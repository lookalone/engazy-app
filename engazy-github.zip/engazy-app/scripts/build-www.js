// يجهّز مجلد www (نسخة الويب اللي بيتغلّف جوه تطبيق أندرويد بـ Capacitor)
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const out = path.join(root, 'www');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
// التطبيق على الموبايل صفحة واحدة (نفس نسخة الملف الواحد): التنقل لحظي بدون إعادة تحميل
const src = path.join(root, 'dist', 'engazy-standalone.html');
if (!fs.existsSync(src)) { console.error('شغّل npm run build الأول'); process.exit(1); }
fs.copyFileSync(src, path.join(out, 'index.html'));
console.log('تم: www/ جاهز للتغليف (صفحة واحدة)');
