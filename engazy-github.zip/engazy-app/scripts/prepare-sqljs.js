#!/usr/bin/env node
/**
 * ينسخ محرك SQLite (sql.js = SQLite مترجم لـ WebAssembly) من node_modules إلى vendor/sqljs
 * ويحوّل ملف الـ wasm لملف JS (base64) علشان يشتغل من ملف محلي (file://) بدون إنترنت أو سيرفر.
 * التشغيل: npm run build:sqljs   (الملفات الناتجة موجودة في المشروع جاهزة، مش لازم تشغّله)
 */
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..');
const dist = path.join(root, 'node_modules', 'sql.js', 'dist');
const out = path.join(root, 'vendor', 'sqljs');
fs.mkdirSync(out, { recursive: true });
fs.copyFileSync(path.join(dist, 'sql-wasm.js'), path.join(out, 'sql-wasm.js'));
const wasm = fs.readFileSync(path.join(dist, 'sql-wasm.wasm'));
fs.writeFileSync(path.join(out, 'sql-wasm-b64.js'), 'window.SQLITE_WASM_B64="' + wasm.toString('base64') + '";\n');
fs.copyFileSync(path.join(root, 'node_modules', 'sql.js', 'LICENSE'), path.join(out, 'LICENSE'));
console.log('تم: vendor/sqljs (' + (wasm.length / 1024).toFixed(0) + ' KB wasm)');
