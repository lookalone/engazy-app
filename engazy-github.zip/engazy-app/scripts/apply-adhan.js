#!/usr/bin/env node
/**
 * بينقل ملف الأذان المخصص (custom-sounds/adhan.*) إلى موارد أندرويد (res/raw/adhan.*)
 * قبل بناء الـ APK. لو مفيش ملف، بيفضل الصوت الافتراضي (adhan.wav).
 */
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const raw = path.join(root, 'android/app/src/main/res/raw');
const src = path.join(root, 'custom-sounds');
const exts = ['.mp3', '.ogg', '.wav', '.m4a', '.aac'];
if (!fs.existsSync(raw)) { console.log('مجلد raw مش موجود — تخطّي'); process.exit(0); }
const found = fs.existsSync(src) ? fs.readdirSync(src).find((f) => /^adhan\./i.test(f) && exts.includes(path.extname(f).toLowerCase())) : null;
if (!found) { console.log('مفيش ملف أذان مخصص: هيستخدم النغمة الافتراضية'); process.exit(0); }
fs.readdirSync(raw).filter((f) => /^adhan\./i.test(f)).forEach((f) => fs.rmSync(path.join(raw, f)));
const ext = path.extname(found).toLowerCase();
fs.copyFileSync(path.join(src, found), path.join(raw, 'adhan' + ext));
console.log('تم نقل ملف الأذان:', found, '→ res/raw/adhan' + ext);
