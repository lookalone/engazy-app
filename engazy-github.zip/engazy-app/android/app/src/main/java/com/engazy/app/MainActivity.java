package com.engazy.app;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.BridgeActivity;

/**
 * ملء الشاشة بالكامل: التطبيق بيترسم تحت شريط الحالة (الإشعارات) وشريط التنقل،
 * وبنبعت أبعاد الأشرطة للصفحة كمتغيرات CSS (--sat و --sab و --kb) علشان المحتوى ما يتغطّاش.
 */
public class MainActivity extends BridgeActivity {
    private int top = 0, bottom = 0, kb = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());

    public class InsetsBridge {
        @JavascriptInterface
        public String get() { return top + "," + bottom + "," + kb; }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window w = getWindow();
        WindowCompat.setDecorFitsSystemWindows(w, false);
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) w.setNavigationBarContrastEnforced(false);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
        if (c != null) {
            c.setAppearanceLightStatusBars(false);     // أيقونات بيضاء فوق الهيدر الملوّن
            c.setAppearanceLightNavigationBars(true);  // أيقونات غامقة فوق الشريط الأبيض
        }

        try {
            WebView wv = getBridge().getWebView();
            wv.addJavascriptInterface(new InsetsBridge(), "EngazyInsets");
        } catch (Exception ignored) {}

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            float d = getResources().getDisplayMetrics().density;
            top = Math.round(bars.top / d);
            bottom = Math.round(bars.bottom / d);
            kb = Math.max(0, Math.round((ime.bottom - bars.bottom) / d));
            push();
            return insets;
        });
        // نبعتها كذا مرة لأن الصفحة بتحمّل بعد الـ insets
        for (int ms : new int[]{300, 900, 2000, 4000}) handler.postDelayed(this::push, ms);
    }

    @Override
    public void onResume() {
        super.onResume();
        push();
    }

    private void push() {
        try {
            final String js = "window.__engazyInsets && window.__engazyInsets(" + top + "," + bottom + "," + kb + ");" +
                    "document.documentElement.style.setProperty('--sat','" + top + "px');" +
                    "document.documentElement.style.setProperty('--sab','" + bottom + "px');" +
                    "document.documentElement.style.setProperty('--kb','" + kb + "px');";
            runOnUiThread(() -> {
                try { getBridge().getWebView().evaluateJavascript(js, null); } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {}
    }
}
