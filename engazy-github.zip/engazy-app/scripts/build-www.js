// يجهّز مجلد www (نسخة الويب اللي بيتغلّف جوه تطبيق أندرويد بـ Capacitor)
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const out = path.join(root, 'www');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
const copy = (rel) => fs.cpSync(path.join(root, rel), path.join(out, rel), { recursive: true });
['index.html', 'home.html', 'tasks.html', 'notifications.html', 'reports.html', 'profile.html', 'prayer.html', 'css', 'js', 'fonts', 'vendor', 'sounds'].forEach(copy);
console.log('تم: www/ جاهز للتغليف');
