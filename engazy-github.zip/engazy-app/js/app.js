(function () {
  'use strict';

  /* =====================================================
     إنجازي – Engazy
     المخزن: كل البيانات بتتحفظ في localStorage
     ===================================================== */
  var KEY = 'engazy.v3';

  function uid() { return 'i' + Math.random().toString(36).slice(2, 9); }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /* ---------- التاريخ والوقت ---------- */
  var now = new Date();
  var LOCALE = 'ar-EG-u-ca-gregory-nu-latn'; // ميلادي بأرقام إنجليزية
  var MIN = 60000, HOUR = 3600000, DAY = 86400000;
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function isoDate(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parseISO(s) { var p = s.split('-'); return new Date(+p[0], +p[1] - 1, +p[2]); }
  var TODAY = isoDate(now);
  var dateStr = now.toLocaleDateString(LOCALE, { day: 'numeric', month: 'long', year: 'numeric' });
  var dayStr = now.toLocaleDateString(LOCALE, { weekday: 'long' });

  function dtAt(ms) { var d = new Date(ms); return { date: isoDate(d), time: pad(d.getHours()) + ':' + pad(d.getMinutes()) }; }
  function toMs(date, time, def) {
    if (!date) return NaN;
    var p = date.split('-'), tm = (time || def).split(':');
    return new Date(+p[0], +p[1] - 1, +p[2], +tm[0], +tm[1], 0, 0).getTime();
  }
  // لو الوقت فاضي: البداية 12:00 ص والنهاية 11:59:59 م
  function startMs(t) { return toMs(t.startDate, t.startTime, '00:00'); }
  function endMs(t) { return toMs(t.endDate, t.endTime, '23:59') + (t.endTime ? 0 : 59999); }

  function dayDiff(iso) { return Math.round((parseISO(iso) - parseISO(TODAY)) / DAY); }
  function dayLabel(iso, short) {
    if (!iso) return '';
    var d = dayDiff(iso);
    if (d === 0) return 'اليوم';
    if (d === 1) return 'غدًا';
    if (d === -1) return 'أمس';
    return parseISO(iso).toLocaleDateString(LOCALE, short ? { day: 'numeric', month: 'short' } : { weekday: 'long', day: 'numeric', month: 'long' });
  }
  function fullDate(iso) {
    if (!iso) return '—';
    var txt = parseISO(iso).toLocaleDateString(LOCALE, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    var d = dayDiff(iso);
    return d === 0 ? 'اليوم · ' + txt : d === 1 ? 'غدًا · ' + txt : txt;
  }
  function fmtTime(t, long) {
    if (!t) return '';
    var p = t.split(':'), h = +p[0], m = p[1];
    var h12 = h % 12 || 12;
    return h12 + ':' + m + ' ' + (long ? (h < 12 ? 'صباحًا' : 'مساءً') : (h < 12 ? 'ص' : 'م'));
  }
  function stamp(date, time, short) { return [dayLabel(date, short), fmtTime(time)].filter(Boolean).join(' '); }
  function rangeText(t) { return 'من ' + stamp(t.startDate, t.startTime, true) + ' إلى ' + stamp(t.endDate, t.endTime, true); }

  /* ---------- حساب المدة (أيام / ساعات / دقائق) بصيغة عربية صحيحة ---------- */
  var UNITS = {
    d: ['يوم واحد', 'يومان', 'أيام', 'يومًا'],
    h: ['ساعة واحدة', 'ساعتان', 'ساعات', 'ساعة'],
    m: ['دقيقة واحدة', 'دقيقتان', 'دقائق', 'دقيقة']
  };
  function unitTxt(n, k) {
    var f = UNITS[k];
    if (n === 1) return f[0];
    if (n === 2) return f[1];
    return n + ' ' + (n <= 10 ? f[2] : f[3]);
  }
  function parts(ms) {
    var m = Math.floor(Math.max(0, ms) / MIN);
    return { d: Math.floor(m / 1440), h: Math.floor(m % 1440 / 60), m: m % 60, totalH: Math.floor(m / 60) };
  }
  function durTxt(ms) {
    var p = parts(ms), a = [];
    if (p.d) { a.push(unitTxt(p.d, 'd')); if (p.h) a.push(unitTxt(p.h, 'h')); }
    else if (p.h) { a.push(unitTxt(p.h, 'h')); if (p.m) a.push(unitTxt(p.m, 'm')); }
    else if (p.m) a.push(unitTxt(p.m, 'm'));
    else return 'أقل من دقيقة';
    return a.join(' و');
  }

  // صيغة العدد في العربي: مهمة / مهمتان / مهام / مهمة
  function tasksWord(n) {
    if (n === 0) return 'لا توجد مهام';
    if (n === 1) return 'مهمة واحدة';
    if (n === 2) return 'مهمتان';
    if (n <= 10) return n + ' مهام';
    return n + ' مهمة';
  }

  /* ---------- حالة المهمة ---------- */
  // done: منتهية ✓ | expired: انتهى وقتها دون إنجاز (كارت أحمر) | upcoming: قادمة | active: نشطة
  function statusOf(t) {
    if (t.done) return 'done';
    if (t.canceled) return 'canceled';
    var n = Date.now();
    if (n > endMs(t)) return 'expired';
    if (n < startMs(t)) return 'upcoming';
    return 'active';
  }
  function isExpired(t) { return statusOf(t) === 'expired'; }
  function isOpen(t) { return !t.done && !t.canceled; }
  var STATUS_TXT = { done: 'منتهية', canceled: 'ملغاة', expired: 'انتهت دون إنجاز', upcoming: 'قادمة', active: 'نشطة' };
  var STATUS_CHIP = { done: 'chip-done', canceled: 'chip-cancel', expired: 'chip-late', upcoming: 'chip-up', active: 'chip-run' };

  function remainText(t) {
    var s = statusOf(t), n = Date.now();
    if (s === 'done') return 'تم الإنجاز ✓';
    if (s === 'canceled') return 'مهمة ملغاة';
    if (s === 'expired') return 'انتهت منذ ' + durTxt(n - endMs(t));
    if (s === 'upcoming') return 'تبدأ بعد ' + durTxt(startMs(t) - n);
    return 'متبقي ' + durTxt(endMs(t) - n);
  }
  function elapsedPct(t) {
    var s = startMs(t), e = endMs(t), n = Date.now();
    if (n <= s) return 0;
    if (n >= e) return 100;
    return Math.round((n - s) / (e - s) * 100);
  }

  /* ---------- التصنيفات ---------- */
  var CATS = {
    work:     { n: 'عمل',      i: 'fa-briefcase',        c: '#3a7bd5' },
    study:    { n: 'دراسة',    i: 'fa-graduation-cap',   c: '#7c5cd6' },
    home:     { n: 'بيت',      i: 'fa-house-chimney',    c: '#e08a2e' },
    health:   { n: 'صحة',      i: 'fa-heart-pulse',      c: '#e0507a' },
    finance:  { n: 'مالية',    i: 'fa-wallet',           c: '#2f9e6e' },
    shopping: { n: 'تسوق',     i: 'fa-cart-shopping',    c: '#c98f12' },
    social:   { n: 'اجتماعي',  i: 'fa-users',            c: '#16a6b6' },
    designs:  { n: 'تصميمات',  i: 'fa-palette',          c: '#d946ef' },
    print:    { n: 'طباعة',    i: 'fa-print',            c: '#475569' },
    travel:   { n: 'سفر',      i: 'fa-plane',            c: '#0ea5e9' },
    personal: { n: 'شخصي',     i: 'fa-user',             c: '#6b7a99' }
  };
  var CAT_ORDER = ['work', 'study', 'home', 'health', 'finance', 'shopping', 'social', 'designs', 'print', 'travel', 'personal'];
  function catOf(t) { return CATS[t.cat] ? t.cat : 'personal'; }
  function catChip(t) {
    var k = catOf(t), c = CATS[k];
    return '<span class="chip" style="background:' + c.c + '22;color:' + c.c + '"><i class="fa-solid ' + c.i + ' text-[10px]"></i>' + c.n + '</span>';
  }

  /* ----- مكتبة أيقونات المهام (96 أيقونة في 8 مجالات) ----- */
  var ICON_GROUPS = [
    ['عمل', 'fa-briefcase', ['briefcase', 'laptop-code', 'chart-line', 'handshake', 'phone', 'envelope', 'file-lines', 'folder-open', 'building', 'users-gear', 'clipboard-check', 'calculator']],
    ['دراسة', 'fa-graduation-cap', ['graduation-cap', 'book', 'book-open', 'pen-to-square', 'flask', 'microscope', 'language', 'atom', 'school', 'pencil', 'square-root-variable', 'globe']],
    ['صحة ورياضة', 'fa-heart-pulse', ['heart-pulse', 'dumbbell', 'person-running', 'stethoscope', 'pills', 'tooth', 'bicycle', 'apple-whole', 'bed', 'droplet', 'futbol', 'spa']],
    ['بيت وأسرة', 'fa-house-chimney', ['house-chimney', 'broom', 'utensils', 'shirt', 'baby', 'paw', 'seedling', 'screwdriver-wrench', 'couch', 'soap', 'car', 'key']],
    ['مال وتسوق', 'fa-wallet', ['wallet', 'cart-shopping', 'credit-card', 'piggy-bank', 'receipt', 'gift', 'bag-shopping', 'money-bill-wave', 'building-columns', 'tags', 'basket-shopping', 'coins']],
    ['سفر وترفيه', 'fa-plane', ['plane', 'map-location-dot', 'suitcase', 'camera', 'music', 'gamepad', 'film', 'champagne-glasses', 'mug-hot', 'tent', 'umbrella-beach', 'cake-candles']],
    ['تقنية وإبداع', 'fa-lightbulb', ['code', 'mobile-screen', 'wifi', 'palette', 'lightbulb', 'pen-nib', 'video', 'headphones', 'microphone', 'server', 'bug', 'rocket']],
    ['عادات وعبادات', 'fa-person-praying', ['person-praying', 'book-quran', 'moon', 'sun', 'hand-holding-heart', 'droplet', 'glass-water', 'pills', 'prescription-bottle-medical', 'syringe', 'bowl-food', 'repeat']],
    ['أخرى', 'fa-star', ['star', 'bell', 'flag', 'heart', 'bolt', 'fire', 'trophy', 'mosque', 'hands-praying', 'calendar-check', 'thumbtack', 'bullseye']]
  ];
  var ICON_SET = {};
  ICON_GROUPS.forEach(function (g) { g[2] = g[2].map(function (n) { return 'fa-' + n; }); g[2].forEach(function (c) { ICON_SET[c] = 1; }); });
  // أيقونة المهمة: المختارة، وإلا أيقونة التصنيف
  function iconOf(t) { return t.icon && ICON_SET[t.icon] ? t.icon : CATS[catOf(t)].i; }
  function taskIco(t, big) {
    var c = CATS[catOf(t)].c;
    return '<span class="tico' + (big ? ' tico-lg' : '') + '" style="background:' + c + '22;color:' + c + '"><i class="fa-solid ' + iconOf(t) + '"></i></span>';
  }

  /* ----- تصنيفات العادات الافتراضية (تقدر تضيف وتعدّل تصنيفاتك) ----- */
  var HC_DEFAULTS = [
    { id: 'hc_pray', name: 'صلاة', icon: 'fa-person-praying', color: '#16a6b6', type: 'normal' },
    { id: 'hc_fast', name: 'صيام', icon: 'fa-moon', color: '#7c5cd6', type: 'normal' },
    { id: 'hc_alms', name: 'صدقات', icon: 'fa-hand-holding-heart', color: '#e0507a', type: 'normal' },
    { id: 'hc_water', name: 'شرب ماء', icon: 'fa-glass-water', color: '#1b7fc9', type: 'normal' },
    { id: 'hc_med', name: 'دواء', icon: 'fa-pills', color: '#15935a', type: 'med' },
    { id: 'hc_sport', name: 'رياضة', icon: 'fa-dumbbell', color: '#e08a2e', type: 'normal' },
    { id: 'hc_routine', name: 'عادة / روتين', icon: 'fa-repeat', color: '#3a7bd5', type: 'normal' }
  ];
  function hcDefaults() { return HC_DEFAULTS.map(function (c) { return Object.assign({}, c); }); }

  var PRI = { high: 'عالية', mid: 'متوسطة', low: 'منخفضة' };
  var PRI_CHIP = { high: 'chip-high', mid: 'chip-mid', low: 'chip-low' };
  var REMIND = [[0, 'بدون تذكير'], [15, 'قبل الانتهاء بـ 15 دقيقة'], [60, 'قبل الانتهاء بساعة'], [180, 'قبل الانتهاء بـ 3 ساعات'], [1440, 'قبل الانتهاء بيوم']];
  function remindTxt(m) {
    var r = REMIND.filter(function (x) { return x[0] === (m || 0); })[0];
    return r ? r[1] : 'بدون تذكير';
  }

  /* =====================================================
     المهمة: إنشاء وعلامات التنبيه
     ===================================================== */
  // علامات "تم التنبيه" – الأحداث اللي عدّت بالفعل بنعلّمها بدون ما نزعج المستخدم
  function flagPast(t) {
    var n = Date.now();
    t.n = {};
    if (n >= startMs(t)) t.n.start = 1;
    if (n > endMs(t)) t.n.end = 1;
    if (t.remind && n >= endMs(t) - t.remind * MIN) t.n.soon = 1;
  }
  // يضمن وجود حقول التأجيل/الإلغاء/الرنين في أي مهمة قديمة
  function fixTask(t) {
    if (!t.n) t.n = {};
    t.icon = ICON_SET[t.icon] ? t.icon : '';
    t.canceled = !!t.canceled; t.canceledAt = t.canceledAt || null;
    t.ring = t.ring === 'soon' || t.ring === 'end' ? t.ring : '';
    if (!Array.isArray(t.snoozes)) t.snoozes = [];
    return t;
  }
  function makeTask(o) {
    var t = {
      id: uid(), title: o.title, notes: o.notes || '', cat: o.cat || 'personal',
      startDate: o.startDate, startTime: o.startTime || '', endDate: o.endDate, endTime: o.endTime || '',
      place: o.place || '', priority: o.priority || 'mid', remind: o.remind == null ? 60 : o.remind,
      done: !!o.done, createdAt: Date.now(), doneAt: o.done ? Date.now() : null, n: {},
      canceled: false, canceledAt: null, ring: '', snoozes: [], icon: ICON_SET[o.icon] ? o.icon : ''
    };
    flagPast(t);
    return t;
  }
  /* =====================================================
     قاعدة البيانات: SQLite حقيقية
     المحرك: SQLite الأصلي مترجم لـ WebAssembly (sql.js) ويشتغل محليًا بدون إنترنت.
     الملف (.sqlite) بيتحفظ بعد كل تعديل في IndexedDB، وتقدر تصدّره وتفتحه ببرنامج DB Browser.
     ===================================================== */
  var SQLM = null, db = null, dbOK = false, dbError = '';
  var dbInfo = { lastSave: 0, bytes: 0, recovered: false, migrated: false, persistError: '', via: 'IndexedDB' };
  var lastParts = {}, persistTimer = null, persistChain = Promise.resolve(), localRev = 0;

  function emptyState() {
    return {
      v: 3,
      user: { name: 'صديقي', title: '', bio: '', phone: '', email: '', avatar: { t: 'art', c: 0, src: '' }, theme: 'aqua' },
      settings: { sound: true, notify: false },
      projects: [], personal: [], tasks: [], notifs: [],
      habitCats: hcDefaults(), habits: [], habitLogs: []
    };
  }
  function normalizeState(l) {
    var s = emptyState();
    s.user = Object.assign(s.user, l.user || {});
    s.settings = Object.assign(s.settings, l.settings || {});
    ['projects', 'personal', 'tasks', 'notifs'].forEach(function (k) { if (Array.isArray(l[k])) s[k] = l[k]; });
    s.tasks.forEach(fixTask);
    ['habitCats', 'habits', 'habitLogs'].forEach(function (k) { if (Array.isArray(l[k])) s[k] = l[k]; });
    if (!s.habitCats.length) s.habitCats = hcDefaults();
    return s;
  }
  var state = emptyState();

  /* ----- IndexedDB (مخزن ملف قاعدة البيانات) ----- */
  function idbOpen() {
    return new Promise(function (res, rej) {
      if (!window.indexedDB) return rej(new Error('IndexedDB غير متاح'));
      var r = indexedDB.open('engazy-db', 1);
      r.onupgradeneeded = function () { r.result.createObjectStore('files'); };
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { rej(r.error || new Error('تعذّر فتح IndexedDB')); };
    });
  }
  function idbDo(mode, fn) {
    return idbOpen().then(function (d) {
      return new Promise(function (res, rej) {
        var tx = d.transaction('files', mode), out;
        try { out = fn(tx.objectStore('files')); } catch (e) { d.close(); return rej(e); }
        tx.oncomplete = function () { d.close(); res(out && out.result); };
        tx.onerror = tx.onabort = function () { d.close(); rej(tx.error || new Error('فشل التخزين')); };
      });
    });
  }
  function idbGet(k) { return idbDo('readonly', function (s) { return s.get(k); }); }
  function idbPut(k, v) { return idbDo('readwrite', function (s) { return s.put(v, k); }); }
  function idbDel(k) { return idbDo('readwrite', function (s) { return s.delete(k); }); }

  // احتياطي لو IndexedDB مش متاح (مثلًا وضع التصفح الخفي)
  function lsDbSave(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i += 8192) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
    localStorage.setItem('engazy.dbfile', btoa(s));
  }
  function lsDbLoad() {
    try {
      var b = localStorage.getItem('engazy.dbfile');
      if (!b) return null;
      var s = atob(b), u = new Uint8Array(s.length);
      for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i);
      return u;
    } catch (e) { return null; }
  }

  /* ----- الجداول ----- */
  var SCHEMA = [
    'CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)',
    'CREATE TABLE IF NOT EXISTS profile (k TEXT PRIMARY KEY, v TEXT)',
    'CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT)',
    "CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY, title TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '', cat TEXT NOT NULL DEFAULT 'personal'," +
      " start_date TEXT NOT NULL, start_time TEXT NOT NULL DEFAULT '', end_date TEXT NOT NULL, end_time TEXT NOT NULL DEFAULT ''," +
      " place TEXT NOT NULL DEFAULT '', priority TEXT NOT NULL DEFAULT 'mid', remind INTEGER NOT NULL DEFAULT 0," +
      ' done INTEGER NOT NULL DEFAULT 0 CHECK (done IN (0,1)), created_at INTEGER, done_at INTEGER,' +
      ' n_start INTEGER NOT NULL DEFAULT 0, n_soon INTEGER NOT NULL DEFAULT 0, n_end INTEGER NOT NULL DEFAULT 0, pos INTEGER NOT NULL DEFAULT 0,' +
      " canceled INTEGER NOT NULL DEFAULT 0, canceled_at INTEGER, ring TEXT NOT NULL DEFAULT '', icon TEXT NOT NULL DEFAULT ''," +
      ' CHECK (end_date >= start_date))',
    'CREATE INDEX IF NOT EXISTS idx_tasks_end ON tasks (end_date)',
    'CREATE INDEX IF NOT EXISTS idx_tasks_done ON tasks (done)',
    // سجل التأجيلات: كل مرة اتمدّت فيها فترة المهمة = صف
    'CREATE TABLE IF NOT EXISTS task_snoozes (id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,' +
      " at INTEGER NOT NULL, mins INTEGER NOT NULL CHECK (mins > 0), via TEXT NOT NULL DEFAULT 'manual'," +
      " from_end_date TEXT NOT NULL DEFAULT '', from_end_time TEXT NOT NULL DEFAULT '', to_end_date TEXT NOT NULL DEFAULT '', to_end_time TEXT NOT NULL DEFAULT '')",
    'CREATE INDEX IF NOT EXISTS idx_snoozes_task ON task_snoozes (task_id)',
    // العادات والروتين: تصنيفات + عادات (بمواعيد وجرعات) + سجل التنفيذ اليومي
    "CREATE TABLE IF NOT EXISTS habit_cats (id TEXT PRIMARY KEY, name TEXT NOT NULL, icon TEXT NOT NULL DEFAULT '', color TEXT NOT NULL DEFAULT '#3a7bd5', type TEXT NOT NULL DEFAULT 'normal' CHECK (type IN ('normal','med')), pos INTEGER NOT NULL DEFAULT 0)",
    "CREATE TABLE IF NOT EXISTS habits (id TEXT PRIMARY KEY, title TEXT NOT NULL, cat TEXT NOT NULL DEFAULT '', times TEXT NOT NULL DEFAULT '[]', days TEXT NOT NULL DEFAULT '[]'," +
      " start_date TEXT NOT NULL DEFAULT '', end_date TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', paused INTEGER NOT NULL DEFAULT 0 CHECK (paused IN (0,1))," +
      " pills REAL NOT NULL DEFAULT 1, unit TEXT NOT NULL DEFAULT '', food TEXT NOT NULL DEFAULT 'any', stock REAL, stock_init REAL, low_alerted INTEGER NOT NULL DEFAULT 0," +
      " alerted TEXT NOT NULL DEFAULT '{}', created_at INTEGER, since INTEGER, pos INTEGER NOT NULL DEFAULT 0)",
    "CREATE TABLE IF NOT EXISTS habit_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, habit_id TEXT NOT NULL REFERENCES habits(id) ON DELETE CASCADE, d TEXT NOT NULL, t TEXT NOT NULL," +
      " st TEXT NOT NULL CHECK (st IN ('done','skip')), at INTEGER, q REAL NOT NULL DEFAULT 0, UNIQUE (habit_id, d, t))",
    'CREATE INDEX IF NOT EXISTS idx_hlogs_habit ON habit_logs (habit_id, d)',
    "CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, title TEXT NOT NULL, descr TEXT NOT NULL DEFAULT '', color TEXT NOT NULL DEFAULT 'green', pos INTEGER NOT NULL DEFAULT 0)",
    'CREATE TABLE IF NOT EXISTS project_tasks (id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,' +
      ' title TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0 CHECK (done IN (0,1)), pos INTEGER NOT NULL DEFAULT 0)',
    'CREATE INDEX IF NOT EXISTS idx_ptasks_project ON project_tasks (project_id)',
    "CREATE TABLE IF NOT EXISTS personal (id TEXT PRIMARY KEY, title TEXT NOT NULL, descr TEXT NOT NULL DEFAULT '', progress INTEGER NOT NULL DEFAULT 0 CHECK (progress BETWEEN 0 AND 100), color TEXT NOT NULL DEFAULT 'green', pos INTEGER NOT NULL DEFAULT 0)",
    "CREATE TABLE IF NOT EXISTS notifs (id TEXT PRIMARY KEY, icon TEXT NOT NULL DEFAULT '', tone TEXT NOT NULL DEFAULT 'royal', title TEXT NOT NULL, sub TEXT NOT NULL DEFAULT '', read INTEGER NOT NULL DEFAULT 0 CHECK (read IN (0,1)), pos INTEGER NOT NULL DEFAULT 0)"
  ];
  var TABLES = ['tasks', 'task_snoozes', 'habit_cats', 'habits', 'habit_logs', 'projects', 'project_tasks', 'personal', 'notifs', 'profile', 'settings', 'meta'];
  function ensureSchema() {
    // ترحيل القواعد القديمة (النسخة 1): نضيف أعمدة الإلغاء والرنين قبل ما ننشئ باقي الجداول
    var hasTasks = q("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'tasks'").length;
    if (hasTasks) {
      var cols = q('PRAGMA table_info(tasks)').map(function (r) { return r.name; });
      if (cols.indexOf('canceled') < 0) db.run('ALTER TABLE tasks ADD COLUMN canceled INTEGER NOT NULL DEFAULT 0');
      if (cols.indexOf('canceled_at') < 0) db.run('ALTER TABLE tasks ADD COLUMN canceled_at INTEGER');
      if (cols.indexOf('ring') < 0) db.run("ALTER TABLE tasks ADD COLUMN ring TEXT NOT NULL DEFAULT ''");
      if (cols.indexOf('icon') < 0) db.run("ALTER TABLE tasks ADD COLUMN icon TEXT NOT NULL DEFAULT ''");
    }
    SCHEMA.forEach(function (sql) { db.run(sql); });
    db.run('PRAGMA user_version = 4');
    db.run('PRAGMA foreign_keys = ON');
  }

  function q(sql, params) {
    var st = db.prepare(sql), rows = [];
    if (params) st.bind(params);
    while (st.step()) rows.push(st.getAsObject());
    st.free();
    return rows;
  }
  function runMany(sql, rows) {
    var st = db.prepare(sql);
    try { rows.forEach(function (r) { st.run(r); }); } finally { st.free(); }
  }
  function kv(table) { var o = {}; q('SELECT k, v FROM ' + table).forEach(function (r) { o[r.k] = r.v; }); return o; }

  /* ----- الكتابة: بنكتب بس الجداول اللي اتغيّرت، داخل Transaction واحدة ----- */
  var WRITERS = {
    profile: function () {
      var u = state.user;
      db.run('DELETE FROM profile');
      runMany('INSERT INTO profile (k, v) VALUES (?, ?)', [
        ['name', u.name || ''], ['title', u.title || ''], ['bio', u.bio || ''], ['phone', u.phone || ''], ['email', u.email || ''],
        ['theme', u.theme || 'aqua'], ['avatar', JSON.stringify(u.avatar || { t: 'art' })]
      ]);
    },
    settings: function () {
      db.run('DELETE FROM settings');
      runMany('INSERT INTO settings (k, v) VALUES (?, ?)', [['sound', state.settings.sound ? '1' : '0'], ['notify', state.settings.notify ? '1' : '0']]);
    },
    tasks: function () {
      db.run('DELETE FROM task_snoozes'); db.run('DELETE FROM tasks');
      runMany('INSERT INTO tasks (id, title, notes, cat, start_date, start_time, end_date, end_time, place, priority, remind, done, created_at, done_at, n_start, n_soon, n_end, pos, canceled, canceled_at, ring, icon) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        state.tasks.map(function (t, i) {
          var sd = t.startDate || TODAY, ed = t.endDate || sd;
          if (ed < sd) ed = sd; // القاعدة نفسها بتمنع النهاية قبل البداية
          var n = t.n || {};
          return [t.id, t.title || '', t.notes || '', t.cat || 'personal', sd, t.startTime || '', ed, t.endTime || '', t.place || '', t.priority || 'mid',
            t.remind || 0, t.done ? 1 : 0, t.createdAt || Date.now(), t.doneAt || null, n.start ? 1 : 0, n.soon ? 1 : 0, n.end ? 1 : 0, i,
            t.canceled ? 1 : 0, t.canceledAt || null, t.ring === 'soon' || t.ring === 'end' ? t.ring : '', ICON_SET[t.icon] ? t.icon : ''];
        }));
      var rows = [];
      state.tasks.forEach(function (t) {
        (t.snoozes || []).forEach(function (z) {
          var f = z.fromEnd || {}, to = z.toEnd || {};
          rows.push([t.id, z.at || Date.now(), Math.max(1, z.mins | 0), z.via || 'manual', f.date || '', f.time || '', to.date || '', to.time || '']);
        });
      });
      runMany('INSERT INTO task_snoozes (task_id, at, mins, via, from_end_date, from_end_time, to_end_date, to_end_time) VALUES (?,?,?,?,?,?,?,?)', rows);
    },
    habitCats: function () {
      db.run('DELETE FROM habit_cats');
      runMany('INSERT INTO habit_cats (id, name, icon, color, type, pos) VALUES (?,?,?,?,?,?)',
        state.habitCats.map(function (c, i) { return [c.id, c.name || '', c.icon || '', c.color || '#3a7bd5', c.type === 'med' ? 'med' : 'normal', i]; }));
    },
    habits: function () {
      db.run('DELETE FROM habit_logs'); db.run('DELETE FROM habits');
      runMany('INSERT INTO habits (id, title, cat, times, days, start_date, end_date, notes, paused, pills, unit, food, stock, stock_init, low_alerted, alerted, created_at, since, pos) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        state.habits.map(function (h, i) {
          return [h.id, h.title || '', h.cat || '', JSON.stringify(h.times || []), JSON.stringify(h.days || []), h.startDate || '', h.endDate || '', h.notes || '', h.paused ? 1 : 0,
            +h.pills || 1, h.unit || '', h.food || 'any', h.stock == null ? null : +h.stock, h.stockInit == null ? null : +h.stockInit, h.lowAlerted ? 1 : 0,
            JSON.stringify(h.alerted || {}), h.createdAt || Date.now(), h.since || h.createdAt || Date.now(), i];
        }));
      var ids = {};
      state.habits.forEach(function (h) { ids[h.id] = 1; });
      runMany('INSERT OR REPLACE INTO habit_logs (habit_id, d, t, st, at, q) VALUES (?,?,?,?,?,?)',
        state.habitLogs.filter(function (l) { return ids[l.h]; }).map(function (l) { return [l.h, l.d, l.t, l.st === 'skip' ? 'skip' : 'done', l.at || Date.now(), +l.q || 0]; }));
    },
    projects: function () {
      db.run('DELETE FROM project_tasks'); db.run('DELETE FROM projects');
      runMany('INSERT INTO projects (id, title, descr, color, pos) VALUES (?,?,?,?,?)',
        state.projects.map(function (p, i) { return [p.id, p.title || '', p.desc || '', p.color || 'green', i]; }));
      var rows = [];
      state.projects.forEach(function (p) {
        (p.tasks || []).forEach(function (t, i) { rows.push([t.id, p.id, t.t || '', t.done ? 1 : 0, i]); });
      });
      runMany('INSERT INTO project_tasks (id, project_id, title, done, pos) VALUES (?,?,?,?,?)', rows);
    },
    personal: function () {
      db.run('DELETE FROM personal');
      runMany('INSERT INTO personal (id, title, descr, progress, color, pos) VALUES (?,?,?,?,?,?)',
        state.personal.map(function (p, i) { return [p.id, p.title || '', p.desc || '', Math.max(0, Math.min(100, p.progress | 0)), p.color || 'green', i]; }));
    },
    notifs: function () {
      db.run('DELETE FROM notifs');
      runMany('INSERT INTO notifs (id, icon, tone, title, sub, read, pos) VALUES (?,?,?,?,?,?,?)',
        state.notifs.map(function (n, i) { return [n.id, n.icon || '', n.tone || 'royal', n.title || '', n.sub || '', n.read ? 1 : 0, i]; }));
    }
  };
  function partsOf() {
    return {
      profile: JSON.stringify(state.user), settings: JSON.stringify(state.settings), tasks: JSON.stringify(state.tasks),
      projects: JSON.stringify(state.projects), personal: JSON.stringify(state.personal), notifs: JSON.stringify(state.notifs),
      habitCats: JSON.stringify(state.habitCats), habits: JSON.stringify({ h: state.habits, l: state.habitLogs })
    };
  }
  function dbSyncTables() {
    var parts = partsOf(), changed = Object.keys(parts).filter(function (k) { return parts[k] !== lastParts[k]; });
    if (!changed.length) return true;
    try {
      db.run('BEGIN');
      changed.forEach(function (k) { WRITERS[k](); });
      db.run('COMMIT');
    } catch (e) {
      try { db.run('ROLLBACK'); } catch (x) {}
      dbError = String((e && e.message) || e);
      return false;
    }
    changed.forEach(function (k) { lastParts[k] = parts[k]; });
    schedulePersist();
    return true;
  }
  function save() {
    if (dbOK) {
      if (!dbSyncTables()) { try { toast('تعذّر الحفظ في قاعدة البيانات'); } catch (e) {} }
    } else { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} }
    try { nativeSchedule(); } catch (e) {}
  }

  /* ----- حفظ الملف في IndexedDB ----- */
  function persistNow() {
    if (!dbOK) return Promise.resolve();
    var bytes = db.export();
    db.run('PRAGMA foreign_keys = ON'); // export بيعيد فتح القاعدة فبنرجّع الإعداد
    persistChain = persistChain.then(function () {
      return idbPut('main', bytes).then(function () { localRev = Date.now(); return idbPut('rev', localRev); });
    }).then(function () {
      dbInfo.lastSave = Date.now(); dbInfo.bytes = bytes.length; dbInfo.persistError = ''; dbInfo.via = 'IndexedDB';
    }).catch(function (e) {
      try { lsDbSave(bytes); dbInfo.via = 'localStorage'; dbInfo.lastSave = Date.now(); dbInfo.bytes = bytes.length; dbInfo.persistError = ''; }
      catch (x) { dbInfo.persistError = String((e && e.message) || e); }
    });
    return persistChain;
  }
  function schedulePersist() {
    clearTimeout(persistTimer);
    persistTimer = setTimeout(function () { persistTimer = null; persistNow(); }, 40);
  }
  function flushPersist() { if (persistTimer) { clearTimeout(persistTimer); persistTimer = null; persistNow(); } }
  window.addEventListener('pagehide', flushPersist);
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) flushPersist();
    else if (dbOK && dbInfo.via === 'IndexedDB') {
      // لو تبويب تاني عدّل القاعدة، نعيد التحميل علشان ما نكتبش فوق تعديلاته
      idbGet('rev').then(function (r) { if (r && localRev && r !== localRev && !$('#sheet') && !$('.lock')) location.reload(); }).catch(function () {});
    }
  });

  /* ----- التحميل ----- */
  function loadSqlJs() {
    if (typeof initSqlJs !== 'function' || !window.SQLITE_WASM_B64) return Promise.reject(new Error('ملفات محرك SQLite غير موجودة'));
    var bin = atob(window.SQLITE_WASM_B64), u = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return initSqlJs({ wasmBinary: u });
  }
  function openBytes(bytes) {
    var d = new SQLM.Database(bytes);
    var chk = d.exec('PRAGMA quick_check');
    if (!chk.length || chk[0].values[0][0] !== 'ok') { d.close(); throw new Error('ملف القاعدة تالف'); }
    return d;
  }
  function dbInit() {
    return loadSqlJs().then(function (SQL) {
      SQLM = SQL;
      return idbGet('main').catch(function () { dbInfo.via = 'localStorage'; return null; });
    }).then(function (bytes) {
      if (!bytes) bytes = lsDbLoad();
      if (bytes) {
        try { db = openBytes(bytes); }
        catch (e) { // قاعدة تالفة: نحفظ نسخة منها ونبدأ بقاعدة جديدة بدل ما التطبيق يقع
          dbInfo.recovered = true;
          idbPut('corrupt-' + Date.now(), bytes).catch(function () {});
          db = new SQLM.Database();
        }
      } else db = new SQLM.Database();
      ensureSchema();
      dbOK = true;
      return idbGet('rev').then(function (r) { localRev = r || 0; }).catch(function () {});
    }).then(function () {
      // نطلب تخزين دائم علشان المتصفح ما يمسحش البيانات لوحده
      try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) {}
    });
  }

  function dbLoadState() {
    var meta = kv('meta');
    if (!meta.initialized) { // أول تشغيل: نرحّل بيانات النسخة القديمة (localStorage) لو موجودة، وإلا نبدأ فاضي
      var legacy = null;
      try { legacy = JSON.parse(localStorage.getItem(KEY)); } catch (e) {}
      if (legacy && legacy.v === 3) { state = normalizeState(legacy); dbInfo.migrated = true; } else state = emptyState();
      lastParts = {};
      dbSyncTables();
      db.run("INSERT OR REPLACE INTO meta (k, v) VALUES ('initialized', ?)", [String(Date.now())]);
      db.run("INSERT OR REPLACE INTO meta (k, v) VALUES ('schema', '4')");
      db.run("INSERT OR REPLACE INTO meta (k, v) VALUES ('hc_seeded', '1')");
      if (dbInfo.migrated) db.run("INSERT OR REPLACE INTO meta (k, v) VALUES ('migrated_from', 'localStorage')");
      persistNow();
      return state;
    }
    var s = emptyState(), p = kv('profile'), st = kv('settings');
    ['name', 'title', 'bio', 'phone', 'email', 'theme'].forEach(function (k) { if (p[k] != null) s.user[k] = p[k]; });
    try { if (p.avatar) s.user.avatar = Object.assign(s.user.avatar, JSON.parse(p.avatar)); } catch (e) {}
    if (st.sound != null) s.settings.sound = st.sound === '1';
    if (st.notify != null) s.settings.notify = st.notify === '1';
    s.tasks = q('SELECT * FROM tasks ORDER BY pos').map(function (r) {
      var n = {};
      if (r.n_start) n.start = 1; if (r.n_soon) n.soon = 1; if (r.n_end) n.end = 1;
      return { id: r.id, title: r.title, notes: r.notes, cat: r.cat, startDate: r.start_date, startTime: r.start_time, endDate: r.end_date, endTime: r.end_time,
        place: r.place, priority: r.priority, remind: r.remind, done: !!r.done, createdAt: r.created_at, doneAt: r.done_at, n: n,
        canceled: !!r.canceled, canceledAt: r.canceled_at || null, ring: r.ring || '', snoozes: [], icon: ICON_SET[r.icon] ? r.icon : '' };
    });
    var byId = {};
    s.tasks.forEach(function (t) { byId[t.id] = t; });
    q('SELECT * FROM task_snoozes ORDER BY id').forEach(function (r) {
      if (byId[r.task_id]) byId[r.task_id].snoozes.push({ at: r.at, mins: r.mins, via: r.via, fromEnd: { date: r.from_end_date, time: r.from_end_time }, toEnd: { date: r.to_end_date, time: r.to_end_time } });
    });
    var pt = {};
    q('SELECT * FROM project_tasks ORDER BY pos').forEach(function (r) { (pt[r.project_id] = pt[r.project_id] || []).push({ id: r.id, t: r.title, done: !!r.done }); });
    s.projects = q('SELECT * FROM projects ORDER BY pos').map(function (r) { return { id: r.id, title: r.title, desc: r.descr, color: r.color, tasks: pt[r.id] || [] }; });
    s.personal = q('SELECT * FROM personal ORDER BY pos').map(function (r) { return { id: r.id, title: r.title, desc: r.descr, progress: r.progress, color: r.color }; });
    s.notifs = q('SELECT * FROM notifs ORDER BY pos').map(function (r) { return { id: r.id, icon: r.icon, tone: r.tone, title: r.title, sub: r.sub, read: !!r.read }; });
    s.habitCats = q('SELECT * FROM habit_cats ORDER BY pos').map(function (r) { return { id: r.id, name: r.name, icon: r.icon, color: r.color, type: r.type }; });
    s.habits = q('SELECT * FROM habits ORDER BY pos').map(function (r) {
      var j = function (x, d) { try { return JSON.parse(x); } catch (e) { return d; } };
      return { id: r.id, title: r.title, cat: r.cat, times: j(r.times, []), days: j(r.days, []), startDate: r.start_date, endDate: r.end_date, notes: r.notes, paused: !!r.paused,
        pills: r.pills, unit: r.unit, food: r.food, stock: r.stock, stockInit: r.stock_init, lowAlerted: !!r.low_alerted, alerted: j(r.alerted, {}), createdAt: r.created_at, since: r.since || r.created_at };
    });
    s.habitLogs = q('SELECT * FROM habit_logs ORDER BY id').map(function (r) { return { h: r.habit_id, d: r.d, t: r.t, st: r.st, at: r.at, q: r.q }; });
    var seedCats = !meta.hc_seeded;
    if (seedCats) {
      if (!s.habitCats.length) s.habitCats = hcDefaults();
      db.run("INSERT OR REPLACE INTO meta (k, v) VALUES ('hc_seeded', '1')");
    }
    state = s;
    lastParts = partsOf();
    if (seedCats) { lastParts.habitCats = ''; dbSyncTables(); }
    return s;
  }

  /* ----- معلومات + اختبار + نسخ احتياطي ----- */
  function fmtBytes(n) { return n < 1024 ? n + ' بايت' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(2) + ' MB'; }
  function dbStats() {
    var o = { version: q('SELECT sqlite_version() AS v')[0].v, pageSize: q('PRAGMA page_size')[0].page_size, pages: q('PRAGMA page_count')[0].page_count, counts: {} };
    o.size = o.pageSize * o.pages;
    ['tasks', 'task_snoozes', 'habits', 'habit_logs', 'projects', 'project_tasks', 'personal', 'notifs'].forEach(function (t) { o.counts[t] = q('SELECT COUNT(*) AS c FROM ' + t)[0].c; });
    o.total = Object.keys(o.counts).reduce(function (a, k) { return a + o.counts[k]; }, 0);
    return o;
  }
  function fingerprint(d) {
    var r = d.exec("SELECT (SELECT COUNT(*) FROM tasks) || '/' || (SELECT COUNT(*) FROM task_snoozes) || '/' || (SELECT COALESCE(SUM(length(title)+length(notes)),0) FROM tasks) || '/' || " +
      "(SELECT COUNT(*) FROM projects) || '/' || (SELECT COUNT(*) FROM project_tasks) || '/' || (SELECT COUNT(*) FROM personal) || '/' || (SELECT COUNT(*) FROM notifs) || '/' || " +
      "(SELECT COALESCE(group_concat(v, '|'), '') FROM profile)");
    return r[0].values[0][0];
  }
  // اختبار حقيقي: كتابة وقراءة وسلامة وحفظ دائم وإعادة تحميل من الملف المحفوظ
  function runSelfTest() {
    var res = [], t0 = Date.now();
    function add(ok, label, detail) { res.push({ ok: ok, label: label, detail: detail || '' }); }
    function step(label, fn) { try { var d = fn(); add(true, label, d); } catch (e) { add(false, label, String((e && e.message) || e)); } }
    if (!dbOK) { add(false, 'محرك SQLite', dbError || 'لم يتم تشغيل المحرك'); return Promise.resolve(res); }
    step('محرك SQLite يعمل', function () { return 'الإصدار ' + q('SELECT sqlite_version() AS v')[0].v; });
    step('الكتابة والقراءة والحذف', function () {
      var tok = 'ok-' + Math.random().toString(36).slice(2) + '-' + Date.now();
      db.run('CREATE TABLE IF NOT EXISTS selftest (id INTEGER PRIMARY KEY, v TEXT)');
      db.run('INSERT INTO selftest (v) VALUES (?)', [tok]);
      var back = q('SELECT v FROM selftest WHERE v = ?', [tok]);
      db.run('DROP TABLE selftest');
      if (back.length !== 1 || back[0].v !== tok) throw new Error('القيمة المقروءة لا تطابق المكتوبة');
      return 'تمت كتابة سجل وقراءته وحذفه';
    });
    step('سلامة بنية القاعدة', function () {
      var ic = q('PRAGMA integrity_check')[0].integrity_check;
      if (ic !== 'ok') throw new Error(ic);
      if (q('PRAGMA foreign_key_check').length) throw new Error('علاقات غير سليمة');
      return 'integrity_check = ok';
    });
    step('قواعد التحقق داخل القاعدة', function () {
      var blocked = false;
      try { db.run("INSERT INTO tasks (id, title, start_date, end_date) VALUES ('__t', 'x', '2030-01-02', '2030-01-01')"); } catch (e) { blocked = true; }
      if (!blocked) { db.run("DELETE FROM tasks WHERE id = '__t'"); throw new Error('القاعدة قبلت نهاية قبل البداية'); }
      return 'القاعدة ترفض تاريخ نهاية قبل البداية';
    });
    var live = null;
    return Promise.resolve().then(function () { live = fingerprint(db); return persistNow(); }).then(function () {
      if (dbInfo.persistError) throw new Error(dbInfo.persistError);
      return dbInfo.via === 'IndexedDB' ? idbGet('main') : lsDbLoad();
    }).then(function (saved) {
      if (!saved || !saved.length) throw new Error('الملف المحفوظ غير موجود');
      add(true, 'الحفظ الدائم', 'تم حفظ ' + fmtBytes(saved.length) + ' في ' + dbInfo.via);
      var d2 = openBytes(saved), same = fingerprint(d2) === live; d2.close();
      add(same, 'إعادة التحميل من الملف المحفوظ', same ? 'البيانات المحمّلة مطابقة للحالية' : 'البيانات المحمّلة لا تطابق الحالية');
    }).catch(function (e) {
      add(false, 'الحفظ الدائم', String((e && e.message) || e));
    }).then(function () {
      return (navigator.storage && navigator.storage.persisted ? navigator.storage.persisted() : Promise.resolve(null)).catch(function () { return null; });
    }).then(function (p) {
      add(true, 'حماية التخزين من المسح التلقائي', p === true ? 'مفعّلة' : p === false ? 'غير مفعّلة (المتصفح قد يمسح البيانات عند امتلاء المساحة)' : 'غير مدعومة في هذا المتصفح');
      res.ms = Date.now() - t0;
      return res;
    });
  }
  function exportDb() {
    var bytes = db.export();
    db.run('PRAGMA foreign_keys = ON');
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([bytes], { type: 'application/vnd.sqlite3' }));
    a.download = 'engazy-backup-' + TODAY + '.sqlite';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 5000);
    toast('تم تصدير نسخة القاعدة (' + fmtBytes(bytes.length) + ')');
  }
  function importDb(file, after) {
    var rd = new FileReader();
    rd.onerror = function () { toast('تعذّرت قراءة الملف'); };
    rd.onload = function () {
      var bytes = new Uint8Array(rd.result), head = String.fromCharCode.apply(null, bytes.subarray(0, 15));
      if (head !== 'SQLite format 3') return toast('الملف ده مش قاعدة SQLite');
      var d2;
      try {
        d2 = openBytes(bytes);
        var names = d2.exec("SELECT name FROM sqlite_master WHERE type = 'table'")[0];
        var have = names ? names.values.map(function (r) { return r[0]; }) : [];
        if (['tasks', 'projects', 'profile'].some(function (t) { return have.indexOf(t) < 0; })) throw new Error('ليست نسخة إنجازي');
        d2.close();
      } catch (e) { try { d2 && d2.close(); } catch (x) {} return toast('الملف ده مش نسخة إنجازي صالحة'); }
      var go = function () {
        confirmBox({ title: 'استعادة النسخة الاحتياطية', msg: 'هيتم استبدال كل بياناتك الحالية بمحتوى الملف. مفيش تراجع بعد كده.', ok: 'نعم، استبدل بياناتي', cancel: 'إلغاء', icon: 'fa-database' }, function () {
          try { db.close(); } catch (e) {}
          db = new SQLM.Database(bytes);
          ensureSchema();
          lastParts = {};
          dbLoadState();
          persistNow().then(function () { location.reload(); });
        });
      };
      if (hasLock()) verifySheet('تأكيد الهوية', 'استعادة نسخة بتستبدل بياناتك، فلازم تأكد الأول.', function () { closeSheet(); go(); });
      else go();
    };
    rd.readAsArrayBuffer(file);
  }
  function clearUserData() {
    state.tasks = []; state.projects = []; state.personal = []; state.notifs = []; state.habits = []; state.habitLogs = [];
    save();
  }

  function pushNotif(icon, tone, title, sub) {
    state.notifs.unshift({ id: uid(), icon: icon, tone: tone, title: title, sub: sub, read: false });
    state.notifs = state.notifs.slice(0, 30);
  }
  function findTask(id) { return state.tasks.filter(function (x) { return x.id === id; })[0]; }

  /* =====================================================
     أدوات الواجهة
     ===================================================== */
  var STANDALONE = document.body.hasAttribute('data-standalone'); // نسخة الملف الواحد
  var page, phone, route = {}, cleanups = [];
  function href(name) { return STANDALONE ? '#' + name : name + '.html'; }
  // مستمع نقر واحد للصفحة الحالية (عشان ما يتكررش لما نتنقل)
  document.addEventListener('click', function (e) { if (route.click) route.click(e); });

  function greeting() {
    var h = now.getHours();
    if (h < 12) return 'صباح الخير';
    if (h < 18) return 'نهارك سعيد';
    return 'مساء الخير';
  }

  function avatar() {
    return '<svg viewBox="0 0 64 64" class="h-full w-full" aria-hidden="true">' +
      '<rect width="64" height="64" fill="#fff"/>' +
      '<path d="M6 64c2-15 14-21 26-21s24 6 26 21z" fill="#1a4f9c"/>' +
      '<path d="M26 43l6 12 6-12z" fill="#fff"/><path d="M30 46l2 12 2-12z" fill="#ee8040"/>' +
      '<rect x="28" y="35" width="8" height="10" fill="#f59a8e"/>' +
      '<ellipse cx="32" cy="27" rx="10" ry="12" fill="#ffb8ab"/>' +
      '<path d="M21 26c-3-11 5-17 13-15 8 1 11 8 9 15-3-5-8-7-14-5-3 1-6 3-8 5z" fill="#243b6b"/></svg>';
  }

  function toast(msg) {
    var t = $('.toast', phone);
    if (!t) { t = document.createElement('div'); t.className = 'toast'; phone.appendChild(t); }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._h);
    t._h = setTimeout(function () { t.classList.remove('show'); }, 1800);
  }

  /* ---------- النافذة السفلية ---------- */
  function sheetHtml(inner) { return '<div class="sheet-handle"></div>' + inner; }

  function openSheet(inner) {
    var wrap = $('#sheet');
    if (wrap) { var sh = $('.sheet', wrap); sh.innerHTML = sheetHtml(inner); sh.scrollTop = 0; return wrap; }
    wrap = document.createElement('div');
    wrap.id = 'sheet';
    wrap.className = 'sheet-wrap';
    wrap.innerHTML = '<div class="sheet-backdrop" data-close></div><div class="sheet" role="dialog" aria-modal="true">' + sheetHtml(inner) + '</div>';
    phone.appendChild(wrap);
    wrap.addEventListener('click', function (e) {
      if (e.target.closest('[data-close]')) closeSheet();
    });
    requestAnimationFrame(function () { requestAnimationFrame(function () { wrap.classList.add('open'); }); });
    return wrap;
  }
  function closeSheet() {
    var wrap = $('#sheet');
    if (!wrap) return;
    route.viewId = null;
    wrap.classList.remove('open');
    wrap.id = '';
    setTimeout(function () { wrap.remove(); }, 220);
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeSheet(); });

  /* ---------- مودال التأكيد (بديل window.confirm) ---------- */
  // o: { title, msg, ok, cancel, icon, tone: 'danger' | 'warn' | 'info' }
  function confirmBox(o, onYes, onNo) {
    if (!phone) phone = $('.phone');
    if (!phone) { if (window.confirm(o.title + '\n' + (o.msg || ''))) { if (onYes) onYes(); } else if (onNo) onNo(); return; }
    var tone = o.tone || 'danger', host = document.createElement('div'), done = false;
    host.className = 'modal'; host.setAttribute('role', 'alertdialog'); host.setAttribute('aria-modal', 'true'); host.setAttribute('aria-label', o.title);
    host.innerHTML = '<div class="modal-card modal-' + tone + '"><div class="modal-ico"><i class="fa-solid ' + (o.icon || (tone === 'info' ? 'fa-circle-question' : 'fa-triangle-exclamation')) + '"></i></div>' +
      '<h3 class="modal-title">' + esc(o.title) + '</h3>' + (o.msg ? '<p class="modal-msg">' + esc(o.msg) + '</p>' : '') +
      '<div class="modal-btns"><button type="button" class="modal-no">' + esc(o.cancel || 'إلغاء') + '</button><button type="button" class="modal-yes">' + esc(o.ok || 'تأكيد') + '</button></div></div>';
    phone.appendChild(host);
    requestAnimationFrame(function () { host.classList.add('show'); });
    function close(yes) {
      if (done) return;
      done = true;
      document.removeEventListener('keydown', onKey, true);
      host.classList.remove('show');
      setTimeout(function () { host.remove(); }, 160);
      if (yes) { if (onYes) onYes(); } else if (onNo) onNo();
    }
    function onKey(e) { if (e.key === 'Escape') { e.stopImmediatePropagation(); e.preventDefault(); close(false); } }
    document.addEventListener('keydown', onKey, true);
    host.addEventListener('click', function (e) { if (e.target === host) close(false); });
    $('.modal-no', host).addEventListener('click', function () { close(false); });
    $('.modal-yes', host).addEventListener('click', function () { close(true); });
    setTimeout(function () { var b = $('.modal-no', host); if (b) b.focus(); }, 60);
  }

  /* =====================================================
     التنبيهات: صوت + بانر + إشعار المتصفح
     ===================================================== */
  var AC = null;
  function audioCtx() {
    if (!AC) {
      var C = window.AudioContext || window.webkitAudioContext;
      if (!C) return null;
      try { AC = new C(); } catch (e) { return null; }
    }
    if (AC.state === 'suspended') { try { AC.resume(); } catch (e) {} }
    return AC;
  }
  // المتصفحات بتمنع الصوت قبل أول لمسة من المستخدم، فنفتحه عند أول ضغطة
  ['pointerdown', 'touchstart', 'keydown'].forEach(function (ev) {
    document.addEventListener(ev, function () { audioCtx(); }, { passive: true });
  });

  function tone(freq, at, dur, type, vol) {
    var ctx = audioCtx();
    if (!ctx) return;
    var t0 = ctx.currentTime + at;
    var osc = ctx.createOscillator(), g = ctx.createGain();
    osc.type = type || 'sine';
    osc.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.28, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g); g.connect(ctx.destination);
    osc.start(t0); osc.stop(t0 + dur + 0.05);
  }
  function playSound(kind) {
    if (!state.settings.sound) return;
    try {
      if (kind === 'expired') {            // إنذار: ثلاث نغمات نازلة
        tone(880, 0, 0.22, 'square', 0.12); tone(660, 0.26, 0.22, 'square', 0.12); tone(440, 0.52, 0.5, 'square', 0.12);
      } else if (kind === 'soon') {        // تنبيه قرب الانتهاء: نغمتان متكررتان
        tone(988, 0, 0.16, 'triangle', 0.3); tone(988, 0.24, 0.16, 'triangle', 0.3); tone(1319, 0.48, 0.32, 'triangle', 0.3);
      } else {                             // بداية المهمة / تجربة: جرس صاعد
        tone(659, 0, 0.2, 'sine', 0.3); tone(880, 0.17, 0.2, 'sine', 0.3); tone(1319, 0.34, 0.5, 'sine', 0.3);
      }
      if (navigator.vibrate && (!navigator.userActivation || navigator.userActivation.hasBeenActive)) navigator.vibrate(kind === 'expired' ? [220, 100, 220, 100, 320] : [160, 80, 160]);
    } catch (e) {}
  }

  function sysNotify(title, body, tag, sticky) {
    if (isNative() || !state.settings.notify || !('Notification' in window) || Notification.permission !== 'granted') return;
    try { new Notification(title, { body: body, tag: tag, lang: 'ar', dir: 'rtl', requireInteraction: !!sticky }); } catch (e) {}
  }

  /* =====================================================
     طبقة إشعارات الجوال (Capacitor LocalNotifications)
     بتشتغل بس جوه تطبيق الأندرويد؛ في المتصفح مفيش أي تأثير.
     بنجدول الإشعارات مقدّمًا في نظام أندرويد نفسه فترن والتطبيق مقفول.
     ===================================================== */
  var CAP = window.Capacitor || null;
  function isNative() { try { return !!(CAP && CAP.isNativePlatform && CAP.isNativePlatform()); } catch (e) { return false; } }
  function LN() { try { return isNative() && CAP.Plugins && CAP.Plugins.LocalNotifications; } catch (e) { return null; } }
  var NATIVE_CH = 'engazy-alarm', nativeTimer = null, nativeReady = false, nativePerm = 'unknown', MAX_NATIVE = 400;
  function nid(s) { var h = 7; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h) % 2000000000 + 1; }

  function nativeBuild() {
    var out = [], now = Date.now(), seen = {};
    function add(key, at, title, body, tag) {
      if (at <= now + 2000 || seen[key]) return;
      seen[key] = 1;
      out.push({ id: nid(key), title: title, body: body, schedule: { at: new Date(at), allowWhileIdle: true }, channelId: NATIVE_CH, smallIcon: 'ic_stat_engazy', sound: 'engazy_alarm.wav', extra: { tag: tag }, at: at });
    }
    // المهام: بداية + قرب الانتهاء + الانتهاء، ومتابعات بعد الانتهاء/القرب عشان يفضل بيذكّرك
    state.tasks.forEach(function (t) {
      if (!isOpen(t)) return;
      var s = startMs(t), e = endMs(t), soonAt = e - (t.remind || 0) * MIN;
      add('t' + t.id + 's', s, 'حان موعد المهمة', 'بدأت الآن: ' + t.title, 'task');
      if (t.remind) {
        add('t' + t.id + 'w', soonAt, 'المهمة توشك على الانتهاء', 'متبقي ' + durTxt(t.remind * MIN) + ' على «' + t.title + '»', 'task');
        [5, 10].forEach(function (m) { add('t' + t.id + 'w' + m, soonAt + m * MIN, 'تذكير: المهمة توشك على الانتهاء', t.title, 'task'); });
      }
      add('t' + t.id + 'e', e, 'انتهى وقت المهمة دون إنجاز', t.title, 'task');
      [5, 10, 15, 30].forEach(function (m) { add('t' + t.id + 'e' + m, e + m * MIN, 'تذكير: مهمة لم تنجز', t.title, 'task'); });
    });
    // العادات والدواء: الـ 14 يوم الجاية
    var base = todayISO();
    state.habits.forEach(function (h) {
      var c = hcOf(h), med = c.type === 'med';
      for (var i = 0; i < 14; i++) {
        var d = addDaysISO(base, i);
        if (!habitOnDay(h, d)) continue;
        (h.times || []).forEach(function (tm) {
          if (logOf(h.id, d, tm)) return;
          var at = slotMs(d, tm), ttl = (med ? 'حان موعد الدواء: ' : 'حان موعد: ') + h.title;
          var sub = (med ? doseLine(h) : c.name) + ' · الساعة ' + fmtTime(tm, true);
          add('h' + h.id + d + tm, at, ttl, sub, 'habit');
          if (i < 2) [10, 30].forEach(function (m) { add('h' + h.id + d + tm + m, at + m * MIN, 'تذكير: ' + h.title, sub, 'habit'); });
        });
      }
    });
    out.sort(function (a, b) { return a.at - b.at; });
    return out.slice(0, MAX_NATIVE).map(function (n) { delete n.at; return n; });
  }

  function nativeSchedule() {
    var ln = LN();
    if (!ln || !nativeReady || nativePerm !== 'granted') return;
    clearTimeout(nativeTimer);
    nativeTimer = setTimeout(function () {
      var list;
      try { list = nativeBuild(); } catch (e) { return; }
      ln.getPending().then(function (p) {
        var ids = (p && p.notifications || []).map(function (x) { return { id: x.id }; });
        return ids.length ? ln.cancel({ notifications: ids }) : null;
      }).then(function () { return list.length ? ln.schedule({ notifications: list }) : null; }).catch(function () {});
    }, 700);
  }

  function nativeAskPermission(cb) {
    var ln = LN();
    if (!ln) return cb && cb('unsupported');
    ln.checkPermissions().then(function (r) {
      if (r.display === 'granted') return r;
      return ln.requestPermissions();
    }).then(function (r) {
      nativePerm = r.display;
      try { if (ln.checkExactNotificationSetting) ln.checkExactNotificationSetting().then(function (x) { if (x && x.exact_alarm !== 'granted' && ln.changeExactNotificationSetting) ln.changeExactNotificationSetting(); }).catch(function () {}); } catch (e) {}
      nativeSchedule();
      cb && cb(nativePerm);
    }).catch(function () { cb && cb('denied'); });
  }

  function nativeInit() {
    var ln = LN();
    if (!ln || nativeReady) return;
    nativeReady = true;
    try { ln.createChannel({ id: NATIVE_CH, name: 'منبّه إنجازي', description: 'تنبيهات المهام والعادات والدواء', importance: 5, visibility: 1, sound: 'engazy_alarm.wav', vibration: true, lights: true }); } catch (e) {}
    ln.checkPermissions().then(function (r) { nativePerm = r.display; if (r.display !== 'granted') nativeAskPermission(); else nativeSchedule(); }).catch(function () {});
    try { ln.addListener('localNotificationReceived', function () { checkAlerts(); }); } catch (e) {}
    try { ln.addListener('localNotificationActionPerformed', function () { checkAlerts(); }); } catch (e) {}
    try {
      var A = CAP.Plugins.App;
      if (A && A.addListener) {
        A.addListener('resume', function () { checkAlerts(); nativeSchedule(); });
        A.addListener('backButton', function (ev) {
          var sh = $('#sheet'), md = $('.modal');
          if (md) { md.remove(); return; }
          if (sh) { closeSheet(); return; }
          if (ev && ev.canGoBack && history.length > 1) history.back(); else if (A.minimizeApp) A.minimizeApp();
        });
      }
    } catch (e) {}
    document.addEventListener('visibilitychange', function () { if (!document.hidden) { checkAlerts(); nativeSchedule(); } });
  }

  var TONE_BG = { royal: 'rgb(var(--royal))', ember: '#f0732e', red: '#dc2626', leaf: '#2fa866' };
  function banner(icon, tone, title, sub) {
    if (!phone) return;
    var b = $('.alert-banner', phone);
    if (!b) { b = document.createElement('button'); b.className = 'alert-banner'; phone.appendChild(b); }
    b.style.background = TONE_BG[tone] || TONE_BG.royal;
    b.innerHTML = '<span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/25 text-[17px]"><i class="fa-solid ' + icon + '"></i></span>' +
      '<span class="min-w-0 flex-1"><span class="block text-[15px] font-extrabold">' + esc(title) + '</span>' +
      '<span class="block truncate text-[13px] opacity-90">' + esc(sub) + '</span></span>';
    void b.offsetWidth;
    b.classList.add('show');
    clearTimeout(b._h);
    b._h = setTimeout(function () { b.classList.remove('show'); }, 7000);
    b.onclick = function () {
      b.classList.remove('show');
      if (page !== 'notifications') location.href = href('notifications');
    };
  }

  var ALERT_WINDOW = 10 * MIN; // تنبيه "بدأت المهمة" بس لو الحدث حصل من أقل من 10 دقايق
  var RING_WINDOW = 6 * HOUR;  // المنبّه المستمر (قرب الانتهاء / الانتهاء) يرن لو الحدث حصل من أقل من 6 ساعات
  function fire(kind, t) {
    var title, sub, icon, tone, snd;
    if (kind === 'start') {
      icon = 'fa-play'; tone = 'royal'; snd = 'start'; title = 'حان موعد المهمة'; sub = 'بدأت الآن: ' + t.title;
    } else if (kind === 'soon') {
      icon = 'fa-hourglass-half'; tone = 'ember'; snd = 'soon'; title = 'المهمة توشك على الانتهاء';
      sub = 'متبقي ' + durTxt(Math.max(0, endMs(t) - Date.now())) + ' على «' + t.title + '»';
    } else {
      icon = 'fa-triangle-exclamation'; tone = 'red'; snd = 'expired'; title = 'انتهى وقت المهمة دون إنجاز'; sub = t.title;
    }
    pushNotif(icon, tone, title, sub);
    if (kind === 'start') { banner(icon, tone, title, sub); playSound(snd); }
    else t.ring = kind; // المنبّه يفضل شغال لحد ما المستخدم يتصرف
    sysNotify(title + ' – إنجازي', sub, t.id + kind, kind !== 'start');
  }

  function checkAlerts() {
    var n = Date.now(), changed = false;
    state.tasks.forEach(function (t) {
      if (!isOpen(t)) { if (t.ring) { t.ring = ''; changed = true; } return; }
      t.n = t.n || {};
      var s = startMs(t), e = endMs(t), soonAt = e - (t.remind || 0) * MIN;
      if (!t.n.start && n >= s) {
        t.n.start = 1; changed = true;
        if (n - s <= ALERT_WINDOW && n <= e) fire('start', t);
      }
      if (t.remind && !t.n.soon && n >= soonAt && n <= e) {
        t.n.soon = 1; changed = true;
        if (n - soonAt <= RING_WINDOW) fire('soon', t);
      }
      if (!t.n.end && n > e) {
        t.n.end = 1; changed = true;
        if (n - e <= RING_WINDOW) fire('end', t);
        else pushNotif('fa-triangle-exclamation', 'red', 'انتهت مهمة دون إنجاز', t.title);
      }
    });
    if (habitCheck()) changed = true;
    if (changed) { save(); renderNav(); }
    ensureAlarm();
    ensureHabitAlarm();
    return changed;
  }

  var tickStarted = false;
  function liveTick() {
    if (page && page !== 'welcome' && hasLock() && !isUnlocked()) showLock();
    var changed = checkAlerts();
    if (page === 'home' && !$('#sheet')) { renderUrgent(); renderHabits(); }
    if (page === 'tasks' && !$('#sheet')) renderTasks();
    else if (page === 'tasks' && route.viewId) updateCountdown(route.viewId);
    if (changed && page === 'notifications') renderNotifs();
  }

  /* =====================================================
     التأجيل (مدّ الفترة) + الإلغاء + المنبّه المستمر
     ===================================================== */
  var SNZ_QUICK = [[5, '5 دقائق'], [10, '10 دقائق'], [15, '15 دقيقة'], [30, '30 دقيقة'], [60, 'ساعة'], [180, '3 ساعات'], [1440, 'يوم']];
  var SNZ_UNIT = { m: 1, h: 60, d: 1440 };
  var SNZ_MAX = 365 * 1440;
  var VIA_TXT = { alarm: 'من المنبّه', manual: 'إضافة يدوية' };

  // مدة بالدقائق → نص دقيق (أيام وساعات ودقائق)
  function snzTxt(mins) {
    var d = Math.floor(mins / 1440), h = Math.floor(mins % 1440 / 60), m = mins % 60, a = [];
    if (d) a.push(unitTxt(d, 'd'));
    if (h) a.push(unitTxt(h, 'h'));
    if (m) a.push(unitTxt(m, 'm'));
    return a.join(' و');
  }
  function absStamp(date, time) {
    if (!date) return '—';
    return parseISO(date).toLocaleDateString(LOCALE, { day: 'numeric', month: 'short', year: 'numeric' }) + (time ? ' · ' + fmtTime(time, true) : '');
  }
  function atStamp(ms) { return absStamp(isoDate(new Date(ms)), pad(new Date(ms).getHours()) + ':' + pad(new Date(ms).getMinutes())); }
  function snzTotal(t) { return (t.snoozes || []).reduce(function (a, z) { return a + (z.mins || 0); }, 0); }
  function newEndFor(t, mins) { return Math.ceil((Math.max(endMs(t), Date.now()) + mins * MIN) / MIN) * MIN; }

  // تنفيذ التأجيل: النهاية الجديدة = (النهاية الحالية أو الآن – الأكبر) + المدة
  function snoozeTask(id, mins, via) {
    var t = findTask(id);
    mins = Math.round(mins);
    if (!t || !isOpen(t) || !(mins >= 1) || mins > SNZ_MAX) return false;
    var from = { date: t.endDate, time: t.endTime || '23:59' };
    var ne = newEndFor(t, mins), to = dtAt(ne), n = Date.now();
    t.snoozes = t.snoozes || [];
    t.snoozes.push({ at: n, mins: mins, via: via || 'manual', fromEnd: from, toEnd: to });
    t.endDate = to.date; t.endTime = to.time;
    t.n = t.n || {};
    t.n.end = 0;
    t.n.soon = t.remind && n >= ne - t.remind * MIN ? 1 : 0; // لو التذكير القديم عدّى، نستنى الانتهاء بس
    t.ring = '';
    pushNotif('fa-clock-rotate-left', 'ember', 'تم مد فترة المهمة إلى فترة إضافية', '«' + t.title + '» + ' + snzTxt(mins));
    save(); afterTaskChange();
    return true;
  }
  function cancelTask(id) {
    var t = findTask(id);
    if (!t || t.done) return;
    t.canceled = true; t.canceledAt = Date.now(); t.ring = '';
    pushNotif('fa-ban', 'red', 'تم إلغاء مهمة', t.title);
    toast('تم إلغاء المهمة');
    save(); afterTaskChange();
  }
  function restoreTask(id) {
    var t = findTask(id);
    if (!t) return;
    t.canceled = false; t.canceledAt = null;
    flagPast(t);
    toast('تمت استعادة المهمة');
    save(); afterTaskChange();
  }
  function afterTaskChange() {
    renderNav();
    if (page === 'tasks') renderTasks();
    if (page === 'home') renderHome();
    ensureAlarm();
  }

  /* ----- اختيار مدة التأجيل (دقائق / ساعات / أيام) – مشترك بين المنبّه وسجل التأجيلات ----- */
  function snoozePickerHtml(t) {
    return '<div class="snz-pick">' +
      '<div class="snz-chips">' + SNZ_QUICK.map(function (c) { return '<button type="button" class="snz-chip" data-snz-min="' + c[0] + '">' + c[1] + '</button>'; }).join('') + '</div>' +
      '<div class="snz-custom"><input type="number" min="1" step="1" inputmode="numeric" class="field snz-num" placeholder="مدة أخرى" aria-label="مدة التأجيل" />' +
      '<select class="field snz-unit" aria-label="الوحدة"><option value="m">دقائق</option><option value="h">ساعات</option><option value="d">أيام</option></select>' +
      '<button type="button" class="btn-primary snz-go">تأجيل</button></div>' +
      '<p class="snz-prev t-sub" aria-live="polite"></p></div>';
  }
  function bindSnoozePicker(root, t, cb) {
    var num = $('.snz-num', root), unit = $('.snz-unit', root), prev = $('.snz-prev', root);
    function val() {
      var v = parseFloat(num.value);
      if (!isFinite(v) || v <= 0) return 0;
      return Math.round(v * SNZ_UNIT[unit.value]);
    }
    function upd() {
      var m = val();
      if (!num.value) { prev.textContent = ''; prev.style.color = ''; return; }
      if (!m) { prev.textContent = 'اكتب رقمًا أكبر من صفر'; prev.style.color = '#dc2626'; return; }
      if (m > SNZ_MAX) { prev.textContent = 'الحد الأقصى سنة واحدة'; prev.style.color = '#dc2626'; return; }
      var ne = dtAt(newEndFor(t, m));
      prev.style.color = ''; prev.textContent = 'ستنتهي المهمة: ' + absStamp(ne.date, ne.time) + ' (مدّ ' + snzTxt(m) + ')';
    }
    num.addEventListener('input', upd); unit.addEventListener('change', upd);
    $$('[data-snz-min]', root).forEach(function (b) { b.addEventListener('click', function () { cb(parseInt(b.getAttribute('data-snz-min'), 10)); }); });
    $('.snz-go', root).addEventListener('click', function () {
      var m = val();
      if (!m || m > SNZ_MAX) { upd(); if (!num.value) { prev.textContent = 'اكتب مدة التأجيل أولًا'; prev.style.color = '#dc2626'; } num.focus(); return; }
      cb(m);
    });
  }

  /* ----- المنبّه المستمر (شاشة كاملة) ----- */
  var alarmUI = { id: null, mode: 'main' }, alarmTimer = null;
  function ringing() { return state.tasks.filter(function (t) { return isOpen(t) && t.ring; }).sort(function (a, b) { return endMs(a) - endMs(b); }); }
  function alarmTimeHtml(t) {
    var n = Date.now(), e = endMs(t);
    return n > e ? '<i class="fa-solid fa-triangle-exclamation me-1"></i>انتهت منذ ' + durTxt(n - e) : '<i class="fa-regular fa-clock me-1"></i>متبقي ' + durTxt(e - n);
  }
  function ringOnce() {
    var l = ringing();
    if (!l.length) return stopAlarm();
    playSound(l[0].ring === 'end' ? 'expired' : 'soon');
  }
  function stopAlarm() {
    if (alarmTimer) { clearInterval(alarmTimer); alarmTimer = null; }
    var h = $('#alarm');
    if (h) { h.id = ''; h.classList.remove('show'); setTimeout(function () { h.remove(); }, 220); }
    alarmUI = { id: null, mode: 'main' };
  }
  function ensureAlarm() {
    var list = ringing();
    if (!list.length) { if ($('#alarm') || alarmTimer) stopAlarm(); return; }
    if (!phone) phone = $('.phone');
    if (!phone) return;
    var cur = list.filter(function (t) { return t.id === alarmUI.id; })[0] || list[0];
    var host = $('#alarm');
    if (!host || alarmUI.id !== cur.id || host.getAttribute('data-n') !== String(list.length)) {
      if (alarmUI.id !== cur.id) alarmUI.mode = 'main';
      renderAlarm(cur, list.length);
    } else {
      var tm = $('#alarmTime'); if (tm) tm.innerHTML = alarmTimeHtml(cur);
    }
    if (!alarmTimer) { ringOnce(); alarmTimer = setInterval(ringOnce, 3000); }
  }
  function renderAlarm(t, count) {
    var host = $('#alarm');
    if (!host) {
      host = document.createElement('div'); host.id = 'alarm'; host.className = 'alarm';
      host.setAttribute('role', 'alertdialog'); host.setAttribute('aria-modal', 'true');
      phone.appendChild(host);
      requestAnimationFrame(function () { host.classList.add('show'); });
    }
    alarmUI.id = t.id;
    host.setAttribute('data-n', String(count));
    var end = t.ring === 'end', zs = (t.snoozes || []).length, id = t.id, body;
    var head = '<div class="alarm-bell' + (end ? ' alarm-bell-red' : '') + '"><i class="fa-solid ' + (end ? 'fa-bell' : 'fa-hourglass-half') + '"></i></div>' +
      '<p class="alarm-kind">' + (end ? 'انتهى وقت المهمة' : 'المهمة توشك على الانتهاء') + '</p>' +
      '<h2 class="alarm-title">' + esc(t.title) + '</h2>' +
      '<p id="alarmTime" class="alarm-time">' + alarmTimeHtml(t) + '</p>' +
      (zs ? '<p class="alarm-sub"><i class="fa-solid fa-clock-rotate-left me-1"></i>سبق مدّ فترتها ' + (zs === 1 ? 'مرة واحدة' : zs === 2 ? 'مرتين' : zs + (zs <= 10 ? ' مرات' : ' مرة')) + '</p>' : '') +
      (count > 1 ? '<p class="alarm-more">+' + (count - 1) + ' ' + (count === 2 ? 'مهمة أخرى' : 'مهام أخرى') + ' تنتظر</p>' : '');
    if (alarmUI.mode === 'snooze') {
      body = '<p class="alarm-q">اختر مدة التأجيل</p><div id="alPick" class="alarm-pick">' + snoozePickerHtml(t) + '</div>' +
        '<button id="alBack" class="alarm-btn alarm-ghost">رجوع</button>';
    } else if (alarmUI.mode === 'cancel') {
      body = '<p class="alarm-q">هل تريد إلغاء هذه المهمة؟</p>' +
        '<button id="alCancelYes" class="alarm-btn alarm-no">نعم، إلغاء المهمة</button><button id="alBack" class="alarm-btn alarm-ghost">لا، رجوع</button>';
    } else {
      body = '<button id="alDone" class="alarm-btn alarm-ok"><i class="fa-solid fa-check me-2"></i>تم الإنجاز</button>' +
        '<button id="alSnz" class="alarm-btn alarm-snz"><i class="fa-solid fa-clock-rotate-left me-2"></i>تأجيل</button>' +
        '<button id="alCancel" class="alarm-btn alarm-no"><i class="fa-solid fa-ban me-2"></i>إلغاء المهمة</button>';
    }
    host.innerHTML = '<div class="alarm-card">' + head + body + '</div>';
    var on = function (sel, fn) { var el = $(sel, host); if (el) el.addEventListener('click', fn); };
    on('#alDone', function () { setDone(id, true); });
    on('#alSnz', function () { alarmUI.mode = 'snooze'; renderAlarm(t, count); });
    on('#alCancel', function () {
      confirmBox({ title: 'إلغاء المهمة', msg: 'المهمة «' + t.title + '» هتتلغي وهيوقف المنبّه. تقدر تستعيدها من قسم المهام الملغاة.', ok: 'نعم، ألغِ المهمة', cancel: 'رجوع', tone: 'warn', icon: 'fa-ban' }, function () { cancelTask(id); });
    });
    on('#alCancelYes', function () { alarmUI.mode = 'main'; cancelTask(id); });
    on('#alBack', function () { alarmUI.mode = 'main'; renderAlarm(t, count); });
    if (alarmUI.mode === 'snooze') {
      bindSnoozePicker($('#alPick', host), t, function (m) {
        alarmUI.mode = 'main';
        if (snoozeTask(id, m, 'alarm')) toast('تم التأجيل ' + snzTxt(m));
      });
    }
  }

  /* ----- سجل التأجيلات + إضافة فترات أخرى ----- */
  function snzListHtml(t) {
    var rows = (t.snoozes || []).map(function (z, i) { return { z: z, no: i + 1 }; }).reverse();
    var pg = paginate('snz-' + t.id, rows, 4, function () { drawSnzList(t.id); });
    return (pg.items.map(function (r) {
      var z = r.z, f = z.fromEnd || {}, to = z.toEnd || {};
      return '<li class="snz-row"><span class="snz-no">' + r.no + '</span><div class="min-w-0 flex-1">' +
        '<p class="text-[14px] font-extrabold text-navy">مُدّت ' + esc(snzTxt(z.mins)) + '</p>' +
        '<p class="t-sub">' + esc(atStamp(z.at)) + ' · ' + (VIA_TXT[z.via] || VIA_TXT.manual) + '</p>' +
        '<p class="t-sub">من ' + esc(absStamp(f.date, f.time)) + ' إلى ' + esc(absStamp(to.date, to.time)) + '</p></div></li>';
    }).join('') || '<li class="t-sub py-2">لا توجد تأجيلات لهذه المهمة بعد.</li>') + (pg.html ? '<li>' + pg.html + '</li>' : '');
  }
  function drawSnzList(id) {
    var t = findTask(id), el = $('#snzList');
    if (t && el) el.innerHTML = snzListHtml(t);
  }
  function snoozeSheet(id) {
    var t = findTask(id);
    if (!t) return closeSheet();
    route.viewId = id;
    var zs = t.snoozes || [], open = isOpen(t);
    var wrap = openSheet(
      '<h3 class="sheet-title"><i class="fa-solid fa-clock-rotate-left me-2 text-ember"></i>سجل التأجيلات</h3>' +
      '<p class="mt-1 text-[14px] font-bold text-royal" style="overflow-wrap:anywhere">' + esc(t.title) + '</p>' +
      (zs.length ? '<div class="snz-sum"><p class="font-extrabold">تم مد فترة المهمة إلى فترة إضافية</p>' +
        '<p class="mt-1 text-[13px]">عدد مرات المد: <b>' + zs.length + '</b> · إجمالي المد: <b>' + esc(snzTxt(snzTotal(t))) + '</b></p>' +
        '<p class="mt-1 text-[13px]">الموعد الأصلي: ' + esc(absStamp(zs[0].fromEnd.date, zs[0].fromEnd.time)) + '</p>' +
        '<p class="text-[13px]">الموعد الحالي: ' + esc(absStamp(t.endDate, t.endTime || '23:59')) + '</p></div>' : '') +
      '<ul id="snzList" class="mt-3 space-y-2">' + snzListHtml(t) + '</ul>' +
      (open ? '<h4 class="label !mt-5">إضافة فترة أخرى</h4><div id="snzAdd">' + snoozePickerHtml(t) + '</div>' : '<p class="t-sub mt-4">لا يمكن إضافة فترات لمهمة ' + (t.done ? 'منتهية' : 'ملغاة') + '.</p>') +
      '<button id="snzBack" class="btn-outline mt-5 w-full">رجوع للمهمة</button>'
    );
    $('#snzBack', wrap).addEventListener('click', function () { taskView(id, false); });
    if (open) {
      bindSnoozePicker($('#snzAdd', wrap), t, function (m) {
        if (snoozeTask(id, m, 'manual')) { toast('تمت إضافة فترة ' + snzTxt(m)); snoozeSheet(id); }
      });
    }
  }

  /* ----- Pagination عام: يُستخدم في كل القوائم الطويلة (الطباعة دايمًا بالبيانات كاملة) ----- */
  var PG = {}, PGFN = {};
  function pgNums(p, pages) {
    if (pages <= 7) { var a = []; for (var i = 1; i <= pages; i++) a.push(i); return a; }
    var s = { 1: 1, 2: 1 }; s[pages] = 1; s[pages - 1] = 1; s[p - 1] = 1; s[p] = 1; s[p + 1] = 1;
    var out = [], last = 0;
    Object.keys(s).map(Number).filter(function (x) { return x >= 1 && x <= pages; }).sort(function (a, b) { return a - b; }).forEach(function (x) {
      if (last && x - last > 1) out.push(0);
      out.push(x); last = x;
    });
    return out;
  }
  // key: اسم القائمة | items: كل العناصر | size: عدد العناصر في الصفحة | rerender: دالة إعادة الرسم
  // opts.token: لو اتغيّر (فلتر/بحث) الصفحة ترجع للأولى | opts.sizes: خيارات "عدد الصفوف"
  function paginate(key, items, size, rerender, opts) {
    opts = opts || {};
    var st = PG[key];
    if (!st) st = PG[key] = { p: 1, size: size, tok: opts.token == null ? '' : String(opts.token) };
    if (opts.token != null && st.tok !== String(opts.token)) { st.tok = String(opts.token); st.p = 1; }
    var total = items.length, pages = Math.max(1, Math.ceil(total / st.size));
    if (st.p > pages) st.p = pages;
    if (st.p < 1) st.p = 1;
    PGFN[key] = rerender;
    var from = (st.p - 1) * st.size, to = Math.min(total, from + st.size), html = '';
    if (pages > 1 || (opts.sizes && total > opts.sizes[0])) {
      html = '<nav class="pg" data-pgkey="' + esc(key) + '" aria-label="التنقل بين الصفحات"><div class="pg-btns">' +
        '<button type="button" class="pg-b" data-pg="prev"' + (st.p === 1 ? ' disabled' : '') + ' aria-label="الصفحة السابقة"><i class="fa-solid fa-chevron-right"></i></button>' +
        pgNums(st.p, pages).map(function (x) { return x ? '<button type="button" class="pg-b' + (x === st.p ? ' is-on' : '') + '" data-pg="' + x + '"' + (x === st.p ? ' aria-current="page"' : '') + '>' + x + '</button>' : '<span class="pg-gap">…</span>'; }).join('') +
        '<button type="button" class="pg-b" data-pg="next"' + (st.p === pages ? ' disabled' : '') + ' aria-label="الصفحة التالية"><i class="fa-solid fa-chevron-left"></i></button></div>' +
        '<div class="pg-foot"><span class="pg-info">' + (total ? (from + 1) + '–' + to + ' من ' + total : '0') + '</span>' +
        (opts.sizes ? '<label class="pg-sz">الصفوف <select data-pgsize aria-label="عدد الصفوف في الصفحة">' + opts.sizes.map(function (z) { return '<option value="' + z + '"' + (z === st.size ? ' selected' : '') + '>' + z + '</option>'; }).join('') + '</select></label>' : '') +
        '</div></nav>';
    }
    return { items: items.slice(from, to), html: html, page: st.p, pages: pages, from: from, to: to, total: total };
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-pg]');
    if (!b || b.disabled) return;
    var nav = b.closest('[data-pgkey]'), k = nav && nav.getAttribute('data-pgkey'), st = k && PG[k];
    if (!st) return;
    var v = b.getAttribute('data-pg');
    st.p = v === 'prev' ? st.p - 1 : v === 'next' ? st.p + 1 : parseInt(v, 10);
    if (PGFN[k]) PGFN[k]();
  });
  document.addEventListener('change', function (e) {
    var s = e.target.closest && e.target.closest('[data-pgsize]');
    if (!s) return;
    var nav = s.closest('[data-pgkey]'), k = nav && nav.getAttribute('data-pgkey'), st = k && PG[k];
    if (!st) return;
    st.size = parseInt(s.value, 10) || st.size; st.p = 1;
    if (PGFN[k]) PGFN[k]();
  });

  function startTicker() {
    if (tickStarted) return;
    tickStarted = true;
    setInterval(liveTick, 15000);
  }

  /* ---------- الطباعة ---------- */
  function printDoc(title, bodyHtml) {
    var a = $('#printArea');
    if (!a) { a = document.createElement('div'); a.id = 'printArea'; document.body.appendChild(a); }
    a.innerHTML = '<div class="pr-head"><span>إنجازي – Engazy</span><span>' + esc(dateStr) + '</span></div>' +
      '<h1>' + esc(title) + '</h1>' + bodyHtml +
      '<p class="pr-foot">تمت الطباعة من تطبيق إنجازي – Engazy</p>';
    setTimeout(function () { window.print(); }, 80);
  }
  function prRows(rows) {
    return rows.map(function (r) {
      return '<div class="pr-row"><div class="pr-label">' + esc(r[0]) + '</div><div>' + esc(r[1]) + '</div></div>';
    }).join('');
  }

  function printTask(t) {
    var s = statusOf(t);
    printDoc(t.title, prRows([
      ['الحالة', STATUS_TXT[s]],
      ['التصنيف', CATS[catOf(t)].n],
      ['الأولوية', PRI[t.priority] || '—'],
      ['البداية', fullDate(t.startDate) + (t.startTime ? ' · ' + fmtTime(t.startTime, true) : '')],
      ['النهاية', fullDate(t.endDate) + (t.endTime ? ' · ' + fmtTime(t.endTime, true) : '')],
      ['المتبقي', s === 'done' ? 'تم الإنجاز' : remainText(t)],
      ['التذكير', remindTxt(t.remind)],
      ['المكان', t.place || '—'],
      ['الملاحظات', t.notes || '—']
    ].concat((t.snoozes || []).length ? [['تم مد فترة المهمة إلى فترة إضافية', t.snoozes.length + ' مرة · إجمالي ' + snzTxt(snzTotal(t))]].concat(t.snoozes.map(function (z, i) {
      return ['التأجيل رقم ' + (i + 1), 'مُدّت ' + snzTxt(z.mins) + ' (' + atStamp(z.at) + ' · ' + (VIA_TXT[z.via] || VIA_TXT.manual) + ') من ' + absStamp(z.fromEnd.date, z.fromEnd.time) + ' إلى ' + absStamp(z.toEnd.date, z.toEnd.time)];
    })) : [])));
  }
  function printAllTasks() {
    function table(list) {
      if (!list.length) return '<p>لا توجد مهام.</p>';
      return '<table class="pr-table"><thead><tr><th>#</th><th>المهمة</th><th>التصنيف</th><th>البداية</th><th>النهاية</th><th>الأولوية</th><th>الحالة</th></tr></thead><tbody>' +
        list.map(function (t, i) {
          return '<tr><td>' + (i + 1) + '</td><td>' + esc(t.title) + '</td><td>' + CATS[catOf(t)].n + '</td><td>' + esc(stamp(t.startDate, t.startTime, true)) +
            '</td><td>' + esc(stamp(t.endDate, t.endTime, true)) + '</td><td>' + (PRI[t.priority] || '—') + '</td><td>' + STATUS_TXT[statusOf(t)] + ((t.snoozes || []).length ? '<br><small>تم مد فترة المهمة (' + t.snoozes.length + ' مرة · ' + esc(snzTxt(snzTotal(t))) + ')</small>' : '') + '</td></tr>';
        }).join('') + '</tbody></table>';
    }
    var open = sortTasks(state.tasks.filter(isOpen));
    var done = state.tasks.filter(function (t) { return t.done; });
    var canc = state.tasks.filter(function (t) { return t.canceled && !t.done; });
    printDoc('قائمة المهام', '<h2>المهام الجارية (' + open.length + ')</h2>' + table(open) + '<h2>المهام المنتهية (' + done.length + ')</h2>' + table(done) +
      (canc.length ? '<h2>المهام الملغاة (' + canc.length + ')</h2>' + table(canc) : ''));
  }

  /* ---------- الشريط السفلي ---------- */
  function renderNav() {
    var nav = $('#nav');
    if (!nav) return;
    var items = [
      { id: 'home', href: href('home'), icon: 'fa-solid fa-house', label: 'الرئيسية' },
      { id: 'tasks', href: href('tasks'), icon: 'fa-solid fa-calendar-days', label: 'المهام' },
      { id: 'reports', href: href('reports'), icon: 'fa-solid fa-chart-pie', label: 'التقارير' },
      { id: 'profile', href: href('profile'), icon: 'fa-regular fa-circle-user', label: 'الملف الشخصي' }
    ];
    var unread = state.notifs.some(function (n) { return !n.read; });
    nav.innerHTML = items.map(function (it, idx) {
      var on = it.id === page;
      return (idx === 2 ? '<button id="navAdd" class="nav-add" aria-label="إنشاء جديد" aria-haspopup="dialog"><i class="fa-solid fa-plus"></i></button>' : '') + '<a href="' + it.href + '" class="nav-btn' + (on ? ' is-on' : '') + '" aria-label="' + it.label + '"' + (on ? ' aria-current="page"' : '') + '>' +
        '<i class="' + it.icon + '"></i>' +
        '</a>';
    }).join('');
    // جرس الإشعارات في هيدر الرئيسية والمهام
    $$('[data-bell]').forEach(function (b) {
      b.setAttribute('href', href('notifications'));
      b.innerHTML = '<i class="fa-solid fa-bell"></i>' + (unread ? '<span class="nav-dot"></span>' : '');
    });
  }

  function renderCommon() {
    $$('[data-name]').forEach(function (el) { el.textContent = state.user.name || 'أحمد'; });
    $$('[data-avatar]').forEach(function (el) { el.innerHTML = avatarHtml(); });
    var t = $('#today'); if (t) t.textContent = dateStr;
    var d = $('#day'); if (d) d.textContent = dayStr;
    var g = $('#greet'); if (g) g.textContent = greeting();
    renderNav();
  }

  /* =====================================================
     صفحة الترحيب (الساعة الكبيرة)
     ===================================================== */
  function initWelcome() {
    var slides = [
      ['أهلاً بك', 'إنجازي – Engazy: سجّل مهامك بتاريخ البداية والنهاية، وهنفكّرك بصوت وإشعار.'],
      ['صنّف', 'ضع كل مهمة في تصنيفها: عمل، دراسة، بيت، صحة، مالية وغيرها.'],
      ['تابع', 'شوف كام يوم وكام ساعة فاضلة، والمهمة اللي فاتت بتتلوّن بالأحمر.'],
      ['أنجز', 'اطبع أي مهمة أو القائمة كاملة، وخلّص مهامك واحدة واحدة.']
    ];
    var idx = 0, timer;
    var title = $('#wTitle'), text = $('#wText'), dots = $$('#dots .dot');

    function go(i) {
      idx = (i + slides.length) % slides.length;
      title.textContent = slides[idx][0];
      text.textContent = slides[idx][1];
      dots.forEach(function (d, k) { d.classList.toggle('is-on', k === idx); });
    }
    function auto() { clearInterval(timer); timer = setInterval(function () { go(idx + 1); }, 4500); }

    dots.forEach(function (d) {
      d.addEventListener('click', function () { go(parseInt(d.dataset.i, 10)); auto(); });
    });
    // سحب على الشاشة (في العربي: السحب لليمين = التالي)
    var x0 = null;
    phone.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
    phone.addEventListener('touchend', function (e) {
      if (x0 === null) return;
      var dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 50) { go(idx + (dx > 0 ? 1 : -1)); auto(); }
      x0 = null;
    });
    auto();
    cleanups.push(function () { clearInterval(timer); });

    /* ----- الساعة ----- */
    var NS = 'http://www.w3.org/2000/svg', CX = 195, CY = 230;
    var ticks = $('#ticks'), nums = $('#nums');
    function el(name, attrs) {
      var n = document.createElementNS(NS, name);
      for (var k in attrs) n.setAttribute(k, attrs[k]);
      return n;
    }
    for (var i = 0; i < 60; i++) {
      var big = i % 5 === 0, a = i * 6 * Math.PI / 180;
      var r1 = 104, r2 = big ? 94 : 99;
      ticks.appendChild(el('line', {
        x1: CX + r1 * Math.sin(a), y1: CY - r1 * Math.cos(a), x2: CX + r2 * Math.sin(a), y2: CY - r2 * Math.cos(a),
        stroke: big ? '#2f6fd0' : '#b9d3f5', 'stroke-width': big ? 3.5 : 1.5, 'stroke-linecap': 'round'
      }));
    }
    for (var n = 1; n <= 12; n++) {
      var an = n * 30 * Math.PI / 180;
      var t = el('text', { x: CX + 73 * Math.sin(an), y: CY - 73 * Math.cos(an) });
      t.textContent = n;
      nums.appendChild(t);
    }
    var hH = $('#hHand'), mH = $('#mHand'), sH = $('#sHand'), dT = $('#dTime'), dD = $('#dDate');
    dD.textContent = dayStr + '، ' + dateStr;
    function rot(elm, deg) { elm.setAttribute('transform', 'rotate(' + deg.toFixed(2) + ' ' + CX + ' ' + CY + ')'); }
    var raf;
    function tick() {
      var d = new Date();
      var sec = d.getSeconds() + d.getMilliseconds() / 1000, min = d.getMinutes() + sec / 60, hr = d.getHours() % 12 + min / 60;
      rot(sH, sec * 6); rot(mH, min * 6); rot(hH, hr * 30);
      var hh = d.getHours() % 12 || 12;
      dT.textContent = hh + ':' + pad(d.getMinutes()) + ' ' + (d.getHours() < 12 ? 'ص' : 'م');
      raf = requestAnimationFrame(tick);
    }
    tick();
    cleanups.push(function () { cancelAnimationFrame(raf); });
  }

  /* =====================================================
     الرئيسية
     ===================================================== */
  function ring(pct) {
    var r = 19, c = 2 * Math.PI * r, off = c * (1 - pct / 100);
    return '<svg width="46" height="46" viewBox="0 0 46 46" aria-hidden="true">' +
      '<circle cx="23" cy="23" r="' + r + '" fill="none" stroke="rgba(255,255,255,.45)" stroke-width="2.5"/>' +
      '<circle cx="23" cy="23" r="' + r + '" fill="none" stroke="var(--ring)" stroke-width="2.5" stroke-linecap="round" ' +
      'stroke-dasharray="' + c.toFixed(1) + '" stroke-dashoffset="' + off.toFixed(1) + '" transform="rotate(-90 23 23)"/></svg>';
  }

  function renderHome() {
    if (!$('#projects')) return; // بنستدعيها من أي صفحة (مثلًا بعد الإنشاء من الزر الأوسط)
    renderUrgent();
    renderHabits();
    $('#projects').innerHTML = state.projects.map(function (p) {
      var done = p.tasks.filter(function (t) { return t.done; }).length;
      return '<button class="proj proj-' + p.color + '" data-proj="' + p.id + '">' +
        '<span class="blob -left-8 top-20 h-24 w-24"></span><span class="blob -right-6 -top-6 h-20 w-20"></span>' +
        '<span class="relative block px-4 pt-3.5 text-start">' +
        '<span class="block text-[17px] font-extrabold leading-[1.2]">' + esc(p.title) + '</span>' +
        '<span class="mt-1 block text-[10px] opacity-80">' + esc(p.desc) + '</span>' +
        '<span class="mt-3 block text-[17px] font-extrabold">' + tasksWord(p.tasks.length) + '</span>' +
        '<span class="block text-[10px] opacity-80">تم إنجاز ' + done + '</span></span>' +
        '<span class="proj-strip"><i></i><i></i><i></i><i></i></span></button>';
    }).join('') +
      '<button id="addProj" class="flex h-[192px] w-[110px] shrink-0 flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-brand text-brand transition active:scale-95">' +
      '<i class="fa-solid fa-folder-plus text-[26px]"></i><span class="text-[13px] font-bold">مشروع جديد</span></button>';

    $('#personal').innerHTML = state.personal.length ? state.personal.map(function (p) {
      return '<button class="ptask ptask-' + p.color + '" data-ptask="' + p.id + '">' +
        '<span class="ptask-ring">' + ring(p.progress) + '<span>' + p.progress + '%</span></span>' +
        '<span class="flex-1 self-center px-4"><span class="block text-[15px] font-bold leading-tight text-slate2">' + esc(p.title) + '</span>' +
        '<span class="mt-0.5 block text-[11px] text-slate2/70">' + esc(p.desc) + '</span></span></button>';
    }).join('') : '<p class="py-6 text-center text-[14px] text-royal/60">لا توجد مهام شخصية بعد. اضغط + لإضافة مهمة.</p>';
  }

  function projectSheet(id) {
    var p = state.projects.filter(function (x) { return x.id === id; })[0];
    if (!p) return closeSheet();
    var done = p.tasks.filter(function (t) { return t.done; }).length;
    var pct = p.tasks.length ? Math.round(done / p.tasks.length * 100) : 0;
    var wrap = openSheet(
      '<h3 class="sheet-title">' + esc(p.title) + '</h3>' +
      '<p class="mt-1 text-[13px] text-slate2">تم إنجاز ' + done + ' من ' + tasksWord(p.tasks.length) + ' · ' + pct + '%</p>' +
      '<div class="bar"><i style="width:' + pct + '%"></i></div>' +
      '<div class="mt-3 max-h-[250px] overflow-y-auto">' +
      (p.tasks.length ? p.tasks.map(function (t) {
        return '<button class="chk-row' + (t.done ? ' is-done' : '') + '" data-t="' + t.id + '"><span class="chk' + (t.done ? ' on' : '') + '"><i class="fa-solid fa-check"></i></span><span class="txt">' + esc(t.t) + '</span></button>';
      }).join('') : '<p class="py-4 text-center text-[13px] text-royal/60">لا توجد مهام في هذا المشروع. أضف أول مهمة.</p>') + '</div>' +
      '<form id="addT" class="mt-3 flex gap-2"><input class="field flex-1" maxlength="50" placeholder="أضف مهمة" /><button class="btn-primary">إضافة</button></form>' +
      '<div class="mt-3 grid grid-cols-2 gap-3"><button id="prP" class="btn-outline"><i class="fa-solid fa-print me-2"></i>طباعة</button>' +
      '<button id="delP" class="btn-danger">حذف المشروع</button></div>'
    );
    $$('[data-t]', wrap).forEach(function (b) {
      b.addEventListener('click', function () {
        var t = p.tasks.filter(function (x) { return x.id === b.dataset.t; })[0];
        t.done = !t.done;
        if (t.done && p.tasks.every(function (x) { return x.done; })) {
          pushNotif('fa-trophy', 'leaf', 'تم إنجاز المشروع', p.title);
          toast('تم إنجاز المشروع 🎉');
        }
        save(); renderHome(); renderNav(); projectSheet(id);
      });
    });
    $('#addT', wrap).addEventListener('submit', function (e) {
      e.preventDefault();
      var v = $('input', e.target).value.trim();
      if (!v) return;
      p.tasks.push({ id: uid(), t: v, done: false });
      save(); renderHome(); projectSheet(id);
    });
    $('#prP', wrap).addEventListener('click', function () {
      printDoc(p.title, '<h2>' + tasksWord(p.tasks.length) + ' · تم إنجاز ' + done + ' (' + pct + '%)</h2>' +
        '<table class="pr-table"><thead><tr><th>#</th><th>المهمة</th><th>الحالة</th></tr></thead><tbody>' +
        p.tasks.map(function (t, i) { return '<tr><td>' + (i + 1) + '</td><td>' + esc(t.t) + '</td><td>' + (t.done ? 'منجزة ✓' : 'جارية') + '</td></tr>'; }).join('') +
        '</tbody></table>');
    });
    $('#delP', wrap).addEventListener('click', function () {
      confirmBox({ title: 'حذف المشروع', msg: 'هيتحذف مشروع «' + p.title + '» بكل مهامه (' + tasksWord(p.tasks.length) + ') نهائيًا.', ok: 'نعم، احذف المشروع', cancel: 'إلغاء', icon: 'fa-trash-can' }, function () {
        state.projects = state.projects.filter(function (x) { return x.id !== id; });
        save(); renderHome(); closeSheet(); toast('تم حذف المشروع');
      });
    });
  }

  function newProjectSheet() {
    var names = { green: 'أخضر', blue: 'أزرق', orange: 'برتقالي' };
    var wrap = openSheet(
      '<h3 class="sheet-title">مشروع جديد</h3>' +
      '<form id="pForm"><label class="label" for="pTitle">العنوان</label>' +
      '<input id="pTitle" class="field" maxlength="30" placeholder="اسم المشروع" />' +
      '<label class="label">اللون</label><div class="flex gap-3" id="pColors">' +
      ['green', 'blue', 'orange'].map(function (c, i) {
        var bg = { green: '#3ec878', blue: '#1896ba', orange: '#f0732e' }[c];
        return '<button type="button" data-c="' + c + '" class="h-10 w-10 rounded-full border-4 ' + (i === 0 ? 'border-navy' : 'border-white shadow') + '" style="background:' + bg + '" aria-label="' + names[c] + '"></button>';
      }).join('') + '</div>' +
      '<button class="btn-primary mt-5 w-full">إنشاء المشروع</button></form>'
    );
    var color = 'green';
    $$('#pColors button', wrap).forEach(function (b) {
      b.addEventListener('click', function () {
        color = b.dataset.c;
        $$('#pColors button', wrap).forEach(function (x) {
          x.classList.toggle('border-navy', x === b); x.classList.toggle('border-white', x !== b); x.classList.toggle('shadow', x !== b);
        });
      });
    });
    $('#pForm', wrap).addEventListener('submit', function (e) {
      e.preventDefault();
      var v = $('#pTitle', wrap).value.trim();
      if (!v) return toast('اكتب اسم المشروع');
      state.projects.push({ id: uid(), title: v, desc: 'وصف مختصر للمشروع', color: color, tasks: [] });
      pushNotif('fa-bolt', 'ember', 'تم إنشاء مشروع جديد', v);
      save(); renderHome(); renderNav(); closeSheet(); toast('تم إنشاء المشروع');
    });
  }

  function personalSheet(id) {
    var p = id ? state.personal.filter(function (x) { return x.id === id; })[0] : null;
    var d = p || { title: '', desc: '', progress: 0, color: state.personal.length % 2 ? 'blue' : 'green' };
    var wrap = openSheet(
      '<h3 class="sheet-title">' + (p ? 'تعديل المهمة' : 'مهمة شخصية جديدة') + '</h3>' +
      '<form id="pf"><label class="label" for="pfT">العنوان</label><input id="pfT" class="field" maxlength="40" value="' + esc(d.title) + '" placeholder="ما الذي تريد إنجازه؟" />' +
      '<label class="label" for="pfD">التفاصيل</label><input id="pfD" class="field" maxlength="60" value="' + esc(d.desc) + '" placeholder="وصف مختصر" />' +
      '<label class="label" for="pfP">نسبة الإنجاز: <span id="pfV" class="text-royal" dir="ltr">' + d.progress + '%</span></label>' +
      '<input id="pfP" type="range" min="0" max="100" step="5" value="' + d.progress + '" class="w-full accent-[#1896ba]" />' +
      '<button class="btn-primary mt-5 w-full">' + (p ? 'حفظ التعديلات' : 'إضافة المهمة') + '</button>' +
      (p ? '<div class="mt-3 grid grid-cols-2 gap-3"><button type="button" id="pfPrint" class="btn-outline"><i class="fa-solid fa-print me-2"></i>طباعة</button>' +
        '<button type="button" id="pfDel" class="btn-danger">حذف</button></div>' : '') + '</form>'
    );
    $('#pfP', wrap).addEventListener('input', function (e) { $('#pfV', wrap).textContent = e.target.value + '%'; });
    $('#pf', wrap).addEventListener('submit', function (e) {
      e.preventDefault();
      var title = $('#pfT', wrap).value.trim();
      if (!title) return toast('اكتب عنوانًا للمهمة');
      var prog = parseInt($('#pfP', wrap).value, 10);
      if (p) { p.title = title; p.desc = $('#pfD', wrap).value.trim(); p.progress = prog; }
      else state.personal.push({ id: uid(), title: title, desc: $('#pfD', wrap).value.trim(), progress: prog, color: d.color });
      if (p && prog === 100) { pushNotif('fa-circle-check', 'leaf', 'تم إنجاز مهمة', title); toast('أحسنت! تم إنجاز المهمة 🎉'); }
      save(); renderHome(); renderNav(); closeSheet();
    });
    if (p) {
      $('#pfPrint', wrap).addEventListener('click', function () {
        printDoc(p.title, prRows([['التفاصيل', p.desc || '—'], ['نسبة الإنجاز', p.progress + '%']]));
      });
      $('#pfDel', wrap).addEventListener('click', function () {
        confirmBox({ title: 'حذف المهمة الشخصية', msg: 'هتتحذف «' + p.title + '» نهائيًا.', ok: 'نعم، احذف', cancel: 'إلغاء', icon: 'fa-trash-can' }, function () {
          state.personal = state.personal.filter(function (x) { return x.id !== id; });
          save(); renderHome(); closeSheet(); toast('تم حذف المهمة');
        });
      });
    }
  }

  /* =====================================================
     العادات والروتين اليومي (صيام، صلاة، صدقات، ماء، دواء، رياضة…)
     كل عادة لها مواعيد يومية؛ كل موعد "خانة" بتتسجل تم أو إلغاء.
     المنبّه بيفضل شغال لحد ما تتصرف فيه، والدواء له أقراص وجرعات ومخزون.
     ===================================================== */
  var HC_COLORS = ['#16a6b6', '#7c5cd6', '#e0507a', '#1b7fc9', '#15935a', '#e08a2e', '#3a7bd5', '#c98f12', '#6b7a99', '#d946ef'];
  var WEEK_DAYS = [[6, 'سبت'], [0, 'أحد'], [1, 'اثنين'], [2, 'ثلاثاء'], [3, 'أربعاء'], [4, 'خميس'], [5, 'جمعة']];
  var FOOD = { any: 'في أي وقت', before: 'قبل الأكل', after: 'بعد الأكل', with: 'مع الأكل', empty: 'على الريق' };
  var MED_UNITS = {
    'قرص': ['قرص', 'قرص واحد', 'قرصان', 'أقراص', 'قرصًا'],
    'كبسولة': ['كبسولة', 'كبسولة واحدة', 'كبسولتان', 'كبسولات', 'كبسولة'],
    'ملعقة': ['ملعقة', 'ملعقة واحدة', 'ملعقتان', 'ملاعق', 'ملعقة'],
    'نقطة': ['نقطة', 'نقطة واحدة', 'نقطتان', 'نقاط', 'نقطة'],
    'حقنة': ['حقنة', 'حقنة واحدة', 'حقنتان', 'حقن', 'حقنة'],
    'جرعة': ['جرعة', 'جرعة واحدة', 'جرعتان', 'جرعات', 'جرعة'],
    'مل': null
  };
  var DOSE_CHIPS = [[0.25, '¼'], [0.5, '½'], [1, '1'], [1.5, '1½'], [2, '2'], [3, '3']];
  var hcatF = 'all', habitAlarmTimer = null, habitAlarmKey = null;

  function todayISO() { return isoDate(new Date()); }
  function findHabit(id) { return state.habits.filter(function (h) { return h.id === id; })[0]; }
  function findHCat(id) { return state.habitCats.filter(function (c) { return c.id === id; })[0] || state.habitCats[0] || HC_DEFAULTS[6]; }
  function hcOf(h) { return findHCat(h.cat); }
  function isMed(h) { return hcOf(h).type === 'med'; }
  function shade(hex, k) { // تغميق اللون (k من 0 إلى 1)
    var n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    return 'rgb(' + Math.round(r * (1 - k)) + ',' + Math.round(g * (1 - k)) + ',' + Math.round(b * (1 - k)) + ')';
  }
  function trimNum(n) { return String(Math.round(n * 100) / 100); }

  // نص الجرعة بالعربي: نصف قرص / قرص واحد / قرصان / 3 أقراص …
  function amountTxt(n, unit) {
    var u = MED_UNITS[unit];
    if (!u) return trimNum(n) + ' ' + (unit || 'مل');
    if (n === 0.25) return 'ربع ' + u[0];
    if (n === 0.5) return 'نصف ' + u[0];
    if (n === 1.5) return u[1] + ' ونصف';
    if (n === 1) return u[1];
    if (n === 2) return u[2];
    if (n === Math.floor(n)) return n + ' ' + (n <= 10 ? u[3] : u[4]);
    return trimNum(n) + ' ' + u[0];
  }
  function doseLine(h) {
    if (!isMed(h)) return '';
    return amountTxt(h.pills || 1, h.unit || 'قرص') + (h.food && h.food !== 'any' ? ' · ' + FOOD[h.food] : '');
  }
  function weekFactor(h) { return h.days && h.days.length ? h.days.length / 7 : 1; }
  function dailyUse(h) { return (h.pills || 1) * (h.times || []).length * weekFactor(h); }
  function stockDays(h) { return h.stock == null || !dailyUse(h) ? null : Math.floor(h.stock / dailyUse(h)); }
  function daysTxt(n) { return n === 0 ? 'أقل من يوم' : n === 1 ? 'يوم واحد' : n === 2 ? 'يومان' : n + (n <= 10 ? ' أيام' : ' يومًا'); }
  function daysSummary(h) {
    if (!h.days || !h.days.length || h.days.length === 7) return 'كل يوم';
    return WEEK_DAYS.filter(function (d) { return h.days.indexOf(d[0]) > -1; }).map(function (d) { return d[1]; }).join(' · ');
  }
  function habitOnDay(h, iso) {
    if (h.paused || !h.startDate || iso < h.startDate || (h.endDate && iso > h.endDate)) return false;
    return !h.days || !h.days.length || h.days.indexOf(parseISO(iso).getDay()) > -1;
  }
  function slotMs(d, t) { return toMs(d, t, '00:00'); }
  function logOf(hid, d, t) { return state.habitLogs.filter(function (l) { return l.h === hid && l.d === d && l.t === t; })[0]; }
  // حالة الخانة: done | skip | due (فات ميعادها وبترن) | later (لسه) | past (قديمة أو قبل ما تتسجل العادة)
  function slotState(h, d, t) {
    var l = logOf(h.id, d, t);
    if (l) return l.st;
    var ms = slotMs(d, t), n = Date.now();
    if (ms > n) return 'later';
    if (ms < (h.since || h.createdAt || 0) - 1000 || ms < n - 24 * HOUR) return 'past';
    return 'due';
  }
  function todaySlots() {
    var d = todayISO(), out = [];
    state.habits.forEach(function (h) {
      if (!habitOnDay(h, d)) return;
      (h.times || []).forEach(function (t) { out.push({ h: h, d: d, t: t, st: slotState(h, d, t) }); });
    });
    return out.sort(function (a, b) { return a.t < b.t ? -1 : a.t > b.t ? 1 : 0; });
  }
  function dueSlots() {
    var n = Date.now(), out = [], d0 = isoDate(new Date(n - 24 * HOUR)), d1 = todayISO();
    state.habits.forEach(function (h) {
      [d0, d1].forEach(function (d) {
        if (!habitOnDay(h, d)) return;
        (h.times || []).forEach(function (t) { if (slotState(h, d, t) === 'due') out.push({ h: h, d: d, t: t }); });
      });
    });
    return out.sort(function (a, b) { return slotMs(a.d, a.t) - slotMs(b.d, b.t); });
  }

  // تسجيل خانة: st = 'done' | 'skip' | null (إرجاع لحالة "لم يُسجَّل")
  function markSlot(hid, d, t, st) {
    var h = findHabit(hid);
    if (!h) return;
    var old = logOf(hid, d, t), med = isMed(h);
    if (old) {
      if (old.st === 'done' && med && h.stock != null) h.stock = Math.round((h.stock + (old.q || 0)) * 100) / 100; // نرجّع الأقراص
      state.habitLogs = state.habitLogs.filter(function (l) { return l !== old; });
    }
    if (st) {
      var q = st === 'done' && med ? (h.pills || 1) : 0;
      state.habitLogs.push({ h: hid, d: d, t: t, st: st, at: Date.now(), q: q });
      if (q && h.stock != null) {
        h.stock = Math.max(0, Math.round((h.stock - q) * 100) / 100);
        var left = stockDays(h);
        if (h.stock <= 0) { pushNotif('fa-box-open', 'red', 'خلص الدواء', 'مخزون «' + h.title + '» انتهى. جدّد العلبة وحدّث المخزون.'); toast('انتبه: مخزون الدواء خلص'); }
        else if (left != null && left <= 3 && !h.lowAlerted) { h.lowAlerted = true; pushNotif('fa-box-open', 'ember', 'الدواء قارب على الانتهاء', '«' + h.title + '» تكفي حوالي ' + daysTxt(left) + ' فقط.'); }
      }
    }
    save(); afterHabitChange();
  }
  function afterHabitChange() {
    renderNav();
    if (page === 'home') renderHome();
    ensureHabitAlarm();
  }

  /* ----- إحصاءات العادة: السلسلة + الالتزام + أسبوع ----- */
  function habitStats(h) {
    var today = todayISO(), streak = 0, best = 0, run = 0, sched = 0, done = 0, total = 0, i, d, tot, dn;
    state.habitLogs.forEach(function (l) { if (l.h === h.id && l.st === 'done') total++; });
    var stop = false;
    for (i = 0; i < 400; i++) {
      d = addDaysISO(today, -i);
      if (h.startDate && d < h.startDate) break;
      if (!habitOnDay(h, d)) continue;
      tot = (h.times || []).length;
      dn = (h.times || []).filter(function (t) { var l = logOf(h.id, d, t); return l && l.st === 'done'; }).length;
      if (i === 0 && dn < tot) continue; // النهارده لسه ما خلصش
      if (dn === tot && tot) { run++; if (!stop) streak = run; } else { stop = true; run = 0; }
      best = Math.max(best, run);
      if (i < 30) {
        (h.times || []).forEach(function (t) {
          var ms = slotMs(d, t);
          if (ms <= Date.now() && ms >= (h.since || h.createdAt || 0) - 1000) { sched++; var l = logOf(h.id, d, t); if (l && l.st === 'done') done++; }
        });
      }
    }
    return { streak: streak, adherence: sched ? Math.round(done / sched * 100) : null, total: total };
  }
  function weekStrip(h) {
    var out = [], today = todayISO();
    for (var i = 6; i >= 0; i--) {
      var d = addDaysISO(today, -i), on = habitOnDay(h, d), st = 'none';
      if (on) {
        var ts = h.times || [], dn = 0, sk = 0, lat = 0;
        ts.forEach(function (t) { var s = slotState(h, d, t); if (s === 'done') dn++; else if (s === 'skip') sk++; else if (s === 'later') lat++; });
        st = dn === ts.length ? 'all' : (dn || sk) ? 'part' : lat === ts.length ? 'later' : (d === today ? 'later' : 'miss');
      }
      out.push({ d: d, st: st, label: WEEK_DAYS.filter(function (w) { return w[0] === parseISO(d).getDay(); })[0][1].slice(0, 2) });
    }
    return out;
  }

  /* ----- المنبّه المميز للعادات: يفضل شغال لحد "تم" أو "إلغاء" ----- */
  function habitCheck() {
    var changed = false, d0 = isoDate(new Date(Date.now() - 4 * DAY));
    state.habits.forEach(function (h) {
      h.alerted = h.alerted || {};
      Object.keys(h.alerted).forEach(function (k) { if (k.slice(0, 10) < d0) { delete h.alerted[k]; changed = true; } });
    });
    dueSlots().forEach(function (x) {
      var k = x.d + '|' + x.t;
      if (x.h.alerted[k]) return;
      x.h.alerted[k] = 1; changed = true;
      var c = hcOf(x.h), med = c.type === 'med';
      var sub = med ? doseLine(x.h) + ' · الساعة ' + fmtTime(x.t, true) : c.name + ' · الساعة ' + fmtTime(x.t, true);
      pushNotif(c.icon, 'ember', (med ? 'حان موعد الدواء: ' : 'حان موعد: ') + x.h.title, sub);
      sysNotify((med ? 'موعد الدواء' : 'موعد العادة') + ' – إنجازي', x.h.title + ' · ' + sub, 'h' + x.h.id + k, true);
    });
    return changed;
  }
  function habitChime() {
    if (!state.settings.sound) return;
    try {
      tone(784, 0, 0.18, 'sine', 0.3); tone(988, 0.2, 0.18, 'sine', 0.3); tone(1175, 0.4, 0.18, 'sine', 0.3); tone(1568, 0.62, 0.45, 'sine', 0.3);
      if (navigator.vibrate && (!navigator.userActivation || navigator.userActivation.hasBeenActive)) navigator.vibrate([200, 100, 200, 100, 400]);
    } catch (e) {}
  }
  function stopHabitAlarm() {
    if (habitAlarmTimer) { clearInterval(habitAlarmTimer); habitAlarmTimer = null; }
    var h = $('#halarm');
    if (h) { h.id = ''; h.classList.remove('show'); setTimeout(function () { h.remove(); }, 220); }
    habitAlarmKey = null;
  }
  function ensureHabitAlarm() {
    var list = dueSlots();
    if (!list.length) { if ($('#halarm') || habitAlarmTimer) stopHabitAlarm(); return; }
    if (!phone) phone = $('.phone');
    if (!phone) return;
    var cur = list[0], key = cur.h.id + '|' + cur.d + '|' + cur.t + '|' + list.length;
    if (!$('#halarm') || habitAlarmKey !== key) { habitAlarmKey = key; renderHabitAlarm(cur, list.length); }
    else { var lt = $('#halLate'); if (lt) lt.textContent = lateTxt(cur); }
    if (!habitAlarmTimer) { habitChime(); habitAlarmTimer = setInterval(function () { if (dueSlots().length) habitChime(); else stopHabitAlarm(); }, 4000); }
  }
  function lateTxt(x) {
    var late = Date.now() - slotMs(x.d, x.t);
    return late < MIN ? 'الآن' : 'متأخر ' + durTxt(late);
  }
  function renderHabitAlarm(x, count) {
    var h = x.h, c = hcOf(h), med = c.type === 'med', st = habitStats(h), host = $('#halarm');
    if (!host) {
      host = document.createElement('div'); host.id = 'halarm'; host.className = 'halarm';
      host.setAttribute('role', 'alertdialog'); host.setAttribute('aria-modal', 'true'); host.setAttribute('aria-label', 'موعد ' + h.title);
      phone.appendChild(host);
      requestAnimationFrame(function () { host.classList.add('show'); });
    }
    host.style.background = 'radial-gradient(circle at 50% 14%, ' + c.color + ', ' + shade(c.color, 0.55) + ' 78%)';
    var stockLow = med && h.stock != null && (h.stock <= 0 || (stockDays(h) != null && stockDays(h) <= 3));
    host.innerHTML = '<div class="halarm-card">' +
      '<div class="halarm-ico"><span class="halarm-ring"></span><span class="halarm-ring r2"></span><i class="fa-solid ' + c.icon + '"></i></div>' +
      '<p class="halarm-kind">' + (med ? 'حان موعد الدواء' : 'حان موعد ' + esc(c.name)) + '</p>' +
      '<h2 class="halarm-title">' + esc(h.title) + '</h2>' +
      '<p class="halarm-time"><i class="fa-regular fa-clock me-1"></i>' + esc(fmtTime(x.t, true)) + ' · <span id="halLate">' + lateTxt(x) + '</span></p>' +
      (med ? '<div class="halarm-dose"><b>' + esc(amountTxt(h.pills || 1, h.unit || 'قرص')) + '</b><span>' + esc(FOOD[h.food] || FOOD.any) + '</span></div>' : '') +
      '<div class="halarm-chips">' +
      (st.streak ? '<span><i class="fa-solid fa-fire me-1"></i>سلسلة ' + daysTxt(st.streak) + '</span>' : '') +
      (med && h.stock != null ? '<span' + (stockLow ? ' class="warn"' : '') + '><i class="fa-solid fa-box-open me-1"></i>المتبقي ' + esc(trimNum(h.stock)) + ' ' + esc(MED_UNITS[h.unit] ? MED_UNITS[h.unit][0] : (h.unit || '')) + '</span>' : '') +
      (count > 1 ? '<span>+' + (count - 1) + ' مواعيد تنتظر</span>' : '') + '</div>' +
      '<button id="halDone" class="halarm-btn halarm-ok"><i class="fa-solid fa-check me-2"></i>تم</button>' +
      '<button id="halSkip" class="halarm-btn halarm-no"><i class="fa-solid fa-xmark me-2"></i>إلغاء (تخطي هذا الموعد)</button></div>';
    $('#halDone', host).addEventListener('click', function () { markSlot(h.id, x.d, x.t, 'done'); toast(med ? 'بالشفا والعافية 💚' : 'ممتاز! تم التسجيل ✅'); });
    $('#halSkip', host).addEventListener('click', function () { markSlot(h.id, x.d, x.t, 'skip'); toast('تم تخطي هذا الموعد'); });
  }

  /* ----- قسم العادات في الرئيسية ----- */
  function renderHabits() {
    var box = $('#habits');
    if (!box) return;
    var slots = todaySlots(), done = slots.filter(function (s) { return s.st === 'done'; }).length, total = slots.length;
    var pct = total ? Math.round(done / total * 100) : 0;
    var head = '<div class="hb-sum"><div class="hb-ring" style="--p:' + pct + '"><b>' + pct + '%</b></div><div class="min-w-0 flex-1"><p class="text-[16px] font-black text-navy">' +
      (total ? 'تم ' + done + ' من ' + total + ' اليوم' : 'مفيش مواعيد النهارده') + '</p><p class="text-[12px] text-slate2">' +
      (state.habits.length ? state.habits.length + (state.habits.length === 1 ? ' عادة' : ' عادات') + ' · ' : '') + 'روتينك اليومي</p></div>' +
      '<button id="hbAll" class="hb-mini" aria-label="كل العادات"><i class="fa-solid fa-list"></i></button>' +
      '<button id="hbAdd" class="hb-mini hb-mini-pri" aria-label="عادة جديدة"><i class="fa-solid fa-plus"></i></button></div>';
    if (!state.habits.length) {
      box.innerHTML = head + '<div class="hb-empty"><i class="fa-solid fa-seedling"></i><p>لسه ما أضفتش عادات.</p><p class="text-[12px]">ابدأ بدواء أو صلاة أو شرب ماء أو رياضة، وحدّد مواعيدها اليومية.</p>' +
        '<button id="hbAdd2" class="btn-primary mx-auto mt-3 !px-6">إضافة عادة أو روتين</button></div>';
      return;
    }
    var used = {};
    slots.forEach(function (s) { used[s.h.cat] = (used[s.h.cat] || 0) + 1; });
    if (hcatF !== 'all' && !used[hcatF]) hcatF = 'all';
    var chips = Object.keys(used).length > 1 ? '<div class="no-scrollbar -mx-1 mb-2.5 flex gap-2 overflow-x-auto px-1 pb-1"><button class="fchip' + (hcatF === 'all' ? ' is-on' : '') + '" data-hcat="all">الكل (' + slots.length + ')</button>' +
      state.habitCats.filter(function (c) { return used[c.id]; }).map(function (c) {
        var on = hcatF === c.id;
        return '<button class="fchip" data-hcat="' + c.id + '" style="' + (on ? 'background:' + c.color + ';border-color:' + c.color + ';color:#fff' : 'border-color:' + c.color + '66;color:' + c.color) + '"><i class="fa-solid ' + c.icon + ' me-1"></i>' + esc(c.name) + ' (' + used[c.id] + ')</button>';
      }).join('') + '</div>' : '';
    var list = hcatF === 'all' ? slots : slots.filter(function (s) { return s.h.cat === hcatF; });
    var pg = paginate('h-slots', list, 6, renderHabits, { token: hcatF });
    var ST_TXT = { done: 'تم', skip: 'ملغي', due: 'حان الآن', later: '', past: 'فات' };
    var rows = pg.items.map(function (s) {
      var c = hcOf(s.h), med = c.type === 'med', left = med ? stockDays(s.h) : null;
      return '<div class="hrow hrow-' + s.st + '" style="--hc:' + c.color + '" data-habit="' + s.h.id + '">' +
        '<span class="hrow-ico"><i class="fa-solid ' + c.icon + '"></i></span>' +
        '<div class="min-w-0 flex-1 text-start"><p class="hrow-t">' + esc(s.h.title) + '</p>' +
        '<p class="hrow-s"><b>' + esc(fmtTime(s.t, true)) + '</b>' + (med ? ' · ' + esc(doseLine(s.h)) : ' · ' + esc(c.name)) +
        (ST_TXT[s.st] ? ' · <em class="hrow-st">' + ST_TXT[s.st] + '</em>' : '') +
        (med && left != null && left <= 3 ? ' · <em class="hrow-low"><i class="fa-solid fa-box-open"></i> ' + (s.h.stock <= 0 ? 'خلص' : 'يكفي ' + daysTxt(left)) + '</em>' : '') + '</p></div>' +
        '<button class="hrow-btn" data-hslot="' + s.h.id + '|' + s.d + '|' + s.t + '" aria-label="' + (s.st === 'done' ? 'إلغاء التسجيل' : 'تم') + '" aria-pressed="' + (s.st === 'done') + '"><i class="fa-solid fa-check"></i></button></div>';
    }).join('');
    box.innerHTML = head + chips + (rows ? '<div class="space-y-2.5">' + rows + '</div>' + pg.html : '<p class="py-4 text-center text-[13px] text-royal/60">لا توجد مواعيد اليوم ' + (hcatF === 'all' ? '' : 'في هذا التصنيف') + '.</p>');
  }
  function habitsClick(e) {
    var sl = e.target.closest('[data-hslot]');
    if (sl) {
      var p = sl.dataset.hslot.split('|'), cur = logOf(p[0], p[1], p[2]);
      markSlot(p[0], p[1], p[2], cur && cur.st === 'done' ? null : 'done');
      if (!cur || cur.st !== 'done') toast('تم التسجيل ✅');
      return true;
    }
    var hc = e.target.closest('[data-hcat]'); if (hc) { hcatF = hc.dataset.hcat; renderHabits(); return true; }
    var ro = e.target.closest('[data-habit]'); if (ro) { habitView(ro.dataset.habit); return true; }
    if (e.target.closest('#hbAdd') || e.target.closest('#hbAdd2')) { habitForm(null); return true; }
    if (e.target.closest('#hbAll')) { habitsAll(); return true; }
    return false;
  }

  /* ----- كل العادات (قائمة بـ pagination) ----- */
  function habitsAll() {
    var wrap = openSheet('<h3 class="sheet-title">كل العادات والروتين</h3><p class="mt-0.5 text-[13px] text-slate2">' + state.habits.length + ' عادة</p>' +
      '<div id="haList" class="mt-3 space-y-2.5"></div><button id="haAdd" class="btn-primary mt-4 w-full"><i class="fa-solid fa-plus me-2"></i>عادة جديدة</button>' +
      '<button id="haCats" class="btn-outline mt-3 w-full"><i class="fa-solid fa-tags me-2"></i>إدارة التصنيفات</button>');
    function draw() {
      var pg = paginate('h-all', state.habits, 6, draw), today = todayISO();
      $('#haList', wrap).innerHTML = pg.items.length ? pg.items.map(function (h) {
        var c = hcOf(h), ended = h.endDate && h.endDate < today, tag = h.paused ? 'موقوفة' : ended ? 'منتهية' : habitOnDay(h, today) ? 'اليوم' : 'ليس اليوم';
        return '<button class="hrow hrow-later" style="--hc:' + c.color + '" data-ha="' + h.id + '"><span class="hrow-ico"><i class="fa-solid ' + c.icon + '"></i></span><div class="min-w-0 flex-1 text-start"><p class="hrow-t">' + esc(h.title) + '</p>' +
          '<p class="hrow-s">' + esc(c.name) + ' · ' + (h.times || []).length + ' مرات · ' + esc(daysSummary(h)) + ' · <em class="hrow-st">' + tag + '</em></p></div><i class="fa-solid fa-chevron-left text-[12px] text-slate-400"></i></button>';
      }).join('') + pg.html : '<p class="py-4 text-center text-[13px] text-royal/60">لا توجد عادات بعد.</p>';
      $$('[data-ha]', wrap).forEach(function (b) { b.addEventListener('click', function () { habitView(b.dataset.ha); }); });
    }
    draw();
    $('#haAdd', wrap).addEventListener('click', function () { habitForm(null); });
    $('#haCats', wrap).addEventListener('click', function () { catManager(function () { habitsAll(); }); });
  }

  /* ----- معاينة العادة (مميزة) ----- */
  function habitView(id) {
    var h = findHabit(id);
    if (!h) return closeSheet();
    var c = hcOf(h), med = c.type === 'med', st = habitStats(h), today = todayISO(), ended = h.endDate && h.endDate < today;
    var slots = habitOnDay(h, today) ? (h.times || []).map(function (t) { return { t: t, st: slotState(h, today, t) }; }) : [];
    var ws = weekStrip(h), left = med ? stockDays(h) : null;
    var stockPct = med && h.stock != null && h.stockInit ? Math.max(0, Math.min(100, Math.round(h.stock / h.stockInit * 100))) : 0;
    var statusChip = h.paused ? '<span class="chip chip-cancel">موقوفة</span>' : ended ? '<span class="chip chip-cancel">انتهت المدة</span>' : '<span class="chip chip-run">نشطة</span>';
    var wrap = openSheet(
      '<div class="hv-head" style="background:linear-gradient(135deg,' + c.color + ',' + shade(c.color, 0.45) + ')"><span class="hv-ico"><i class="fa-solid ' + c.icon + '"></i></span>' +
      '<div class="min-w-0 flex-1"><p class="hv-cat">' + esc(c.name) + (med ? ' · دواء' : '') + '</p><h3 class="hv-title">' + esc(h.title) + '</h3></div>' + statusChip + '</div>' +
      '<div class="mt-3 flex flex-wrap gap-2"><span class="chip chip-up"><i class="fa-regular fa-calendar"></i>' + esc(daysSummary(h)) + '</span>' +
      (h.times || []).map(function (t) { return '<span class="chip chip-run"><i class="fa-regular fa-clock"></i>' + esc(fmtTime(t, true)) + '</span>'; }).join('') + '</div>' +
      (med ? '<div class="hv-dose"><div><small>الجرعة</small><b>' + esc(amountTxt(h.pills || 1, h.unit || 'قرص')) + '</b></div><div><small>التوقيت</small><b>' + esc(FOOD[h.food] || FOOD.any) + '</b></div>' +
        '<div><small>يوميًا</small><b>' + esc(amountTxt(Math.round((h.pills || 1) * (h.times || []).length * 100) / 100, h.unit || 'قرص')) + '</b></div></div>' +
        (h.stock != null ? '<div class="hv-stock' + (h.stock <= 0 || (left != null && left <= 3) ? ' hv-stock-low' : '') + '"><div class="flex items-center justify-between text-[13px] font-extrabold"><span><i class="fa-solid fa-box-open me-1.5"></i>المتبقي: ' + esc(trimNum(h.stock)) + ' ' + esc(MED_UNITS[h.unit] ? MED_UNITS[h.unit][0] : (h.unit || '')) + '</span><span>' + (h.stock <= 0 ? 'خلص' : 'يكفي ' + esc(daysTxt(left))) + '</span></div>' +
          '<div class="bar2"><i style="width:' + stockPct + '%"></i></div>' +
          '<form id="hvRefill" class="mt-2 flex gap-2"><input class="field !h-10 min-w-0 flex-1" type="number" min="0" step="any" inputmode="decimal" placeholder="كمية جديدة لإضافتها للمخزون" /><button class="btn-primary !h-10">إضافة</button></form></div>' : '') : '') +
      '<div class="hv-stats"><div><b>' + st.streak + '</b><small>سلسلة أيام</small></div><div><b>' + (st.adherence == null ? '—' : st.adherence + '%') + '</b><small>الالتزام (30 يوم)</small></div><div><b>' + st.total + '</b><small>مرات التنفيذ</small></div></div>' +
      '<div class="hv-week">' + ws.map(function (w) { return '<div class="hv-day hv-day-' + w.st + '"><i></i><small>' + w.label + '</small></div>'; }).join('') + '</div>' +
      '<h4 class="cm-h">مواعيد اليوم</h4>' +
      (slots.length ? '<div class="space-y-2">' + slots.map(function (s) {
        var lbl = { done: 'تم ✓', skip: 'ملغي', due: 'حان الآن', later: 'لسه', past: 'فات' }[s.st];
        return '<div class="hv-slot hv-slot-' + s.st + '"><span class="hv-time">' + esc(fmtTime(s.t, true)) + '</span><span class="hv-lbl">' + lbl + '</span><span class="flex-1"></span>' +
          (s.st === 'done' || s.st === 'skip' ? '<button class="hv-b" data-hv="' + s.t + '|reset"><i class="fa-solid fa-rotate-left"></i> تراجع</button>'
            : '<button class="hv-b hv-b-ok" data-hv="' + s.t + '|done"><i class="fa-solid fa-check"></i> تم</button><button class="hv-b hv-b-no" data-hv="' + s.t + '|skip"><i class="fa-solid fa-xmark"></i> إلغاء</button>') + '</div>';
      }).join('') + '</div>' : '<p class="t-sub">' + (h.paused ? 'العادة موقوفة حاليًا.' : ended ? 'انتهت مدة هذه العادة.' : 'مفيش مواعيد لهذه العادة النهارده.') + '</p>') +
      (h.notes ? '<h4 class="cm-h">ملاحظات</h4><p class="text-[14px] text-navy" style="overflow-wrap:anywhere">' + esc(h.notes) + '</p>' : '') +
      '<h4 class="cm-h">سجل التنفيذ</h4><div id="hvHist"></div>' +
      '<div class="mt-5 grid grid-cols-2 gap-3"><button id="hvEdit" class="btn-primary"><i class="fa-solid fa-pen me-2"></i>تعديل</button><button id="hvPrint" class="btn-outline"><i class="fa-solid fa-print me-2"></i>طباعة</button></div>' +
      '<div class="mt-3 grid grid-cols-2 gap-3"><button id="hvPause" class="btn-outline"><i class="fa-solid ' + (h.paused ? 'fa-play' : 'fa-pause') + ' me-2"></i>' + (h.paused ? 'استئناف' : 'إيقاف مؤقت') + '</button><button id="hvDel" class="btn-danger"><i class="fa-solid fa-trash me-2"></i>حذف</button></div>'
    );
    function histRows() { return state.habitLogs.filter(function (l) { return l.h === h.id; }).sort(function (a, b) { return (b.at || 0) - (a.at || 0); }); }
    function drawHist() {
      var rows = histRows(), pg = paginate('hh-' + h.id, rows, 5, drawHist), box = $('#hvHist', wrap);
      if (!box) return;
      box.innerHTML = rows.length ? '<ul class="space-y-1.5">' + pg.items.map(function (l) {
        return '<li class="hv-log"><i class="fa-solid ' + (l.st === 'done' ? 'fa-circle-check text-leaf' : 'fa-circle-xmark text-slate-400') + '"></i><span class="flex-1">' + esc(absStamp(l.d, l.t)) + '</span><b>' + (l.st === 'done' ? 'تم' : 'ملغي') + '</b></li>';
      }).join('') + '</ul>' + pg.html : '<p class="t-sub">لا يوجد سجل بعد.</p>';
    }
    drawHist();
    $$('[data-hv]', wrap).forEach(function (b) {
      b.addEventListener('click', function () {
        var p = b.dataset.hv.split('|');
        markSlot(h.id, today, p[0], p[1] === 'reset' ? null : p[1]);
        habitView(id);
      });
    });
    var rf = $('#hvRefill', wrap);
    if (rf) rf.addEventListener('submit', function (e) {
      e.preventDefault();
      var v = parseFloat($('input', rf).value);
      if (!(v > 0)) return toast('اكتب كمية أكبر من صفر');
      h.stock = Math.round(((h.stock || 0) + v) * 100) / 100; h.stockInit = Math.max(h.stockInit || 0, h.stock); h.lowAlerted = false;
      save(); toast('تمت إضافة ' + trimNum(v) + ' للمخزون'); habitView(id);
    });
    $('#hvEdit', wrap).addEventListener('click', function () { habitForm(id); });
    $('#hvPause', wrap).addEventListener('click', function () { h.paused = !h.paused; if (!h.paused) h.since = Date.now(); save(); afterHabitChange(); habitView(id); toast(h.paused ? 'تم إيقاف العادة مؤقتًا' : 'تم استئناف العادة'); });
    $('#hvDel', wrap).addEventListener('click', function () {
      confirmBox({ title: 'حذف العادة', msg: 'هتتحذف «' + h.title + '» مع كل سجلها (' + histRows().length + ' تسجيل) نهائيًا، ولا يمكن التراجع.', ok: 'نعم، احذف', cancel: 'إلغاء', icon: 'fa-trash-can' }, function () {
        state.habits = state.habits.filter(function (x) { return x.id !== id; });
        state.habitLogs = state.habitLogs.filter(function (l) { return l.h !== id; });
        save(); afterHabitChange(); closeSheet(); toast('تم حذف العادة');
      });
    });
    $('#hvPrint', wrap).addEventListener('click', function () {
      var rows = histRows().slice().reverse();
      printDoc(h.title, prRows([['التصنيف', c.name], ['التكرار', daysSummary(h)], ['المواعيد', (h.times || []).map(function (t) { return fmtTime(t, true); }).join(' · ')],
        ['الفترة', absStamp(h.startDate) + (h.endDate ? ' إلى ' + absStamp(h.endDate) : ' (مستمرة)')]]
        .concat(med ? [['الجرعة', doseLine(h)], ['المخزون المتبقي', h.stock == null ? '—' : trimNum(h.stock)]] : [])
        .concat([['سلسلة الأيام', String(st.streak)], ['الالتزام (30 يوم)', st.adherence == null ? '—' : st.adherence + '%'], ['ملاحظات', h.notes || '—']])) +
        '<h2>سجل التنفيذ (' + rows.length + ')</h2>' + (rows.length ? '<table class="pr-table"><thead><tr><th>#</th><th>التاريخ والموعد</th><th>الحالة</th></tr></thead><tbody>' +
        rows.map(function (l, i) { return '<tr><td>' + (i + 1) + '</td><td>' + esc(absStamp(l.d, l.t)) + '</td><td>' + (l.st === 'done' ? 'تم' : 'ملغي') + '</td></tr>'; }).join('') + '</tbody></table>' : '<p>لا يوجد سجل.</p>'));
    });
  }

  /* ----- تقسيم الجرعات على اليوم ----- */
  function t2m(t) { var p = (t || '08:00').split(':'); return (+p[0]) * 60 + (+p[1]); }
  function m2t(m) { m = ((Math.round(m / 5) * 5) % 1440 + 1440) % 1440; return pad(Math.floor(m / 60)) + ':' + pad(m % 60); }
  // mode 'day': كل 24÷ن ساعة | 'wake': موزعة بالتساوي من أول جرعة لحد 10 مساءً
  function splitTimes(n, first, mode) {
    var f = t2m(first || '08:00'), out = [], i;
    if (n <= 1) return [m2t(f)];
    if (mode === 'wake' && f < 22 * 60 - 60) { var span = 22 * 60 - f; for (i = 0; i < n; i++) out.push(m2t(f + span * i / (n - 1))); }
    else { for (i = 0; i < n; i++) out.push(m2t(f + 1440 * i / n)); }
    return out.sort();
  }

  /* ----- نموذج العادة / الدواء ----- */
  function habitForm(id, draft) {
    var h = id ? findHabit(id) : null;
    var f = draft || (h ? { title: h.title, cat: h.cat, days: (h.days || []).slice(), times: (h.times || []).slice(), start: h.startDate, end: h.endDate || '', notes: h.notes || '', pills: h.pills || 1, unit: h.unit || 'قرص', food: h.food || 'any', stock: h.stock == null ? '' : h.stock, split: 'wake' }
      : { title: '', cat: (state.habitCats[0] || HC_DEFAULTS[0]).id, days: [], times: ['08:00'], start: todayISO(), end: '', notes: '', pills: 1, unit: 'قرص', food: 'any', stock: '', split: 'wake' });
    var wrap;
    function med() { return findHCat(f.cat).type === 'med'; }
    function stockInfo() {
      if (!med() || f.stock === '' || !(+f.stock >= 0)) return '';
      var daily = (+f.pills || 1) * f.times.length * (f.days.length && f.days.length < 7 ? f.days.length / 7 : 1);
      return daily ? 'تكفي حوالي ' + daysTxt(Math.floor(+f.stock / daily)) + ' (الاستهلاك اليومي ' + trimNum(daily) + ')' : '';
    }
    function interval() {
      var ts = f.times.slice().sort();
      if (ts.length < 2) return '';
      var gaps = ts.map(function (t, i) { return i ? t2m(t) - t2m(ts[i - 1]) : 0; }).slice(1), g = Math.round(gaps.reduce(function (a, b) { return a + b; }, 0) / gaps.length / 6) / 10;
      return 'متوسط الفاصل بين الجرعات ≈ ' + trimNum(g) + ' ساعة';
    }
    function sync() { // نقرأ القيم الحالية من الشاشة قبل أي إعادة رسم
      if (!wrap || !$('#hfT', wrap)) return;
      f.title = $('#hfT', wrap).value; f.notes = $('#hfN', wrap).value;
      var s = $('#hfStart', wrap); if (s) f.start = s.value;
      var dd = $('#hfDays', wrap); if (dd) f.dur = dd.value;
    }
    function draw() {
      var cat = findHCat(f.cat), isM = med(), n = f.times.length;
      var html = '<h3 class="sheet-title">' + (h ? 'تعديل العادة' : 'عادة أو روتين جديد') + '</h3><form id="hf" novalidate>' +
        '<label class="label" for="hfT">الاسم</label><input id="hfT" class="field" maxlength="50" value="' + esc(f.title) + '" placeholder="' + (isM ? 'مثال: فيتامين د / مضاد حيوي' : 'مثال: صلاة الضحى / شرب كوب ماء') + '" />' +
        '<label class="label">التصنيف</label><div class="flex flex-wrap gap-2" id="hfCats">' + state.habitCats.map(function (c) {
          var on = c.id === f.cat;
          return '<button type="button" class="fchip" data-c="' + c.id + '" style="' + (on ? 'background:' + c.color + ';border-color:' + c.color + ';color:#fff' : 'border-color:' + c.color + '66;color:' + c.color) + '"><i class="fa-solid ' + c.icon + ' me-1"></i>' + esc(c.name) + '</button>';
        }).join('') + '<button type="button" class="fchip" id="hfCatMgr"><i class="fa-solid fa-gear me-1"></i>تصنيفات</button></div>' +
        '<label class="label">التكرار</label><div class="flex flex-wrap gap-2" id="hfWd"><button type="button" class="seg-btn !flex-none !px-4' + (!f.days.length ? ' is-on' : '') + '" data-d="all">كل يوم</button>' +
        WEEK_DAYS.map(function (d) { return '<button type="button" class="seg-btn !flex-none !px-3' + (f.days.indexOf(d[0]) > -1 ? ' is-on' : '') + '" data-d="' + d[0] + '">' + d[1] + '</button>'; }).join('') + '</div>' +
        '<label class="label">عدد المرات في اليوم</label><div class="hf-step"><button type="button" data-n="-1" aria-label="أقل"' + (n <= 1 ? ' disabled' : '') + '><i class="fa-solid fa-minus"></i></button><b>' + n + '</b><button type="button" data-n="1" aria-label="أكثر"' + (n >= 8 ? ' disabled' : '') + '><i class="fa-solid fa-plus"></i></button>' +
        '<select id="hfSplit" class="field !h-10 flex-1" aria-label="طريقة التقسيم"><option value="wake"' + (f.split === 'wake' ? ' selected' : '') + '>تقسيم خلال ساعات اليقظة</option><option value="day"' + (f.split === 'day' ? ' selected' : '') + '>بالتساوي على 24 ساعة</option></select>' +
        '<button type="button" id="hfDo" class="btn-outline !h-10 !px-3 !text-[12px]">قسّم</button></div>' +
        '<div class="mt-2 grid grid-cols-2 gap-2.5" id="hfTimes">' + f.times.map(function (t, i) {
          return '<div class="hf-time"><small>' + (i + 1) + '</small><input type="time" class="field !h-10" value="' + esc(t) + '" data-i="' + i + '" aria-label="الموعد ' + (i + 1) + '" /></div>';
        }).join('') + '</div><p class="t-sub mt-1">' + esc(interval() || 'عدّل أي موعد بإيدك لو عايز.') + '</p>';
      if (isM) {
        html += '<div class="hf-med"><p class="hf-med-h"><i class="fa-solid fa-pills me-1.5"></i>تفاصيل الدواء</p>' +
          '<label class="label !mt-2">الجرعة في كل مرة</label><div class="flex flex-wrap gap-2" id="hfDose">' + DOSE_CHIPS.map(function (d) {
            return '<button type="button" class="seg-btn !flex-none !px-4' + (+f.pills === d[0] ? ' is-on' : '') + '" data-p="' + d[0] + '">' + d[1] + '</button>';
          }).join('') + '<input id="hfPills" type="number" min="0.25" step="0.25" inputmode="decimal" class="field !h-10 !w-24" value="' + esc(String(f.pills)) + '" aria-label="جرعة مخصصة" />' +
          '<select id="hfUnit" class="field !h-10 !w-28" aria-label="الوحدة">' + Object.keys(MED_UNITS).map(function (u) { return '<option' + (u === f.unit ? ' selected' : '') + '>' + u + '</option>'; }).join('') + '</select></div>' +
          '<p class="t-sub mt-1">الجرعة: <b>' + esc(amountTxt(+f.pills || 1, f.unit)) + '</b> × ' + n + ' مرات = <b>' + esc(amountTxt(Math.round((+f.pills || 1) * n * 100) / 100, f.unit)) + '</b> يوميًا</p>' +
          '<label class="label" for="hfFood">التوقيت مع الأكل</label><select id="hfFood" class="field">' + Object.keys(FOOD).map(function (k) { return '<option value="' + k + '"' + (k === f.food ? ' selected' : '') + '>' + FOOD[k] + '</option>'; }).join('') + '</select>' +
          '<label class="label" for="hfStock">عدد ' + esc(MED_UNITS[f.unit] ? MED_UNITS[f.unit][0] : f.unit) + ' المتبقي في العلبة <small class="font-semibold text-slate2">(اختياري)</small></label>' +
          '<input id="hfStock" type="number" min="0" step="any" inputmode="decimal" class="field" value="' + esc(String(f.stock)) + '" placeholder="مثال: 30" /><p id="hfStockInfo" class="t-sub mt-1">' + esc(stockInfo()) + '</p></div>';
      }
      html += '<div class="mt-1 grid grid-cols-2 gap-3"><div><label class="label" for="hfStart">تبدأ من</label><input id="hfStart" type="date" class="field" value="' + esc(f.start) + '" /></div>' +
        '<div><label class="label" for="hfDays">المدة (أيام)</label><input id="hfDays" type="number" min="1" max="3650" inputmode="numeric" class="field" value="' + esc(f.dur != null ? String(f.dur) : (f.end && f.start ? String(daysBetween(f.start, f.end) + 1) : '')) + '" placeholder="مستمرة" /></div></div>' +
        '<p class="t-sub">اترك المدة فاضية لو العادة مستمرة بدون نهاية' + (isM ? '، أو اكتب مدة العلاج بالأيام' : '') + '.</p>' +
        '<p id="hfErr" class="mt-1 min-h-[18px] text-[13px] font-bold text-red-500" role="alert"></p>' +
        '<label class="label" for="hfN">ملاحظات</label><textarea id="hfN" rows="2" maxlength="200" class="field !h-16 resize-none py-2" placeholder="اختياري">' + esc(f.notes) + '</textarea>' +
        '<button class="btn-primary mt-5 w-full" style="background:' + cat.color + '">' + (h ? 'حفظ التعديلات' : 'حفظ العادة') + '</button>' +
        (h ? '<button type="button" id="hfBack" class="btn-outline mt-3 w-full">رجوع</button>' : '') + '</form>';
      wrap = openSheet(html);
      bind();
    }
    function bind() {
      $('#hfT', wrap).addEventListener('input', function () { f.title = this.value; });
      $$('#hfCats [data-c]', wrap).forEach(function (b) { b.addEventListener('click', function () { sync(); f.cat = b.dataset.c; draw(); }); });
      $('#hfCatMgr', wrap).addEventListener('click', function () { sync(); catManager(function () { if (!findHCat(f.cat) || state.habitCats.every(function (c) { return c.id !== f.cat; })) f.cat = state.habitCats[0].id; habitForm(id, f); }); });
      $$('#hfWd [data-d]', wrap).forEach(function (b) {
        b.addEventListener('click', function () {
          sync();
          if (b.dataset.d === 'all') f.days = [];
          else { var d = +b.dataset.d, i = f.days.indexOf(d); if (i > -1) f.days.splice(i, 1); else f.days.push(d); if (f.days.length === 7) f.days = []; }
          draw();
        });
      });
      $$('[data-n]', wrap).forEach(function (b) {
        b.addEventListener('click', function () { sync(); var n = Math.max(1, Math.min(8, f.times.length + (+b.dataset.n))); f.times = splitTimes(n, f.times.slice().sort()[0], f.split); draw(); });
      });
      $('#hfSplit', wrap).addEventListener('change', function () { f.split = this.value; });
      $('#hfDo', wrap).addEventListener('click', function () { sync(); f.times = splitTimes(f.times.length, f.times.slice().sort()[0], f.split); draw(); toast('تم تقسيم المواعيد'); });
      $$('#hfTimes input', wrap).forEach(function (inp) { inp.addEventListener('change', function () { f.times[+inp.dataset.i] = inp.value || f.times[+inp.dataset.i]; }); });
      if (med()) {
        $$('#hfDose [data-p]', wrap).forEach(function (b) { b.addEventListener('click', function () { sync(); f.pills = +b.dataset.p; draw(); }); });
        $('#hfPills', wrap).addEventListener('input', function () { var v = parseFloat(this.value); if (v > 0) { f.pills = v; $('#hfStockInfo', wrap).textContent = stockInfo(); } });
        $('#hfPills', wrap).addEventListener('change', function () { sync(); draw(); });
        $('#hfUnit', wrap).addEventListener('change', function () { sync(); f.unit = this.value; draw(); });
        $('#hfFood', wrap).addEventListener('change', function () { f.food = this.value; });
        $('#hfStock', wrap).addEventListener('input', function () { f.stock = this.value; $('#hfStockInfo', wrap).textContent = stockInfo(); });
      }
      var bk = $('#hfBack', wrap); if (bk) bk.addEventListener('click', function () { habitView(id); });
      $('#hf', wrap).addEventListener('submit', function (e) { e.preventDefault(); submit(); });
    }
    function submit() {
      sync();
      var err = $('#hfErr', wrap), title = f.title.trim(), isM = med(), times = f.times.slice().sort();
      function bad(m, sel) { err.textContent = m; var el = sel && $(sel, wrap); if (el) { el.classList.add('field-err'); el.focus(); } }
      $$('.field', wrap).forEach(function (x) { x.classList.remove('field-err'); });
      if (!title) return bad('اكتب اسم العادة', '#hfT');
      if (times.some(function (t, i) { return !/^\d\d:\d\d$/.test(t) || (i && t === times[i - 1]); })) return bad('المواعيد لازم تكون كاملة وغير مكررة');
      if (!f.start) return bad('اختر تاريخ البداية', '#hfStart');
      if (isM && !(+f.pills > 0)) return bad('اكتب جرعة صحيحة', '#hfPills');
      var dur = f.dur === '' || f.dur == null ? 0 : parseInt(f.dur, 10);
      if (f.dur !== '' && f.dur != null && !(dur >= 1)) return bad('المدة لازم تكون يوم أو أكتر', '#hfDays');
      if (!h && f.start < todayISO()) return bad('تاريخ البداية لا يمكن أن يكون قبل اليوم', '#hfStart');
      var end = dur ? addDaysISO(f.start, dur - 1) : '';
      var stock = isM && f.stock !== '' && +f.stock >= 0 ? +f.stock : null;
      var changedSched = !h || h.times.join() !== times.join() || (h.days || []).join() !== f.days.slice().sort().join() || h.startDate !== f.start;
      var o = { title: title, cat: f.cat, times: times, days: f.days.slice().sort(), startDate: f.start, endDate: end, notes: f.notes.trim(), pills: isM ? +f.pills : 1, unit: isM ? f.unit : '', food: isM ? f.food : 'any' };
      if (h) {
        Object.assign(h, o);
        if (changedSched) h.since = Date.now();
        if (stock !== h.stock) { h.stock = stock; if (stock != null) { h.stockInit = Math.max(h.stockInit || 0, stock); h.lowAlerted = false; } }
        if (!isM) { h.stock = null; h.stockInit = null; }
        save(); afterHabitChange(); toast('تم الحفظ'); habitView(h.id);
      } else {
        var n = Object.assign({ id: uid(), paused: false, stock: stock, stockInit: stock, lowAlerted: false, alerted: {}, createdAt: Date.now(), since: Date.now() }, o);
        state.habits.push(n);
        pushNotif(findHCat(n.cat).icon, 'leaf', 'تمت إضافة عادة', n.title + ' · ' + times.length + (times.length === 1 ? ' مرة' : ' مرات') + ' يوميًا');
        save(); afterHabitChange(); closeSheet(); toast('تمت إضافة العادة ✅');
      }
    }
    draw();
  }

  /* ----- إدارة تصنيفات العادات ----- */
  function catManager(back) {
    var edit = null, icon = 'fa-repeat', color = HC_COLORS[0], isMed = false, iconOpen = false, nameVal = '';
    function list() {
      return '<div class="space-y-2">' + state.habitCats.map(function (c) {
        var n = state.habits.filter(function (h) { return h.cat === c.id; }).length;
        return '<div class="hrow hrow-later" style="--hc:' + c.color + '"><span class="hrow-ico"><i class="fa-solid ' + c.icon + '"></i></span><div class="min-w-0 flex-1 text-start"><p class="hrow-t">' + esc(c.name) + '</p><p class="hrow-s">' + (c.type === 'med' ? 'دواء (جرعات ومخزون) · ' : '') + n + ' عادة</p></div>' +
          '<button class="hv-b" data-ce="' + c.id + '" aria-label="تعديل"><i class="fa-solid fa-pen"></i></button><button class="hv-b hv-b-no" data-cd="' + c.id + '" aria-label="حذف"><i class="fa-solid fa-trash"></i></button></div>';
      }).join('') + '</div>';
    }
    function draw() {
      var cur = edit && state.habitCats.filter(function (c) { return c.id === edit; })[0];
      var wrap = openSheet('<h3 class="sheet-title">تصنيفات العادات</h3>' + list() +
        '<h4 class="cm-h">' + (cur ? 'تعديل «' + esc(cur.name) + '»' : 'تصنيف جديد') + '</h4>' +
        '<div class="flex items-end gap-3"><button type="button" id="ccIco" class="ico-pick" style="background:' + color + '22;color:' + color + ';border-color:' + color + '" aria-label="اختيار أيقونة"><i class="fa-solid ' + icon + '"></i><span class="ico-pick-pen"><i class="fa-solid fa-pen"></i></span></button>' +
        '<input id="ccName" class="field min-w-0 flex-1" maxlength="24" value="' + esc(nameVal) + '" placeholder="اسم التصنيف (مثال: أذكار)" /></div>' +
        '<div id="ccPanel" class="ico-panel" hidden></div>' +
        '<div class="mt-3 flex flex-wrap gap-2.5" id="ccColors">' + HC_COLORS.map(function (c) { return '<button type="button" data-col="' + c + '" class="h-8 w-8 rounded-full border-4 ' + (c === color ? 'border-navy' : 'border-white shadow') + '" style="background:' + c + '" aria-label="لون"></button>'; }).join('') + '</div>' +
        '<label class="mt-3 flex items-center gap-2 text-[13px] font-bold text-navy"><input id="ccMed" type="checkbox" class="h-4 w-4 accent-[#15935a]"' + (isMed ? ' checked' : '') + ' /> تصنيف دواء (يفعّل الجرعات والأقراص والمخزون)</label>' +
        '<p id="ccErr" class="mt-1 min-h-[18px] text-[13px] font-bold text-red-500" role="alert"></p>' +
        '<button id="ccSave" class="btn-primary w-full">' + (cur ? 'حفظ التصنيف' : 'إضافة التصنيف') + '</button>' +
        (cur ? '<button id="ccNew" class="btn-outline mt-3 w-full">تصنيف جديد بدل التعديل</button>' : '') +
        '<button id="ccDone" class="btn-outline mt-3 w-full">تم</button>');
      var panelG = 0;
      function paintPanel() {
        var box = $('#ccPanel', wrap); box.hidden = !iconOpen;
        if (!iconOpen) return;
        var g = ICON_GROUPS[panelG];
        box.innerHTML = '<div class="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-2">' + ICON_GROUPS.map(function (x, i) { return '<button type="button" class="ico-tab' + (i === panelG ? ' is-on' : '') + '" data-g="' + i + '"><i class="fa-solid ' + x[1] + ' me-1"></i>' + x[0] + '</button>'; }).join('') + '</div>' +
          '<div class="ico-grid">' + g[2].map(function (n) { return '<button type="button" class="ico-cell' + (n === icon ? ' is-on' : '') + '" data-i="' + n + '" style="' + (n === icon ? 'background:' + color + ';border-color:' + color + ';color:#fff' : 'color:' + color) + '"><i class="fa-solid ' + n + '"></i></button>'; }).join('') + '</div>';
      }
      $('#ccIco', wrap).addEventListener('click', function () { iconOpen = !iconOpen; paintPanel(); });
      $('#ccPanel', wrap).addEventListener('click', function (e) {
        var tb = e.target.closest('[data-g]'); if (tb) { panelG = +tb.dataset.g; return paintPanel(); }
        var ib = e.target.closest('[data-i]'); if (ib) { icon = ib.dataset.i; keep(); draw(); }
      });
      function keep() { isMed = $('#ccMed', wrap).checked; }
      $('#ccName', wrap).addEventListener('input', function () { nameVal = this.value; });
      $$('#ccColors [data-col]', wrap).forEach(function (b) { b.addEventListener('click', function () { color = b.dataset.col; keep(); draw(); }); });
      $$('[data-ce]', wrap).forEach(function (b) { b.addEventListener('click', function () { var c = findHCat(b.dataset.ce); edit = c.id; icon = c.icon; color = c.color; isMed = c.type === 'med'; nameVal = c.name; draw(); }); });
      $$('[data-cd]', wrap).forEach(function (b) {
        b.addEventListener('click', function () {
          var c = findHCat(b.dataset.cd), n = state.habits.filter(function (h) { return h.cat === c.id; }).length;
          if (state.habitCats.length <= 1) return toast('لازم يفضل تصنيف واحد على الأقل');
          confirmBox({ title: 'حذف التصنيف', msg: 'هيتحذف تصنيف «' + c.name + '»' + (n ? ' وهتنتقل ' + n + ' عادة لتصنيف «' + state.habitCats.filter(function (x) { return x.id !== c.id; })[0].name + '»' : '') + '.', ok: 'نعم، احذف', cancel: 'إلغاء', icon: 'fa-trash-can' }, function () {
            var to = state.habitCats.filter(function (x) { return x.id !== c.id; })[0].id;
            state.habits.forEach(function (h) { if (h.cat === c.id) h.cat = to; });
            state.habitCats = state.habitCats.filter(function (x) { return x.id !== c.id; });
            save(); renderHome(); edit = null; draw();
          });
        });
      });
      var nw = $('#ccNew', wrap); if (nw) nw.addEventListener('click', function () { edit = null; icon = 'fa-repeat'; color = HC_COLORS[0]; isMed = false; nameVal = ''; draw(); });
      $('#ccSave', wrap).addEventListener('click', function () {
        var nm = $('#ccName', wrap).value.trim(), err = $('#ccErr', wrap);
        if (!nm) { err.textContent = 'اكتب اسم التصنيف'; return $('#ccName', wrap).focus(); }
        if (state.habitCats.some(function (c) { return c.name === nm && c.id !== edit; })) { err.textContent = 'التصنيف ده موجود بالفعل'; return; }
        var med = $('#ccMed', wrap).checked;
        if (cur) { cur.name = nm; cur.icon = icon; cur.color = color; cur.type = med ? 'med' : 'normal'; toast('تم حفظ التصنيف'); }
        else { state.habitCats.push({ id: 'hc_' + uid(), name: nm, icon: icon, color: color, type: med ? 'med' : 'normal' }); toast('تمت إضافة التصنيف'); }
        save(); renderHome(); edit = null; icon = 'fa-repeat'; color = HC_COLORS[0]; isMed = false; nameVal = ''; draw();
      });
      $('#ccDone', wrap).addEventListener('click', function () { if (back) back(); else closeSheet(); });
    }
    draw();
  }


  /* ----- كارت المهام المستعجلة (تنتهي خلال 6 ساعات) ----- */
  var URGENT_WINDOW = 6 * HOUR, urgIdx = 0;
  function urgentList() {
    var n = Date.now();
    return state.tasks.filter(function (t) { return isOpen(t) && endMs(t) > n && endMs(t) <= n + URGENT_WINDOW; })
      .sort(function (a, b) { return endMs(a) - endMs(b); });
  }
  function urgentGo(dir) {
    var l = urgentList();
    if (!l.length) return;
    if (dir === 'next') urgIdx = (urgIdx + 1) % l.length;
    else if (dir === 'prev') urgIdx = (urgIdx - 1 + l.length) % l.length;
    else urgIdx = Math.max(0, Math.min(l.length - 1, parseInt(dir, 10) || 0));
    renderUrgent(true);
  }
  function renderUrgent(anim) {
    var box = $('#urgent');
    if (!box) return;
    var l = urgentList();
    if (!l.length) {
      urgIdx = 0;
      box.innerHTML = '<div class="urg urg-empty"><span class="urg-ok"><i class="fa-solid fa-mug-hot"></i></span><div class="min-w-0"><p class="text-[15px] font-extrabold text-navy">لا توجد مهام مستعجلة</p>' +
        '<p class="text-[12px] text-slate2">مفيش مهمة بتنتهي خلال الـ 6 ساعات الجاية.</p></div></div>';
      return;
    }
    if (urgIdx >= l.length) urgIdx = l.length - 1;
    var t = l[urgIdx], n = Date.now(), left = endMs(t) - n, total = Math.max(1, endMs(t) - Math.max(startMs(t), endMs(t) - URGENT_WINDOW));
    var pct = Math.max(2, Math.min(100, Math.round((1 - left / total) * 100))), hot = left <= HOUR;
    var multi = l.length > 1;
    box.innerHTML = '<div class="urg' + (hot ? ' urg-hot' : '') + '" tabindex="0" aria-roledescription="carousel" aria-label="المهام المستعجلة">' +
      '<div class="urg-head"><span class="urg-tag"><i class="fa-solid fa-bolt me-1"></i>مستعجلة · خلال 6 ساعات</span>' +
      '<span class="urg-count">' + (urgIdx + 1) + ' / ' + l.length + '</span></div>' +
      '<button type="button" class="urg-body' + (anim ? ' urg-anim' : '') + '" data-urg-open="' + t.id + '" aria-label="عرض المهمة ' + esc(t.title) + '">' +
      '<span class="urg-ico"><i class="fa-solid ' + iconOf(t) + '"></i></span>' +
      '<span class="min-w-0 flex-1 text-start"><span class="urg-title">' + esc(t.title) + '</span>' +
      '<span class="urg-left"><i class="fa-regular fa-clock me-1"></i>تنتهي بعد ' + esc(durTxt(left)) + '</span>' +
      '<span class="urg-sub">' + esc(CATS[catOf(t)].n) + ' · ' + esc(fmtTime(t.endTime || '23:59', true)) + ((t.snoozes || []).length ? ' · مُدّت ×' + t.snoozes.length : '') + '</span></span></button>' +
      '<div class="urg-bar"><i style="width:' + pct + '%"></i></div>' +
      (multi ? '<div class="urg-nav"><button type="button" class="urg-arrow" data-urg="prev" aria-label="السابقة"><i class="fa-solid fa-chevron-right"></i></button>' +
        '<div class="urg-dots">' + l.map(function (_, i) { return '<button type="button" class="urg-dot' + (i === urgIdx ? ' is-on' : '') + '" data-urg="' + i + '" aria-label="المهمة ' + (i + 1) + '"></button>'; }).join('') + '</div>' +
        '<button type="button" class="urg-arrow" data-urg="next" aria-label="التالية"><i class="fa-solid fa-chevron-left"></i></button></div>' : '') + '</div>';
  }

  /* ----- قائمة الإنشاء الشاملة (الزر الأوسط في الشريط السفلي) ----- */
  function createMenu() {
    var wrap = openSheet(
      '<h3 class="sheet-title">إنشاء جديد</h3><p class="mt-0.5 text-[13px] text-slate2">اختر اللي عايز تضيفه.</p>' +
      '<h4 class="cm-h"><i class="fa-solid fa-list-check me-1.5"></i>مهمة بموعد <small>(اختر المجال)</small></h4>' +
      '<div class="grid grid-cols-4 gap-2.5">' + CAT_ORDER.map(function (k) {
        var c = CATS[k];
        return '<button class="cm-cat" data-cm="task:' + k + '"><span class="cm-ico" style="background:' + c.c + '"><i class="fa-solid ' + c.i + '"></i></span><span style="color:' + c.c + '">' + c.n + '</span></button>';
      }).join('') + '</div>' +
      '<h4 class="cm-h"><i class="fa-solid fa-diagram-project me-1.5"></i>مشاريع ومهام شخصية</h4>' +
      '<div class="space-y-2.5">' +
      '<button class="cm-row" data-cm="project"><span class="cm-ico" style="background:#3ec878"><i class="fa-solid fa-folder-plus"></i></span><span class="min-w-0 flex-1 text-start"><b>مشروع جديد</b><small>مجموعة مهام بقائمة تحقق ونسبة إنجاز</small></span><i class="fa-solid fa-chevron-left cm-arr"></i></button>' +
      '<button class="cm-row" data-cm="personal"><span class="cm-ico" style="background:#1896ba"><i class="fa-solid fa-user-check"></i></span><span class="min-w-0 flex-1 text-start"><b>مهمة شخصية</b><small>هدف بنسبة تقدّم تحدّثها بنفسك</small></span><i class="fa-solid fa-chevron-left cm-arr"></i></button>' +
      '<button class="cm-row" data-cm="habit"><span class="cm-ico" style="background:#7c5cd6"><i class="fa-solid fa-repeat"></i></span><span class="min-w-0 flex-1 text-start"><b>عادة أو روتين يومي</b><small>دواء، صلاة، صيام، صدقات، ماء، رياضة…</small></span><i class="fa-solid fa-chevron-left cm-arr"></i></button>' +
      '<button class="cm-row" data-cm="addtoproj"><span class="cm-ico" style="background:#f0732e"><i class="fa-solid fa-list-check"></i></span><span class="min-w-0 flex-1 text-start"><b>أضف مهمة داخل مشروع</b><small>اختر مشروعًا من مشاريعك وأضف له مهمة</small></span><i class="fa-solid fa-chevron-left cm-arr"></i></button>' +
      '</div>'
    );
    $$('[data-cm]', wrap).forEach(function (b) {
      b.addEventListener('click', function () {
        var k = b.dataset.cm;
        if (k.indexOf('task:') === 0) taskForm(null, k.slice(5));
        else if (k === 'project') newProjectSheet();
        else if (k === 'personal') personalSheet(null);
        else if (k === 'habit') habitForm(null);
        else if (k === 'addtoproj') projectPicker();
      });
    });
  }
  function projectPicker() {
    closeSheet();
    var old = $('.modal'); if (old) old.remove();
    var m = document.createElement('div'); m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
    var list = state.projects.map(function (p) {
      var done = p.tasks.filter(function (t) { return t.done; }).length;
      return '<button type="button" class="cm-row" data-pp="' + p.id + '"><span class="cm-ico" style="background:#3ec878"><i class="fa-solid fa-folder"></i></span><span class="min-w-0 flex-1 text-start"><b class="block truncate">' + esc(p.title) + '</b><small>' + done + ' من ' + tasksWord(p.tasks.length) + '</small></span><i class="fa-solid fa-chevron-left cm-arr"></i></button>';
    }).join('');
    m.innerHTML = '<div class="modal-card" style="max-height:80%;display:flex;flex-direction:column">' +
      '<h3 class="sheet-title">اختر المشروع</h3><p class="mt-0.5 text-[13px] text-slate2">هتتفتح صفحة المشروع علشان تضيف المهمة.</p>' +
      '<div class="mt-3 space-y-2.5 overflow-y-auto" style="min-height:0">' +
      (list || '<p class="rounded-xl bg-white/70 py-5 text-center text-[13px] text-slate2">لا توجد مشاريع بعد. أنشئ مشروعًا أولًا.</p>') + '</div>' +
      '<div class="modal-btns mt-3">' + (list ? '' : '<button type="button" class="btn-primary" data-pp-new="1">مشروع جديد</button>') + '<button type="button" class="btn-outline" data-pp-x="1">إلغاء</button></div></div>';
    (phone || document.body).appendChild(m);
    requestAnimationFrame(function () { m.classList.add('show'); var c = m.firstChild; if (c) c.style.transform = 'scale(1)'; });
    m.addEventListener('click', function (e) {
      var b = e.target.closest('[data-pp]');
      if (b) { m.remove(); projectSheet(b.dataset.pp); setTimeout(function () { var i = $('#addT input'); if (i) i.focus(); }, 80); return; }
      if (e.target.closest('[data-pp-new]')) { m.remove(); newProjectSheet(); return; }
      if (e.target === m || e.target.closest('[data-pp-x]')) m.remove();
    });
  }
  document.addEventListener('click', function (e) {
    if (e.target.closest && e.target.closest('#navAdd')) {
      if ($('#alarm') || $('.lock')) return;
      createMenu();
    }
  });

  function initHome() {
    renderHome();
    var box = $('#urgent'), sx = null;
    box.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
    box.addEventListener('touchend', function (e) {
      if (sx == null) return;
      var dx = e.changedTouches[0].clientX - sx; sx = null;
      if (Math.abs(dx) > 45) urgentGo(dx < 0 ? 'next' : 'prev'); // في الـ RTL السحب لليسار = التالي
    }, { passive: true });
    box.addEventListener('keydown', function (e) { if (e.key === 'ArrowLeft') urgentGo('next'); else if (e.key === 'ArrowRight') urgentGo('prev'); });
    route.click = function (e) {
      var pr = e.target.closest('[data-proj]'); if (pr) return projectSheet(pr.dataset.proj);
      var pt = e.target.closest('[data-ptask]'); if (pt) return personalSheet(pt.dataset.ptask);
      if (e.target.closest('#addProj')) return newProjectSheet();
      if (habitsClick(e)) return;
      var us = e.target.closest('[data-urg]'); if (us) return urgentGo(us.dataset.urg);
      var uo = e.target.closest('[data-urg-open]'); if (uo) return taskView(uo.dataset.urgOpen, false);
    };
  }

  /* =====================================================
     المهام: تسجيل + معاينة + تعديل + حذف + طباعة
     ===================================================== */
  var filter = 'all', catFilter = 'all', dayFilter = null, weekOff = 0;
  var ORD = { expired: 0, active: 1, upcoming: 2 };

  function sortTasks(list) {
    return list.slice().sort(function (a, b) {
      var sa = statusOf(a), sb = statusOf(b);
      if (ORD[sa] !== ORD[sb]) return ORD[sa] - ORD[sb];
      return endMs(a) - endMs(b);
    });
  }

  function chipsFor(t) {
    var s = statusOf(t);
    var h = '<span class="chip ' + STATUS_CHIP[s] + '">' + STATUS_TXT[s] + '</span>' + catChip(t);
    if (t.priority && PRI[t.priority] && s !== 'expired') h += '<span class="chip ' + PRI_CHIP[t.priority] + '">' + PRI[t.priority] + '</span>';
    return '<div class="mt-2 flex flex-wrap gap-1.5">' + h + '</div>';
  }

  // عمود الوقت في الكارت: موعد الانتهاء
  function timeCol(t) {
    var tm = t.endTime || '23:59', p = tm.split(':'), h = +p[0];
    return '<div class="tc-time"><b>' + (h % 12 || 12) + ':' + p[1] + ' <span>' + (h < 12 ? 'ص' : 'م') + '</span></b><small>' + esc(dayLabel(t.endDate, true)) + '</small></div><i class="tc-sep"></i>';
  }
  function onDay(t, iso) { return t.startDate <= iso && iso <= t.endDate; }

  // شريط الأسبوع (السبت ← الجمعة)
  function renderWeek() {
    var box = $('#week');
    if (!box) return;
    var base = parseISO(TODAY);
    base.setDate(base.getDate() - ((base.getDay() + 1) % 7) + weekOff * 7);
    var days = [];
    for (var i = 0; i < 7; i++) { var d = new Date(base); d.setDate(base.getDate() + i); days.push(d); }
    var label = days[0].toLocaleDateString(LOCALE, { day: 'numeric', month: 'long' }) + ' – ' + days[6].toLocaleDateString(LOCALE, { day: 'numeric', month: 'long', year: 'numeric' });
    box.innerHTML = '<div class="week-top"><button class="week-nav" data-wk="-1" aria-label="الأسبوع السابق"><i class="fa-solid fa-chevron-right"></i></button><span>' + label + '</span>' +
      '<button class="week-nav" data-wk="1" aria-label="الأسبوع التالي"><i class="fa-solid fa-chevron-left"></i></button></div><div class="grid grid-cols-7 gap-1">' +
      days.map(function (d) {
        var iso = isoDate(d);
        var open = state.tasks.filter(function (t) { return isOpen(t) && onDay(t, iso); });
        var red = state.tasks.some(function (t) { return isExpired(t) && t.endDate === iso; });
        return '<button class="wd' + (iso === TODAY ? ' is-today' : '') + (iso === dayFilter ? ' is-sel' : '') + (red ? ' has-red' : open.length ? ' has' : '') + '" data-day="' + iso + '" aria-pressed="' + (iso === dayFilter) + '">' +
          '<small>' + d.toLocaleDateString(LOCALE, { weekday: 'short' }).replace('ال', '') + '</small><b>' + d.getDate() + '</b><i></i></button>';
      }).join('') + '</div>';
  }

  function renderTasks() {
    if (!$('#ongoing')) return;
    renderWeek();
    var q = ($('#q').value || '').trim().toLowerCase();
    function match(t) { return !q || [t.title, t.notes, t.place, CATS[catOf(t)].n, rangeText(t)].join(' ').toLowerCase().indexOf(q) !== -1; }
    var openAll = sortTasks(state.tasks.filter(isOpen));
    function cnt(fn) { return openAll.filter(fn).length; }

    var filters = [
      ['all', 'الكل', openAll.length],
      ['active', 'نشطة', cnt(function (t) { return statusOf(t) === 'active'; })],
      ['upcoming', 'قادمة', cnt(function (t) { return statusOf(t) === 'upcoming'; })],
      ['expired', 'انتهت', cnt(isExpired)],
      ['high', 'أولوية عالية', cnt(function (t) { return t.priority === 'high'; })]
    ];
    $('#chips').innerHTML = (dayFilter ? '<button class="fchip is-on" data-day-clear="1"><i class="fa-solid fa-xmark me-1"></i>' + esc(dayLabel(dayFilter, true)) + '</button>' : '') + filters.map(function (f) {
      return '<button class="fchip' + (filter === f[0] ? ' is-on' : '') + (f[0] === 'expired' && f[2] ? ' fchip-red' : '') + '" data-filter="' + f[0] + '">' + f[1] + ' (' + f[2] + ')</button>';
    }).join('');

    $('#cats').innerHTML = '<button class="fchip' + (catFilter === 'all' ? ' is-on' : '') + '" data-catf="all"><i class="fa-solid fa-layer-group me-1"></i>كل التصنيفات</button>' +
      CAT_ORDER.map(function (k) {
        var c = CATS[k], n = cnt(function (t) { return catOf(t) === k; }), on = catFilter === k;
        return '<button class="fchip" data-catf="' + k + '" style="' + (on ? 'background:' + c.c + ';border-color:' + c.c + ';color:#fff' : 'border-color:' + c.c + '66;color:' + c.c) + '">' +
          '<i class="fa-solid ' + c.i + ' me-1"></i>' + c.n + ' (' + n + ')</button>';
      }).join('');

    function byFilter(t) {
      if (filter === 'active') return statusOf(t) === 'active';
      if (filter === 'upcoming') return statusOf(t) === 'upcoming';
      if (filter === 'expired') return isExpired(t);
      if (filter === 'high') return t.priority === 'high';
      return true;
    }
    function byCat(t) { return (catFilter === 'all' || catOf(t) === catFilter) && (!dayFilter || onDay(t, dayFilter)); }
    var ongoing = openAll.filter(function (t) { return byFilter(t) && byCat(t) && match(t); });
    var finished = state.tasks.filter(function (t) { return t.done && byCat(t) && match(t); })
      .sort(function (a, b) { return (b.doneAt || 0) - (a.doneAt || 0); });
    var canceled = state.tasks.filter(function (t) { return t.canceled && !t.done && byCat(t) && match(t); })
      .sort(function (a, b) { return (b.canceledAt || 0) - (a.canceledAt || 0); });

    var tok = [filter, catFilter, dayFilter, q].join('|'), SZ = 6;
    var pgO = paginate('t-ongoing', ongoing, SZ, renderTasks, { token: tok });
    function snzChip(t) {
      var z = (t.snoozes || []).length;
      return z ? '<span class="chip chip-snz"><i class="fa-solid fa-clock-rotate-left"></i>مُدّت ×' + z + '</span>' : '';
    }

    $('#ongoing').innerHTML = pgO.items.length ? pgO.items.map(function (t) {
      var s = statusOf(t);
      return '<li class="tl-item' + (s === 'expired' ? ' tl-late' : '') + '">' +
        '<div class="tcard tcard-' + s + '" data-open="' + t.id + '">' + timeCol(t) +
        '<div class="min-w-0 flex-1"><p class="t-title truncate">' + taskIco(t) + esc(t.title) + '</p>' +
        '<div class="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1"><span class="chip ' + STATUS_CHIP[s] + '">' + STATUS_TXT[s] + '</span>' + snzChip(t) +
        '<span class="t-remain !mt-0">' + (s === 'expired' ? '<i class="fa-solid fa-triangle-exclamation me-1"></i>' : '<i class="fa-regular fa-clock me-1"></i>') + remainText(t) + '</span></div></div></div>' +
        '<button class="tl-dot" data-done="' + t.id + '" aria-label="تحديد كمنجزة"><i class="fa-solid fa-check opacity-0"></i></button></li>';
    }).join('') + (pgO.html ? '<li class="tl-item">' + pgO.html + '</li>' : '')
      : '<li class="tl-item"><p class="t-sub">' + (q || dayFilter || filter !== 'all' || catFilter !== 'all' ? 'لا توجد مهام جارية مطابقة.' : 'خلّصت كل شيء! اضغط + لإضافة مهمة.') + '</p></li>';

    var pgF = paginate('t-finished', finished, SZ, renderTasks, { token: tok });
    $('#finished').innerHTML = pgF.items.length ? pgF.items.map(function (t) {
      return '<li class="tl-item"><div class="tcard tcard-done" data-open="' + t.id + '">' + timeCol(t) +
        '<div class="min-w-0 flex-1"><p class="t-title truncate">' + taskIco(t) + esc(t.title) + '</p>' +
        '<div class="mt-1.5 flex flex-wrap gap-1.5"><span class="chip chip-done">تم الإنجاز</span>' + snzChip(t) + '</div></div></div>' +
        '<button class="tl-dot tl-dot-done" data-undo="' + t.id + '" aria-label="إرجاعها للجارية"><i class="fa-solid fa-check"></i></button></li>';
    }).join('') + (pgF.html ? '<li class="tl-item">' + pgF.html + '</li>' : '')
      : '<li class="tl-item"><p class="t-sub">' + (q || dayFilter ? 'لا توجد مهام منتهية مطابقة.' : 'لم تنهِ أي مهمة بعد.') + '</p></li>';

    var wrapC = $('#canceledWrap');
    if (wrapC) {
      wrapC.hidden = !canceled.length;
      var pgC = paginate('t-canceled', canceled, SZ, renderTasks, { token: tok });
      $('#canceled').innerHTML = pgC.items.map(function (t) {
        return '<li class="tl-item"><div class="tcard tcard-canceled" data-open="' + t.id + '">' + timeCol(t) +
          '<div class="min-w-0 flex-1"><p class="t-title truncate">' + taskIco(t) + esc(t.title) + '</p>' +
          '<div class="mt-1.5 flex flex-wrap gap-1.5"><span class="chip chip-cancel">ملغاة</span>' + snzChip(t) + '</div></div></div>' +
          '<button class="tl-dot tl-dot-restore" data-restore="' + t.id + '" aria-label="استعادة المهمة"><i class="fa-solid fa-rotate-left"></i></button></li>';
      }).join('') + (pgC.html ? '<li class="tl-item">' + pgC.html + '</li>' : '');
    }
  }

  function setDone(id, done) {
    var t = findTask(id);
    if (!t) return;
    t.done = done;
    t.doneAt = done ? Date.now() : null;
    t.ring = '';
    if (done) t.canceled = false, t.canceledAt = null;
    if (!done) flagPast(t);
    if (done) { pushNotif('fa-circle-check', 'leaf', 'تم إنجاز مهمة', t.title); toast('أحسنت! تم إنجاز المهمة 🎉'); }
    else toast('رجعت المهمة إلى الجارية');
    save(); afterTaskChange();
  }

  /* ----- شاشة المعاينة ----- */
  function drow(icon, label, value) {
    return '<div class="drow"><span class="drow-ico"><i class="fa-solid ' + icon + '"></i></span>' +
      '<div class="min-w-0 flex-1"><p class="text-[11px] font-bold text-royal/60">' + label + '</p>' +
      '<p class="text-[15px] font-semibold text-navy" style="overflow-wrap:anywhere">' + value + '</p></div></div>';
  }

  // عدّاد المتبقي (أيام / ساعات / دقائق)
  function countdownHtml(t) {
    var s = statusOf(t), n = Date.now();
    if (s === 'canceled') {
      return '<div class="cd cd-canceled"><p class="cd-line"><i class="fa-solid fa-ban me-1"></i>هذه المهمة ملغاة' + (t.canceledAt ? ' · ' + esc(atStamp(t.canceledAt)) : '') + '</p></div>';
    }
    if (s === 'done') {
      return '<div class="cd cd-done"><p class="cd-line"><i class="fa-solid fa-circle-check me-1"></i>تم إنجاز هذه المهمة</p></div>';
    }
    var target = s === 'upcoming' ? startMs(t) - n : s === 'active' ? endMs(t) - n : n - endMs(t);
    var cap = s === 'upcoming' ? 'تبدأ بعد' : s === 'active' ? 'الوقت المتبقي' : 'مضى على انتهائها';
    var p = parts(target);
    var hours = s === 'expired' ? p.totalH : p.totalH;
    return '<div class="cd cd-' + s + '"><p class="cd-cap">' + cap + '</p>' +
      '<div class="flex gap-2"><div class="cd-box"><b>' + p.d + '</b><span>يوم</span></div><div class="cd-box"><b>' + p.h + '</b><span>ساعة</span></div><div class="cd-box"><b>' + p.m + '</b><span>دقيقة</span></div></div>' +
      '<p class="cd-line">' + remainText(t) + (p.totalH ? ' · ≈ ' + unitTxt(hours, 'h') + ' بالإجمالي' : '') + '</p>' +
      '<div class="bar2 mt-2"><i style="width:' + elapsedPct(t) + '%"></i></div>' +
      '<p class="mt-1 text-[11px] font-bold opacity-70">انقضى ' + elapsedPct(t) + '% من مدة المهمة (' + durTxt(endMs(t) - startMs(t)) + ')</p></div>';
  }
  function updateCountdown(id) {
    var t = findTask(id), box = $('#cd');
    if (t && box) box.innerHTML = countdownHtml(t);
  }

  function taskView(id, confirmDel) {
    var t = findTask(id);
    if (!t) return closeSheet();
    var s = statusOf(t);
    route.viewId = id;
    var pri = t.priority && PRI[t.priority] ? '<span class="chip ' + PRI_CHIP[t.priority] + '">أولوية ' + PRI[t.priority] + '</span>' : '';
    var created = new Date(t.createdAt || Date.now()).toLocaleDateString(LOCALE, { day: 'numeric', month: 'long', year: 'numeric' });

    var zs = t.snoozes || [];
    var actions;
    if (confirmDel === 'cancel') {
      actions = '<p class="mt-5 text-center text-[15px] font-bold text-red-500">هل تريد إلغاء هذه المهمة؟</p>' +
        '<p class="mt-1 text-center text-[12px] text-slate2">هتنتقل لقسم «المهام الملغاة» وتقدر تستعيدها بعدين.</p>' +
        '<div class="mt-3 grid grid-cols-2 gap-3"><button id="vCancelYes" class="btn-red">نعم، ألغِ المهمة</button><button id="vDelNo" class="btn-outline">رجوع</button></div>';
    } else if (confirmDel) {
      actions = '<p class="mt-5 text-center text-[15px] font-bold text-red-500">هل تريد حذف هذه المهمة نهائيًا؟</p>' +
        '<div class="mt-3 grid grid-cols-2 gap-3"><button id="vDelYes" class="btn-red">نعم، احذف</button><button id="vDelNo" class="btn-outline">إلغاء</button></div>';
    } else {
      actions = '<div class="mt-5 grid grid-cols-2 gap-3">' +
        '<button id="vEdit" class="btn-primary"><i class="fa-solid fa-pen me-2"></i>تعديل</button>' +
        '<button id="vPrint" class="btn-outline"><i class="fa-solid fa-print me-2"></i>طباعة</button></div>' +
        (t.canceled
          ? '<button id="vRestore" class="btn-green mt-3 w-full"><i class="fa-solid fa-rotate-left me-2"></i>استعادة المهمة</button>'
          : '<button id="vDone" class="btn-green mt-3 w-full"><i class="fa-solid fa-check me-2"></i>' + (t.done ? 'إرجاعها إلى الجارية' : 'تحديد كمنجزة') + '</button>') +
        (isOpen(t)
          ? '<div class="mt-3 grid grid-cols-2 gap-3"><button id="vCancelAsk" class="btn-outline"><i class="fa-solid fa-ban me-2"></i>إلغاء المهمة</button><button id="vDel" class="btn-danger"><i class="fa-solid fa-trash me-2"></i>حذف</button></div>'
          : '<button id="vDel" class="btn-danger mt-3 w-full"><i class="fa-solid fa-trash me-2"></i>حذف</button>');
    }
    var snzBtn = isOpen(t) || zs.length
      ? '<button id="vSnz" class="snz-ico" aria-label="سجل التأجيلات وإضافة فترة أخرى"><i class="fa-solid fa-clock-rotate-left"></i><b>' + (zs.length || '+') + '</b></button>' : '';

    var wrap = openSheet(
      (s === 'expired' ? '<div class="mb-3 flex items-center gap-2 rounded-xl bg-red-500 px-3 py-2 text-[13px] font-bold text-white"><i class="fa-solid fa-triangle-exclamation"></i>انتهى وقت هذه المهمة دون إنجاز</div>' : '') +
      '<div class="flex items-start gap-3">'+ taskIco(t, true) + '<h3 class="sheet-title min-w-0 flex-1" style="overflow-wrap:anywhere">' + esc(t.title) + '</h3>' + snzBtn + '</div>' +
      '<div class="mt-2 flex flex-wrap gap-2"><span class="chip ' + STATUS_CHIP[s] + '">' + STATUS_TXT[s] + '</span>' + catChip(t) + pri + '</div>' +
      (zs.length ? '<button id="vSnzSum" class="snz-sum snz-sum-btn mt-3 w-full text-start"><span class="font-extrabold"><i class="fa-solid fa-clock-rotate-left me-1"></i>تم مد فترة المهمة إلى فترة إضافية</span>' +
        '<span class="mt-0.5 block text-[12px]">' + zs.length + (zs.length === 1 ? ' مرة' : ' مرات') + ' · إجمالي المد ' + esc(snzTxt(snzTotal(t))) + ' · اضغط لعرض السجل</span></button>' : '') +
      '<div id="cd" class="mt-4">' + countdownHtml(t) + '</div>' +
      '<div class="mt-4 space-y-2.5">' +
      drow('fa-play', 'البداية', esc(fullDate(t.startDate) + (t.startTime ? ' · ' + fmtTime(t.startTime, true) : ''))) +
      drow('fa-flag-checkered', 'النهاية', esc(fullDate(t.endDate) + (t.endTime ? ' · ' + fmtTime(t.endTime, true) : ''))) +
      drow('fa-location-dot', 'المكان', esc(t.place || '—')) +
      drow('fa-bell', 'التذكير', esc(remindTxt(t.remind))) +
      drow('fa-note-sticky', 'الملاحظات', t.notes ? esc(t.notes) : '—') +
      drow('fa-circle-info', t.done ? 'تاريخ الإنجاز' : t.canceled ? 'تاريخ الإلغاء' : 'تاريخ الإنشاء',
        esc(t.done && t.doneAt ? new Date(t.doneAt).toLocaleDateString(LOCALE, { day: 'numeric', month: 'long', year: 'numeric' }) : t.canceled && t.canceledAt ? new Date(t.canceledAt).toLocaleDateString(LOCALE, { day: 'numeric', month: 'long', year: 'numeric' }) : created)) +
      '</div>' + actions
    );

    if (confirmDel) {
      if (confirmDel === 'cancel') $('#vCancelYes', wrap).addEventListener('click', function () { cancelTask(id); taskView(id, false); });
      else $('#vDelYes', wrap).addEventListener('click', function () {
        state.tasks = state.tasks.filter(function (x) { return x.id !== id; });
        save(); afterTaskChange(); closeSheet(); toast('تم حذف المهمة');
      });
      $('#vDelNo', wrap).addEventListener('click', function () { taskView(id, false); });
      return;
    }
    var on = function (sel, fn) { var el = $(sel, wrap); if (el) el.addEventListener('click', fn); };
    on('#vEdit', function () { taskForm(id); });
    on('#vPrint', function () { printTask(t); });
    on('#vDone', function () { setDone(id, !t.done); taskView(id, false); });
    on('#vRestore', function () { restoreTask(id); taskView(id, false); });
    on('#vCancelAsk', function () {
      confirmBox({ title: 'إلغاء المهمة', msg: 'المهمة «' + t.title + '» هتنتقل لقسم «المهام الملغاة» وتقدر تستعيدها بعدين.', ok: 'نعم، ألغِ المهمة', cancel: 'رجوع', tone: 'warn', icon: 'fa-ban' }, function () { cancelTask(id); taskView(id, false); });
    });
    on('#vDel', function () {
      confirmBox({ title: 'حذف المهمة', msg: 'هتتحذف «' + t.title + '» نهائيًا مع سجل تأجيلاتها، ولا يمكن التراجع.', ok: 'نعم، احذف', cancel: 'إلغاء', icon: 'fa-trash-can' }, function () {
        state.tasks = state.tasks.filter(function (x) { return x.id !== id; });
        save(); afterTaskChange(); closeSheet(); toast('تم حذف المهمة');
      });
    });
    on('#vSnz', function () { snoozeSheet(id); });
    on('#vSnzSum', function () { snoozeSheet(id); });
  }

  /* ----- نموذج التسجيل / التعديل (مع التحقق الصارم من التواريخ) ----- */
  function taskForm(id, presetCat) {
    var t = id ? findTask(id) : null;
    var d = t || { title: '', notes: '', cat: 'personal', startDate: TODAY, startTime: '', endDate: TODAY, endTime: '', place: '', priority: 'mid', remind: 60 };
    var pri = d.priority || 'mid', cat = t ? catOf(d) : (CATS[presetCat] ? presetCat : 'personal');
    // تاريخ البداية لا يسبق اليوم (في التعديل: نسمح بتاريخ البداية القديم لو ما اتغيّرش)
    var startMin = t && d.startDate < TODAY ? d.startDate : TODAY;

    var wrap = openSheet(
      '<h3 class="sheet-title">' + (t ? 'تعديل المهمة' : 'مهمة جديدة') + '</h3>' +
      '<form id="tf" novalidate>' +
      '<label class="label" for="tfT">اسم المهمة</label><div class="flex items-end gap-3"><button type="button" id="tfIcoBtn" class="ico-pick" aria-label="اختيار أيقونة للمهمة" aria-expanded="false"></button>' +
      '<input id="tfT" class="field min-w-0 flex-1" maxlength="60" value="' + esc(d.title) + '" placeholder="ماذا ستفعل؟" /></div><div id="tfIcoPanel" class="ico-panel" hidden></div>' +
      '<label class="label">التصنيف</label><div class="grid grid-cols-4 gap-2" id="tfCat">' +
      CAT_ORDER.map(function (k) { var c = CATS[k]; return '<button type="button" class="cat-btn" data-k="' + k + '"><i class="fa-solid ' + c.i + ' text-[16px]"></i>' + c.n + '</button>'; }).join('') + '</div>' +
      '<div class="mt-1 grid grid-cols-2 gap-3"><div><label class="label" for="tfSD">تاريخ البداية</label><input id="tfSD" type="date" class="field" min="' + startMin + '" value="' + esc(d.startDate || '') + '" /></div>' +
      '<div><label class="label" for="tfST">وقت البداية</label><input id="tfST" type="time" class="field" value="' + esc(d.startTime || '') + '" /></div>' +
      '<div><label class="label" for="tfED">تاريخ النهاية</label><input id="tfED" type="date" class="field" min="' + esc(d.startDate || TODAY) + '" value="' + esc(d.endDate || '') + '" /></div>' +
      '<div><label class="label" for="tfET">وقت النهاية</label><input id="tfET" type="time" class="field" value="' + esc(d.endTime || '') + '" /></div></div>' +
      '<p class="mt-1.5 text-[11px] text-royal/60">لو تركت الوقت فاضي: تبدأ 12:00 ص وتنتهي 11:59 م.</p>' +
      '<p id="tfErr" class="mt-1 min-h-[18px] text-[13px] font-bold text-red-500" role="alert"></p>' +
      '<label class="label" for="tfP">المكان</label><input id="tfP" class="field" maxlength="50" value="' + esc(d.place || '') + '" placeholder="مثال: كافيه النيل" />' +
      '<label class="label">الأولوية</label><div class="flex gap-2" id="tfPri">' +
      ['high', 'mid', 'low'].map(function (k) { return '<button type="button" class="seg-btn' + (k === pri ? ' is-on' : '') + '" data-p="' + k + '">' + PRI[k] + '</button>'; }).join('') + '</div>' +
      '<label class="label" for="tfR">تذكير صوتي</label><select id="tfR" class="field">' +
      REMIND.map(function (r) { return '<option value="' + r[0] + '"' + (r[0] === (d.remind == null ? 60 : d.remind) ? ' selected' : '') + '>' + r[1] + '</option>'; }).join('') + '</select>' +
      '<label class="label" for="tfN">ملاحظات</label><textarea id="tfN" rows="3" maxlength="300" class="field !h-24 resize-none py-2" placeholder="تفاصيل إضافية (اختياري)">' + esc(d.notes || '') + '</textarea>' +
      '<button class="btn-primary mt-5 w-full">' + (t ? 'حفظ التعديلات' : 'تسجيل المهمة') + '</button>' +
      (t ? '<button type="button" id="tfCancel" class="btn-outline mt-3 w-full">رجوع للمعاينة</button>' : '') + '</form>'
    );

    function paintCats() {
      $$('#tfCat .cat-btn', wrap).forEach(function (b) {
        var c = CATS[b.dataset.k], on = b.dataset.k === cat;
        b.style.background = on ? c.c : '';
        b.style.borderColor = on ? c.c : c.c + '55';
        b.style.color = on ? '#fff' : c.c;
      });
    }
    var icon = t && ICON_SET[t.icon] ? t.icon : '', icoGroup = 0, icoOpen = false;
    function paintIcoBtn() {
      var c = CATS[cat], cur = icon || c.i;
      $('#tfIcoBtn', wrap).innerHTML = '<i class="fa-solid ' + cur + '"></i><span class="ico-pick-pen"><i class="fa-solid fa-pen"></i></span>';
      $('#tfIcoBtn', wrap).style.background = c.c + '22'; $('#tfIcoBtn', wrap).style.color = c.c; $('#tfIcoBtn', wrap).style.borderColor = c.c;
    }
    function paintIcoPanel() {
      var box = $('#tfIcoPanel', wrap);
      box.hidden = !icoOpen;
      $('#tfIcoBtn', wrap).setAttribute('aria-expanded', icoOpen ? 'true' : 'false');
      if (!icoOpen) return;
      var c = CATS[cat].c, g = ICON_GROUPS[icoGroup];
      box.innerHTML = '<div class="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-2">' + ICON_GROUPS.map(function (x, i) {
        return '<button type="button" class="ico-tab' + (i === icoGroup ? ' is-on' : '') + '" data-g="' + i + '"><i class="fa-solid ' + x[1] + ' me-1"></i>' + x[0] + '</button>';
      }).join('') + '</div>' +
        '<div class="ico-grid" role="listbox" aria-label="أيقونات ' + g[0] + '">' + g[2].map(function (n) {
          return '<button type="button" class="ico-cell' + (n === icon ? ' is-on' : '') + '" data-i="' + n + '" role="option" aria-selected="' + (n === icon) + '" style="' + (n === icon ? 'background:' + c + ';border-color:' + c + ';color:#fff' : 'color:' + c) + '"><i class="fa-solid ' + n + '"></i></button>';
        }).join('') + '</div>' +
        '<button type="button" class="ico-reset' + (icon ? '' : ' is-on') + '" data-i="">' + (icon ? 'استخدم أيقونة التصنيف (الافتراضي)' : '✓ أيقونة التصنيف (الافتراضي)') + '</button>';
    }
    $('#tfIcoBtn', wrap).addEventListener('click', function () {
      icoOpen = !icoOpen;
      if (icoOpen && icon) { ICON_GROUPS.forEach(function (x, i) { if (x[2].indexOf(icon) > -1) icoGroup = i; }); }
      paintIcoPanel();
    });
    $('#tfIcoPanel', wrap).addEventListener('click', function (e) {
      var tb = e.target.closest('[data-g]'); if (tb) { icoGroup = +tb.dataset.g; return paintIcoPanel(); }
      var ib = e.target.closest('[data-i]'); if (ib) { icon = ib.dataset.i; icoOpen = false; paintIcoBtn(); paintIcoPanel(); }
    });
    paintCats(); paintIcoBtn();
    $$('#tfCat .cat-btn', wrap).forEach(function (b) { b.addEventListener('click', function () { cat = b.dataset.k; paintCats(); paintIcoBtn(); paintIcoPanel(); }); });
    $$('#tfPri .seg-btn', wrap).forEach(function (b) {
      b.addEventListener('click', function () {
        pri = b.dataset.p;
        $$('#tfPri .seg-btn', wrap).forEach(function (x) { x.classList.toggle('is-on', x === b); });
      });
    });

    // قواعد التواريخ (نهائية):
    //  1) تاريخ البداية لا يكون قبل اليوم   2) تاريخ النهاية لا يكون قبل البداية
    //  3) لو نفس اليوم: وقت النهاية لازم يكون بعد وقت البداية
    function dateErr() {
      var sd = $('#tfSD', wrap).value, ed = $('#tfED', wrap).value, st = $('#tfST', wrap).value, et = $('#tfET', wrap).value;
      $('#tfED', wrap).min = sd || TODAY;
      if (!sd) return ['#tfSD', 'اختر تاريخ البداية'];
      if ((!t || sd !== t.startDate) && sd < TODAY) return ['#tfSD', 'تاريخ البداية لا يمكن أن يكون قبل تاريخ اليوم'];
      if (!ed) return ['#tfED', 'اختر تاريخ النهاية'];
      if (ed < sd) return ['#tfED', 'تاريخ النهاية لا يمكن أن يكون قبل تاريخ البداية'];
      if (ed === sd && (et || '23:59') <= (st || '00:00')) return ['#tfET', 'وقت النهاية يجب أن يكون بعد وقت البداية'];
      return null;
    }
    function showErr() {
      var r = dateErr();
      $$('.field', wrap).forEach(function (f) { f.classList.remove('field-err'); });
      $('#tfErr', wrap).textContent = r ? r[1] : '';
      if (r) $(r[0], wrap).classList.add('field-err');
      return r;
    }
    ['#tfSD', '#tfED', '#tfST', '#tfET'].forEach(function (sel) {
      ['input', 'change'].forEach(function (ev) {
        $(sel, wrap).addEventListener(ev, function () {
          if (sel === '#tfSD' && !$('#tfED', wrap).value) $('#tfED', wrap).value = $('#tfSD', wrap).value;
          showErr();
        });
      });
    });
    showErr();

    $('#tf', wrap).addEventListener('submit', function (e) {
      e.preventDefault();
      var title = $('#tfT', wrap).value.trim();
      if (!title) { $('#tfT', wrap).classList.add('field-err'); return toast('اكتب اسم المهمة'); }
      var r = showErr();
      if (r) { $(r[0], wrap).focus(); return toast(r[1]); }
      var vals = {
        title: title, notes: $('#tfN', wrap).value.trim(), cat: cat, icon: icon,
        startDate: $('#tfSD', wrap).value, startTime: $('#tfST', wrap).value,
        endDate: $('#tfED', wrap).value, endTime: $('#tfET', wrap).value,
        place: $('#tfP', wrap).value.trim(), priority: pri, remind: parseInt($('#tfR', wrap).value, 10) || 0
      };
      if (t) {
        for (var k in vals) t[k] = vals[k];
        flagPast(t); t.ring = '';
        save(); afterTaskChange(); toast('تم الحفظ'); taskView(t.id, false);
      } else {
        state.tasks.unshift(makeTask(vals));
        pushNotif('fa-clock', 'royal', 'تمت إضافة مهمة', title);
        save(); afterTaskChange(); closeSheet(); toast('تم تسجيل المهمة');
      }
    });
    if (t) $('#tfCancel', wrap).addEventListener('click', function () { taskView(id, false); });
  }

  // قائمة "نوع المهمة" اللي بتظهر لما نضغط على زر +
  function typeMenu() {
    var wrap = openSheet(
      '<h3 class="sheet-title">ما نوع المهمة؟</h3><p class="mt-1 text-[13px] text-slate2">اختر النوع وهنفتحلك نموذج التسجيل.</p>' +
      '<div class="mt-4 grid grid-cols-2 gap-3">' + CAT_ORDER.map(function (k) {
        var c = CATS[k];
        return '<button class="type-btn" data-type="' + k + '" style="border-color:' + c.c + '55"><span class="type-ico" style="background:' + c.c + '"><i class="fa-solid ' + c.i + '"></i></span><span style="color:' + c.c + '">' + c.n + '</span></button>';
      }).join('') + '</div>'
    );
    $$('[data-type]', wrap).forEach(function (b) { b.addEventListener('click', function () { taskForm(null, b.dataset.type); }); });
  }

  function initTasks() {
    renderTasks();
    $('#q').addEventListener('input', renderTasks);
    $('#printAll').addEventListener('click', printAllTasks);
    route.click = function (e) {
      var d = e.target.closest('[data-done]'); if (d) return setDone(d.dataset.done, true);
      var u = e.target.closest('[data-undo]'); if (u) return setDone(u.dataset.undo, false);
      var o = e.target.closest('[data-open]'); if (o) return taskView(o.dataset.open, false);
      var f = e.target.closest('[data-filter]'); if (f) { filter = f.dataset.filter; return renderTasks(); }
      var wk = e.target.closest('[data-wk]'); if (wk) { weekOff += parseInt(wk.dataset.wk, 10); return renderTasks(); }
      var dy = e.target.closest('[data-day]'); if (dy) { dayFilter = dayFilter === dy.dataset.day ? null : dy.dataset.day; return renderTasks(); }
      if (e.target.closest('[data-day-clear]')) { dayFilter = null; return renderTasks(); }
      var c = e.target.closest('[data-catf]'); if (c) { catFilter = c.dataset.catf; return renderTasks(); }
      var rs = e.target.closest('[data-restore]'); if (rs) return restoreTask(rs.dataset.restore);
    };
  }

  /* =====================================================
     الإشعارات
     ===================================================== */
  function renderNotifs() {
    var box = $('#notifs');
    var bg = { royal: 'bg-royal', ember: 'bg-ember', leaf: 'bg-leaf', red: 'bg-red-500' };
    var pg = paginate('notifs', state.notifs, 8, renderNotifs);
    box.innerHTML = pg.items.length ? pg.items.map(function (n) {
      return '<button class="notif' + (n.read ? ' is-read' : '') + '" data-n="' + n.id + '">' +
        '<span class="notif-ico ' + (bg[n.tone] || 'bg-royal') + '"><i class="fa-solid ' + n.icon + '"></i></span>' +
        '<span class="min-w-0 flex-1"><span class="block text-[15px] font-bold text-royal">' + esc(n.title) + '</span>' +
        '<span class="block truncate text-[13px] text-slate2">' + esc(n.sub) + '</span></span>' +
        (n.read ? '' : '<span class="h-2.5 w-2.5 shrink-0 rounded-full bg-ember"></span>') + '</button>';
    }).join('') + pg.html : '<p class="py-10 text-center text-[14px] text-royal/60">لا توجد إشعارات.</p>';
  }
  function initNotifs() {
    renderNotifs();
    $('#notifs').addEventListener('click', function (e) {
      var b = e.target.closest('[data-n]'); if (!b) return;
      var n = state.notifs.filter(function (x) { return x.id === b.dataset.n; })[0];
      n.read = !n.read; save(); renderNotifs(); renderNav();
    });
    $('#readAll').addEventListener('click', function () {
      state.notifs.forEach(function (n) { n.read = true; });
      save(); renderNotifs(); renderNav(); toast('تم تحديد الكل كمقروء');
    });
  }

  /* =====================================================
     الثيمات + الصورة الشخصية
     ===================================================== */
  // royal, brand, navy, g1, g2, g3, g4
  var TH = {
    aqua:   { n: 'فيروزي',  v: ['24 150 186', '112 210 232', '28 96 122', '98 203 228', '143 220 238', '205 238 246', '238 249 252'] },
    blue:   { n: 'أزرق',    v: ['52 111 214', '110 160 245', '28 70 140', '84 140 240', '140 184 250', '205 224 252', '238 244 254'] },
    green:  { n: 'أخضر',    v: ['30 160 110', '100 215 165', '20 100 72', '70 200 150', '130 225 185', '200 243 226', '237 250 243'] },
    purple: { n: 'بنفسجي',  v: ['120 90 210', '175 150 240', '70 50 140', '140 110 230', '180 160 245', '224 215 250', '244 241 254'] },
    rose:   { n: 'وردي',    v: ['214 70 120', '245 140 175', '140 40 80', '238 110 150', '247 160 190', '252 215 228', '254 241 246'] },
    orange: { n: 'برتقالي', v: ['225 110 40', '250 175 110', '140 70 20', '240 140 70', '250 185 130', '253 226 200', '254 245 237'] }
  };
  var TH_KEYS = ['--royal', '--brand', '--navy', '--g1', '--g2', '--g3', '--g4'];
  function applyTheme(pg) {
    var b = document.body, t = TH[state.user.theme];
    TH_KEYS.forEach(function (k, i) {
      if (pg === 'welcome' || !t) b.style.removeProperty(k); // الصفحة الأولى تفضل زي ما هي
      else b.style.setProperty(k, t.v[i]);
    });
  }
  var AV_COLORS = ['#1896ba', '#7c5cd6', '#e08a2e', '#e0507a', '#2f9e6e', '#c98f12', '#16a6b6', '#6b7a99'];
  function avatarHtml(u) {
    u = u || state.user;
    var a = u.avatar || { t: 'art' };
    if (a.t === 'photo' && a.src) return '<img src="' + esc(a.src) + '" alt="" class="h-full w-full object-cover" draggable="false" />';
    if (a.t === 'init') {
      var ch = Array.from((u.name || 'أ').trim())[0] || 'أ';
      return '<svg viewBox="0 0 64 64" class="h-full w-full" aria-hidden="true"><rect width="64" height="64" fill="' + AV_COLORS[a.c % AV_COLORS.length] + '"/>' +
        '<text x="32" y="33" text-anchor="middle" dominant-baseline="central" font-size="32" font-weight="800" fill="#fff" font-family="Cairo Variable, sans-serif">' + esc(ch.toUpperCase()) + '</text></svg>';
    }
    return avatar();
  }

  /* =====================================================
     الأمان: كلمة مرور أو نمط
     - التخزين: PBKDF2-SHA256 (200 ألف دورة) + ملح عشوائي، ومفيش حفظ للسر نفسه
     - حماية من التخمين: بعد 5 محاولات غلط يتوقف التطبيق مؤقتًا وبيزيد الوقت كل مرة
     - تغيير أو إيقاف القفل بيتطلب كتابة الحالي الأول
     ===================================================== */
  var SEC_KEY = 'engazy.sec.v1', SS_KEY = 'engazy.u';
  var sec = (function () { try { return JSON.parse(localStorage.getItem(SEC_KEY)) || {}; } catch (e) { return {}; } })();
  function secSave() { try { localStorage.setItem(SEC_KEY, JSON.stringify(sec)); } catch (e) {} }
  function hasLock() { return !!(sec && sec.hash); }
  var profileRefresh = null;

  function toHex(u8) { var s = ''; for (var i = 0; i < u8.length; i++) s += (u8[i] < 16 ? '0' : '') + u8[i].toString(16); return s; }
  function fromHex(h) { var a = new Uint8Array(h.length / 2); for (var i = 0; i < a.length; i++) a[i] = parseInt(h.substr(i * 2, 2), 16); return a; }
  function randBytes(n) {
    var a = new Uint8Array(n);
    if (window.crypto && crypto.getRandomValues) crypto.getRandomValues(a);
    else for (var i = 0; i < n; i++) a[i] = Math.floor(Math.random() * 256);
    return a;
  }
  function safeEq(a, b) {
    if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
    var d = 0;
    for (var i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
    return d === 0;
  }

  // SHA-256 بالـ JavaScript (احتياطي للمتصفحات اللي مفيهاش WebCrypto)
  var K256 = [], H256 = [];
  (function () {
    var n = 0, p = 2;
    while (n < 64) {
      var prime = true;
      for (var i = 2; i * i <= p; i++) if (p % i === 0) { prime = false; break; }
      if (prime) {
        if (n < 8) H256[n] = (Math.pow(p, 1 / 2) % 1) * 4294967296 | 0;
        K256[n] = (Math.pow(p, 1 / 3) % 1) * 4294967296 | 0;
        n++;
      }
      p++;
    }
  })();
  function sha256(msg) {
    var l = msg.length, buf = new Uint8Array(((l + 9 + 63) >> 6) << 6);
    buf.set(msg); buf[l] = 0x80;
    var dv = new DataView(buf.buffer);
    dv.setUint32(buf.length - 4, (l * 8) >>> 0);
    dv.setUint32(buf.length - 8, Math.floor(l / 0x20000000));
    var h = H256.slice(), w = new Array(64), i;
    for (var o = 0; o < buf.length; o += 64) {
      for (i = 0; i < 16; i++) w[i] = dv.getUint32(o + i * 4);
      for (i = 16; i < 64; i++) {
        var a15 = w[i - 15], a2 = w[i - 2];
        var s0 = ((a15 >>> 7) | (a15 << 25)) ^ ((a15 >>> 18) | (a15 << 14)) ^ (a15 >>> 3);
        var s1 = ((a2 >>> 17) | (a2 << 15)) ^ ((a2 >>> 19) | (a2 << 13)) ^ (a2 >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
      }
      var A = h[0], B = h[1], C = h[2], D = h[3], E = h[4], F = h[5], G = h[6], Hh = h[7];
      for (i = 0; i < 64; i++) {
        var S1 = ((E >>> 6) | (E << 26)) ^ ((E >>> 11) | (E << 21)) ^ ((E >>> 25) | (E << 7));
        var ch = (E & F) ^ (~E & G);
        var t1 = (Hh + S1 + ch + K256[i] + w[i]) | 0;
        var S0 = ((A >>> 2) | (A << 30)) ^ ((A >>> 13) | (A << 19)) ^ ((A >>> 22) | (A << 10));
        var mj = (A & B) ^ (A & C) ^ (B & C);
        var t2 = (S0 + mj) | 0;
        Hh = G; G = F; F = E; E = (D + t1) | 0; D = C; C = B; B = A; A = (t1 + t2) | 0;
      }
      h[0] = (h[0] + A) | 0; h[1] = (h[1] + B) | 0; h[2] = (h[2] + C) | 0; h[3] = (h[3] + D) | 0;
      h[4] = (h[4] + E) | 0; h[5] = (h[5] + F) | 0; h[6] = (h[6] + G) | 0; h[7] = (h[7] + Hh) | 0;
    }
    var out = new Uint8Array(32), ov = new DataView(out.buffer);
    for (i = 0; i < 8; i++) ov.setUint32(i * 4, h[i] >>> 0);
    return out;
  }

  // اشتقاق المفتاح: PBKDF2 لو متاح، وإلا SHA-256 متكرر 20 ألف مرة
  function kdf(secret, salt, algo) {
    var data = new TextEncoder().encode(secret.normalize ? secret.normalize('NFKC') : secret);
    var hasSub = !!(window.crypto && crypto.subtle && crypto.subtle.importKey);
    if ((!algo || algo === 'pbkdf2') && hasSub) {
      return crypto.subtle.importKey('raw', data, 'PBKDF2', false, ['deriveBits'])
        .then(function (k) { return crypto.subtle.deriveBits({ name: 'PBKDF2', salt: salt, iterations: 200000, hash: 'SHA-256' }, k, 256); })
        .then(function (b) { return { algo: 'pbkdf2', hex: toHex(new Uint8Array(b)) }; });
    }
    if (algo === 'pbkdf2') return Promise.resolve(null);
    return new Promise(function (res) {
      setTimeout(function () {
        var x = new Uint8Array(salt.length + data.length); x.set(salt); x.set(data, salt.length);
        var h = sha256(x);
        for (var i = 0; i < 20000; i++) {
          var y = new Uint8Array(32 + salt.length + data.length); y.set(h); y.set(salt, 32); y.set(data, 32 + salt.length);
          h = sha256(y);
        }
        res({ algo: 'sha256x', hex: toHex(h) });
      }, 30);
    });
  }

  function lockWait() { return Math.max(0, Math.ceil(((sec.until || 0) - Date.now()) / 1000)); }
  function waitTxt(w) { return w < 60 ? w + ' ثانية' : durTxt(w * 1000); }
  // محاولة فتح: بتحسب الفشل المتتالي وبتوقف المحاولات مؤقتًا (30ث ثم تتضاعف حتى ساعة)
  function attempt(secret) {
    var w = lockWait();
    if (w > 0) return Promise.resolve({ ok: false, wait: w });
    return kdf(secret, fromHex(sec.salt), sec.algo).then(function (r) {
      if (!r) return { ok: false, unsupported: true };
      if (safeEq(r.hex, sec.hash)) { sec.fails = 0; sec.until = 0; secSave(); return { ok: true }; }
      sec.fails = (sec.fails || 0) + 1;
      if (sec.fails >= 5) sec.until = Date.now() + Math.min(30 * Math.pow(2, sec.fails - 5), 3600) * 1000;
      secSave();
      return { ok: false, wait: lockWait(), left: Math.max(0, 5 - sec.fails) };
    });
  }

  function touchActive() { try { sessionStorage.setItem(SS_KEY, String(Date.now())); } catch (e) {} }
  function isUnlocked() {
    if (!hasLock()) return true;
    try {
      var t = +sessionStorage.getItem(SS_KEY);
      if (!t) return false;
      var m = sec.auto == null ? 5 : sec.auto;
      return m === 0 || Date.now() - t < m * 60000;
    } catch (e) { return false; }
  }
  /* ----- الخمول: بعد 5 دقايق (أو مدة القفل التلقائي) من غير لمس نرجع للشاشة الأولى، والدخول بيطلب السر/النمط ----- */
  var lastAct = Date.now();
  ['pointerdown', 'keydown', 'touchstart', 'scroll', 'wheel'].forEach(function (ev) {
    document.addEventListener(ev, function () { lastAct = Date.now(); }, true);
  });
  setInterval(function () {
    if (!page || page === 'welcome') { lastAct = Date.now(); return; }
    if ($('#alarm') || $('#halarm')) { lastAct = Date.now(); return; } // المنبّه شغال: ما نبعدش المستخدم عنه
    var mins = sec && sec.auto > 0 ? sec.auto : 5;
    if (Date.now() - lastAct < mins * 60000) return;
    if (hasLock()) { try { sessionStorage.removeItem(SS_KEY); } catch (e) {} }
    lastAct = Date.now();
    var old = $('#sheet'); if (old) old.remove();
    var md = $('.modal'); if (md) md.remove();
    if (STANDALONE) location.hash = '#welcome'; else location.href = 'index.html';
  }, 10000);
  function lockNow() { try { sessionStorage.removeItem(SS_KEY); } catch (e) {} showLock(); }
  document.addEventListener('pointerdown', function () { if (hasLock() && page && page !== 'welcome' && !$('.lock')) touchActive(); }, true);
  document.addEventListener('keydown', function () { if (hasLock() && page && page !== 'welcome' && !$('.lock')) touchActive(); }, true);

  function wipeAll() {
    try { localStorage.removeItem(KEY); localStorage.removeItem(SEC_KEY); localStorage.removeItem('engazy.dbfile'); sessionStorage.removeItem(SS_KEY); } catch (e) {}
    var fin = function () { if (STANDALONE) { location.hash = '#welcome'; location.reload(); } else location.href = 'index.html'; };
    clearTimeout(persistTimer); persistTimer = null; dbOK = false;
    Promise.all([idbDel('main'), idbDel('rev')]).then(fin, fin);
  }

  /* ----- لوحة النمط 3×3 ----- */
  function makePad(box, onDone) {
    box.classList.add('pad'); box.setAttribute('dir', 'ltr');
    var h = '<svg class="pad-svg" viewBox="0 0 240 240"><polyline class="pad-line" points=""/></svg>';
    for (var i = 0; i < 9; i++) h += '<span class="pad-dot" style="left:' + (40 + (i % 3) * 80) / 2.4 + '%;top:' + (40 + Math.floor(i / 3) * 80) / 2.4 + '%"><i></i></span>';
    box.innerHTML = h;
    var dots = $$('.pad-dot', box), line = $('.pad-line', box), seq = [], drawing = false, off = false;
    function pt(e) { var r = box.getBoundingClientRect(); return { x: (e.clientX - r.left) * 240 / r.width, y: (e.clientY - r.top) * 240 / r.height }; }
    function hit(p) {
      for (var i = 0; i < 9; i++) if (Math.hypot(p.x - (40 + (i % 3) * 80), p.y - (40 + Math.floor(i / 3) * 80)) < 34) return i;
      return -1;
    }
    function draw(cur) {
      var pts = seq.map(function (i) { return (40 + (i % 3) * 80) + ',' + (40 + Math.floor(i / 3) * 80); });
      if (cur) pts.push(cur.x.toFixed(1) + ',' + cur.y.toFixed(1));
      line.setAttribute('points', pts.join(' '));
    }
    function add(i) { if (i < 0 || seq.indexOf(i) > -1) return; seq.push(i); dots[i].classList.add('on'); }
    function reset() { seq = []; line.setAttribute('points', ''); dots.forEach(function (d) { d.classList.remove('on'); }); box.classList.remove('bad'); }
    function end() {
      if (!drawing) return;
      drawing = false; draw(null);
      if (seq.length < 2) return reset();
      onDone(seq.join('-'), seq.length);
    }
    box.addEventListener('pointerdown', function (e) {
      if (off) return;
      e.preventDefault(); reset(); drawing = true;
      try { box.setPointerCapture(e.pointerId); } catch (x) {}
      var p = pt(e); add(hit(p)); draw(p);
    });
    box.addEventListener('pointermove', function (e) { if (!drawing) return; var p = pt(e); add(hit(p)); draw(p); });
    box.addEventListener('pointerup', end);
    box.addEventListener('pointercancel', end);
    return {
      reset: reset,
      disable: function (v) { off = v; box.classList.toggle('off', v); },
      fail: function () { box.classList.add('bad'); setTimeout(reset, 700); }
    };
  }

  /* ----- واجهة إدخال السر الحالي (بتستخدم في شاشة القفل وفي تأكيد الهوية) ----- */
  function credUI(root, onOk, label) {
    var mode = sec.mode, timer = null, busy = false;
    root.innerHTML = (mode === 'pass'
      ? '<form class="cred-f" autocomplete="off"><div class="cred-in"><input class="cred-input" type="password" maxlength="64" autocomplete="off" placeholder="كلمة المرور" aria-label="كلمة المرور" />' +
        '<button type="button" class="cred-eye" aria-label="إظهار كلمة المرور"><i class="fa-regular fa-eye"></i></button></div><button class="cred-btn">' + (label || 'فتح') + '</button></form>'
      : '<div class="cred-pad"></div>') + '<p class="cred-msg" role="alert"></p>';
    var msg = $('.cred-msg', root), input = $('.cred-input', root), pad = null;
    function setDisabled(v) {
      if (input) { input.disabled = v; $('.cred-btn', root).disabled = v; }
      if (pad) pad.disable(v);
    }
    function tickWait() {
      if (!root.isConnected) { clearInterval(timer); return; }
      var w = lockWait();
      if (w > 0) { msg.textContent = 'تم إيقاف المحاولات مؤقتًا. حاول بعد ' + waitTxt(w); setDisabled(true); }
      else { clearInterval(timer); timer = null; msg.textContent = ''; setDisabled(false); if (input) input.focus(); }
    }
    function startWait() { clearInterval(timer); tickWait(); if (lockWait() > 0) timer = setInterval(tickWait, 1000); }
    function submit(secret, onFail) {
      if (busy) return;
      busy = true; setDisabled(true); msg.textContent = 'جارٍ التحقق…';
      attempt(secret).then(function (r) {
        busy = false;
        if (r.ok) { clearInterval(timer); msg.textContent = ''; onOk(); return; }
        if (r.unsupported) { setDisabled(false); msg.textContent = 'المتصفح ده مش بيدعم التحقق المحفوظ'; return; }
        if (r.wait > 0) startWait();
        else { setDisabled(false); msg.textContent = (mode === 'pass' ? 'كلمة المرور غير صحيحة' : 'النمط غير صحيح') + ' — المحاولات المتبقية قبل الإيقاف المؤقت: ' + r.left; }
        onFail();
      });
    }
    if (mode === 'pass') {
      $('.cred-eye', root).addEventListener('click', function () {
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        $('i', this).className = show ? 'fa-regular fa-eye-slash' : 'fa-regular fa-eye';
      });
      $('.cred-f', root).addEventListener('submit', function (e) {
        e.preventDefault();
        if (!input.value) { msg.textContent = 'اكتب كلمة المرور'; return; }
        submit('p:' + input.value, function () { input.value = ''; input.focus(); });
      });
    } else {
      pad = makePad($('.cred-pad', root), function (seq) { submit('g:' + seq, function () { pad.fail(); }); });
    }
    if (lockWait() > 0) startWait(); else if (input) setTimeout(function () { try { input.focus(); } catch (e) {} }, 50);
  }

  /* ----- شاشة القفل ----- */
  function showLock() {
    if (!phone || !hasLock() || $('.lock', phone)) return;
    closeSheet();
    var wrap = document.createElement('div');
    wrap.className = 'lock';
    wrap.innerHTML = '<div class="lock-av">' + avatarHtml() + '</div>' +
      '<p class="mt-3 text-[22px] font-black">' + esc(state.user.name || 'أحمد') + '</p>' +
      '<p class="mb-5 mt-1 text-[14px] font-semibold opacity-90"><i class="fa-solid fa-lock me-1"></i>' + (sec.mode === 'pass' ? 'أدخل كلمة المرور لفتح إنجازي' : 'ارسم النمط لفتح إنجازي') + '</p>' +
      '<div id="lkBox" class="w-full max-w-[300px]"></div>' +
      '<button id="lkForgot" class="mt-auto pb-6 text-[13px] font-bold underline opacity-90">نسيت كلمة المرور / النمط؟</button>';
    phone.appendChild(wrap);
    credUI($('#lkBox', wrap), function () {
      touchActive(); wrap.classList.add('out'); setTimeout(function () { wrap.remove(); }, 250);
    }, 'فتح');
    $('#lkForgot', wrap).addEventListener('click', function () {
      wrap.innerHTML = '<i class="fa-solid fa-triangle-exclamation mt-6 text-[40px]"></i>' +
        '<p class="mt-3 text-[20px] font-black">مسح كل البيانات؟</p>' +
        '<p class="mt-2 max-w-[290px] text-center text-[14px] leading-relaxed">مفيش طريقة لاسترجاع كلمة المرور، وده بيحمي بياناتك. لو كملت هنمسح كل المهام والإعدادات والقفل ونبدأ من جديد.</p>' +
        '<input id="fgIn" class="cred-input mt-5 max-w-[260px]" placeholder="اكتب كلمة: مسح" autocomplete="off" />' +
        '<button id="fgGo" class="cred-btn mt-3 !max-w-[260px] !bg-red-600 !text-white" disabled>مسح كل شيء</button>' +
        '<button id="fgBack" class="mt-4 text-[14px] font-bold underline">رجوع</button>';
      $('#fgIn', wrap).addEventListener('input', function (e) { $('#fgGo', wrap).disabled = e.target.value.trim() !== 'مسح'; });
      $('#fgGo', wrap).addEventListener('click', wipeAll);
      $('#fgBack', wrap).addEventListener('click', function () { wrap.remove(); showLock(); });
    });
  }
  function gate() {
    if (page === 'welcome' || !hasLock()) return;
    if (isUnlocked()) touchActive(); else showLock();
  }

  /* ----- تأكيد الهوية (لازم السر الحالي قبل أي تغيير) ----- */
  function verifySheet(title, hint, onOk) {
    var wrap = openSheet('<h3 class="sheet-title"><i class="fa-solid fa-shield-halved me-2"></i>' + esc(title) + '</h3>' +
      '<p class="mb-4 mt-1 text-[13px] text-slate2">' + esc(hint) + '</p><div id="vBox"></div>' +
      '<button class="btn-outline mt-4 w-full" data-close>إلغاء</button>');
    credUI($('#vBox', wrap), onOk, 'تأكيد');
  }

  /* ----- قوة كلمة المرور ----- */
  var COMMON = ['12345678', '123456789', '1234567890', 'password', 'password1', 'password123', 'qwertyui', 'qwerty123', 'abc12345', 'iloveyou', '11111111', '00000000', '87654321', '12341234', 'admin123', 'welcome1', '123123123', 'letmein1', '1q2w3e4r', 'asdfghjk', 'zxcvbnm1', 'engazy123', 'engazy12', 'p@ssw0rd', 'passw0rd', 'abcd1234', 'a1234567', 'aa123456'];
  var SEQS = ['0123456789', '9876543210', 'abcdefghijklmnopqrstuvwxyz', 'zyxwvutsrqponmlkjihgfedcba', 'qwertyuiop', 'poiuytrewq', 'asdfghjkl', 'lkjhgfdsa', 'zxcvbnm', 'mnbvcxz', '1q2w3e4r5t6y'];
  function pwEval(pw, name) {
    var low = pw.toLowerCase(), has = [/[a-z]/.test(pw), /[A-Z]/.test(pw), /[0-9]/.test(pw), /[^a-zA-Z0-9]/.test(pw)];
    var classes = has.filter(Boolean).length;
    var pool = (has[0] ? 26 : 0) + (has[1] ? 26 : 0) + (has[2] ? 10 : 0) + (has[3] ? 33 : 0);
    var bits = pool ? Math.round(pw.length * Math.log(pool) / Math.LN2) : 0;
    var easy = COMMON.indexOf(low) > -1 || /^(.)\1+$/.test(pw) || /^(.{1,3})\1+$/.test(low) ||
      (low.length >= 4 && SEQS.some(function (q) { return q.indexOf(low) > -1; })) ||
      (name && name.trim().length >= 3 && low.indexOf(name.trim().toLowerCase()) > -1);
    var len = pw.length >= 8;
    return { len: len, classes: classes, kinds: classes >= 3, easy: easy, bits: bits, ok: len && classes >= 3 && !easy && bits >= 45 };
  }

  function saveSecret(mode, secret, done) {
    var salt = randBytes(16);
    kdf(secret, salt).then(function (r) {
      sec.mode = mode; sec.salt = toHex(salt); sec.hash = r.hex; sec.algo = r.algo; sec.fails = 0; sec.until = 0;
      if (sec.auto == null) sec.auto = 5;
      secSave(); touchActive(); done();
    });
  }
  // نمنع إعادة نفس السر الحالي
  function sameAsCurrent(mode, secret) {
    if (!hasLock() || sec.mode !== mode) return Promise.resolve(false);
    return kdf(secret, fromHex(sec.salt), sec.algo).then(function (r) { return !!r && safeEq(r.hex, sec.hash); });
  }

  function chooseMode(cb) {
    var wrap = openSheet('<h3 class="sheet-title">اختر نوع القفل</h3><p class="mt-1 text-[13px] text-slate2">النمط لازم 5 نقاط على الأقل، وكلمة المرور لازم تكون قوية.</p>' +
      '<div class="mt-4 grid grid-cols-2 gap-3">' +
      '<button class="type-btn" data-m="pass" style="border-color:rgb(var(--royal) / .35)"><span class="type-ico" style="background:rgb(var(--royal))"><i class="fa-solid fa-key"></i></span><span class="text-royal">كلمة مرور</span></button>' +
      '<button class="type-btn" data-m="pattern" style="border-color:rgb(var(--royal) / .35)"><span class="type-ico" style="background:rgb(var(--royal))"><i class="fa-solid fa-grip"></i></span><span class="text-royal">نمط</span></button></div>' +
      '<button class="btn-outline mt-4 w-full" data-close>إلغاء</button>');
    $$('[data-m]', wrap).forEach(function (b) { b.addEventListener('click', function () { cb(b.dataset.m); }); });
  }

  function setupPass(done) {
    var wrap = openSheet('<h3 class="sheet-title">كلمة مرور جديدة</h3>' +
      '<form id="spF" autocomplete="off"><label class="label" for="spA">كلمة المرور</label>' +
      '<div class="cred-in light"><input id="spA" class="cred-input" type="password" maxlength="64" autocomplete="new-password" /><button type="button" class="cred-eye" data-eye aria-label="إظهار"><i class="fa-regular fa-eye"></i></button></div>' +
      '<div class="pw-meter"><i id="spBar"></i></div><p id="spLvl" class="mt-1 text-[12px] font-bold text-slate2">اكتب كلمة مرور</p>' +
      '<ul id="spRules" class="mt-2 space-y-1 text-[13px] font-semibold">' +
      '<li data-r="len">8 أحرف أو أكثر (الأفضل 12)</li><li data-r="kinds">3 أنواع على الأقل: حروف صغيرة، كبيرة، أرقام، رموز</li>' +
      '<li data-r="easy">مش شائعة ولا متكررة ولا فيها اسمك</li><li data-r="same">التأكيد مطابق</li></ul>' +
      '<label class="label" for="spB">تأكيد كلمة المرور</label>' +
      '<div class="cred-in light"><input id="spB" class="cred-input" type="password" maxlength="64" autocomplete="new-password" /></div>' +
      '<p id="spErr" class="mt-2 min-h-[18px] text-[13px] font-bold text-red-500" role="alert"></p>' +
      '<button id="spGo" class="btn-primary mt-2 w-full" disabled>حفظ كلمة المرور</button><button type="button" class="btn-outline mt-3 w-full" data-close>إلغاء</button></form>');
    var A = $('#spA', wrap), B = $('#spB', wrap), go = $('#spGo', wrap), ok = false;
    $('[data-eye]', wrap).addEventListener('click', function () {
      var show = A.type === 'password'; A.type = B.type = show ? 'text' : 'password';
      $('i', this).className = show ? 'fa-regular fa-eye-slash' : 'fa-regular fa-eye';
    });
    function mark(k, v) { var li = $('[data-r=' + k + ']', wrap); li.classList.toggle('ok', v); li.innerHTML = '<i class="fa-solid ' + (v ? 'fa-circle-check' : 'fa-circle') + ' me-1.5"></i>' + li.textContent; }
    function update() {
      var r = pwEval(A.value, state.user.name), same = A.value.length > 0 && A.value === B.value;
      mark('len', r.len); mark('kinds', r.kinds); mark('easy', A.value.length > 0 && !r.easy); mark('same', same);
      var lvl = !A.value ? 0 : !r.ok ? 1 : r.bits < 60 ? 2 : r.bits < 80 ? 3 : 4;
      $('#spBar', wrap).style.width = [0, 25, 50, 75, 100][lvl] + '%';
      $('#spBar', wrap).style.background = ['', '#ef4444', '#f59e0b', '#22c55e', '#15803d'][lvl];
      $('#spLvl', wrap).textContent = ['اكتب كلمة مرور', 'ضعيفة', 'مقبولة', 'قوية', 'قوية جدًا'][lvl] + (A.value ? ' · ≈ ' + r.bits + ' بت' : '');
      ok = r.ok && same; go.disabled = !ok;
    }
    A.addEventListener('input', update); B.addEventListener('input', update); update();
    $('#spF', wrap).addEventListener('submit', function (e) {
      e.preventDefault();
      if (!ok) return;
      go.disabled = true;
      sameAsCurrent('pass', 'p:' + A.value).then(function (same) {
        if (same) { $('#spErr', wrap).textContent = 'لازم تختلف عن كلمة المرور الحالية'; go.disabled = false; return; }
        saveSecret('pass', 'p:' + A.value, done);
      });
    });
  }

  function setupPattern(done) {
    var wrap = openSheet('<h3 class="sheet-title">نمط جديد</h3><p id="spHint" class="mt-1 text-[13px] text-slate2">ارسم نمطًا بـ 5 نقاط على الأقل</p>' +
      '<div id="spPad" class="mx-auto mt-4 w-[240px]"></div><p id="spErr" class="mt-3 min-h-[20px] text-center text-[13px] font-bold text-red-500" role="alert"></p>' +
      '<button class="btn-outline mt-2 w-full" data-close>إلغاء</button>');
    var first = null, err = $('#spErr', wrap), hint = $('#spHint', wrap), pad;
    pad = makePad($('#spPad', wrap), function (seq, n) {
      err.textContent = '';
      if (!first) {
        if (n < 5) { err.textContent = 'النمط قصير. لازم 5 نقاط على الأقل'; return pad.fail(); }
        sameAsCurrent('pattern', 'g:' + seq).then(function (same) {
          if (same) { err.textContent = 'لازم يختلف عن النمط الحالي'; return pad.fail(); }
          first = seq; hint.textContent = 'أعد رسم النمط للتأكيد'; pad.reset();
        });
      } else if (seq === first) {
        pad.disable(true); saveSecret('pattern', 'g:' + seq, done);
      } else {
        err.textContent = 'النمط مش مطابق. ابدأ من جديد'; first = null; hint.textContent = 'ارسم نمطًا بـ 5 نقاط على الأقل'; pad.fail();
      }
    });
  }

  /* =====================================================
     تخصيص الملف الشخصي
     ===================================================== */
  function editProfile(done) {
    var u = state.user;
    var d = { name: u.name, title: u.title || '', bio: u.bio || '', phone: u.phone || '', email: u.email || '', avatar: Object.assign({ t: 'art', c: 0, src: '' }, u.avatar), theme: u.theme || 'aqua' };
    var wrap = openSheet('<h3 class="sheet-title">تخصيص ملفي الشخصي</h3>' +
      '<div id="epAv" class="mx-auto mt-3 h-[88px] w-[88px] overflow-hidden rounded-full bg-white shadow-card"></div>' +
      '<div class="mt-3 flex gap-2" id="epType">' +
      [['art', 'رسمة'], ['init', 'حروف'], ['photo', 'صورة']].map(function (x) { return '<button type="button" class="seg-btn" data-t="' + x[0] + '">' + x[1] + '</button>'; }).join('') + '</div>' +
      '<div id="epOpts" class="mt-3 min-h-[44px]"></div>' +
      '<form id="epF" novalidate>' +
      '<label class="label" for="epN">الاسم</label><input id="epN" class="field" maxlength="20" value="' + esc(d.name) + '" />' +
      '<label class="label" for="epT">المسمى / الوظيفة</label><input id="epT" class="field" maxlength="30" value="' + esc(d.title) + '" placeholder="مثال: مصمم جرافيك" />' +
      '<label class="label" for="epB">نبذة عنك</label><textarea id="epB" rows="2" maxlength="120" class="field !h-16 resize-none py-2" placeholder="جملة قصيرة عنك">' + esc(d.bio) + '</textarea>' +
      '<label class="label" for="epP">الهاتف</label><input id="epP" class="field" dir="ltr" inputmode="tel" maxlength="20" value="' + esc(d.phone) + '" placeholder="اختياري" />' +
      '<label class="label" for="epE">البريد الإلكتروني</label><input id="epE" class="field" dir="ltr" inputmode="email" maxlength="50" value="' + esc(d.email) + '" placeholder="اختياري" />' +
      '<label class="label">لون التطبيق</label><div id="epTh" class="flex flex-wrap gap-3">' +
      Object.keys(TH).map(function (k) { var v = TH[k].v; return '<button type="button" data-th="' + k + '" aria-label="' + TH[k].n + '" class="h-10 w-10 rounded-full border-4" style="background:linear-gradient(135deg,rgb(' + v[3] + '),rgb(' + v[0] + '))"></button>'; }).join('') + '</div>' +
      '<p id="epErr" class="mt-3 min-h-[18px] text-[13px] font-bold text-red-500" role="alert"></p>' +
      '<button class="btn-primary mt-2 w-full">حفظ</button><button type="button" class="btn-outline mt-3 w-full" data-close>إلغاء</button></form>');

    function draw() {
      $('#epAv', wrap).innerHTML = avatarHtml({ name: $('#epN', wrap).value || d.name, avatar: d.avatar });
      $$('#epType .seg-btn', wrap).forEach(function (b) { b.classList.toggle('is-on', b.dataset.t === d.avatar.t); });
      $$('#epTh button', wrap).forEach(function (b) { b.classList.toggle('border-navy', b.dataset.th === d.theme); b.classList.toggle('border-white', b.dataset.th !== d.theme); b.classList.toggle('shadow', b.dataset.th !== d.theme); });
      var o = $('#epOpts', wrap);
      if (d.avatar.t === 'init') {
        o.innerHTML = '<div class="flex flex-wrap justify-center gap-2.5">' + AV_COLORS.map(function (c, i) {
          return '<button type="button" data-c="' + i + '" aria-label="لون ' + (i + 1) + '" class="h-9 w-9 rounded-full border-4 ' + (i === d.avatar.c ? 'border-navy' : 'border-white shadow') + '" style="background:' + c + '"></button>';
        }).join('') + '</div>';
        $$('[data-c]', o).forEach(function (b) { b.addEventListener('click', function () { d.avatar.c = +b.dataset.c; draw(); }); });
      } else if (d.avatar.t === 'photo') {
        o.innerHTML = '<label class="btn-outline w-full cursor-pointer"><i class="fa-solid fa-image me-2"></i>' + (d.avatar.src ? 'تغيير الصورة' : 'اختر صورة من جهازك') +
          '<input id="epFile" type="file" accept="image/*" class="hidden" /></label>';
        $('#epFile', o).addEventListener('change', function (e) {
          var f = e.target.files && e.target.files[0];
          if (!f) return;
          if (!/^image\//.test(f.type)) return toast('اختر ملف صورة');
          var rd = new FileReader();
          rd.onload = function () {
            var im = new Image();
            im.onload = function () {
              var c = document.createElement('canvas'), S = 240, m = Math.min(im.width, im.height);
              c.width = c.height = S;
              c.getContext('2d').drawImage(im, (im.width - m) / 2, (im.height - m) / 2, m, m, 0, 0, S, S);
              d.avatar.src = c.toDataURL('image/jpeg', 0.85); draw();
            };
            im.onerror = function () { toast('تعذّر قراءة الصورة'); };
            im.src = rd.result;
          };
          rd.readAsDataURL(f);
        });
      } else o.innerHTML = '<p class="text-center text-[12px] text-slate2">الرسمة الافتراضية</p>';
    }
    $$('#epType .seg-btn', wrap).forEach(function (b) { b.addEventListener('click', function () { d.avatar.t = b.dataset.t; draw(); }); });
    $$('#epTh button', wrap).forEach(function (b) { b.addEventListener('click', function () { d.theme = b.dataset.th; draw(); }); });
    $('#epN', wrap).addEventListener('input', draw);
    draw();

    $('#epF', wrap).addEventListener('submit', function (e) {
      e.preventDefault();
      var err = $('#epErr', wrap), name = $('#epN', wrap).value.trim(), em = $('#epE', wrap).value.trim(), ph = $('#epP', wrap).value.trim();
      if (!name) { err.textContent = 'اكتب اسمك'; return; }
      if (em && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em)) { err.textContent = 'البريد الإلكتروني غير صحيح'; return; }
      if (ph && !/^[0-9٠-٩+\-\s()]{6,20}$/.test(ph)) { err.textContent = 'رقم الهاتف غير صحيح'; return; }
      if (d.avatar.t === 'photo' && !d.avatar.src) d.avatar.t = 'art';
      state.user = Object.assign(state.user, { name: name, title: $('#epT', wrap).value.trim(), bio: $('#epB', wrap).value.trim(), phone: ph, email: em, avatar: d.avatar, theme: d.theme });
      save(); applyTheme(page); closeSheet(); toast('تم حفظ ملفك الشخصي'); done();
    });
  }

  /* =====================================================
     الملف الشخصي
     ===================================================== */
  function initProfile() {
    function stats() {
      var open = state.tasks.filter(isOpen).length;
      var expired = state.tasks.filter(isExpired).length;
      var done = state.tasks.filter(function (t) { return t.done; }).length;
      var list = [
        ['جارية', open - expired, 'text-royal'], ['منتهية', done, 'text-leaf'],
        ['انتهت دون إنجاز', expired, 'text-red-500'], ['مشاريع', state.projects.length, 'text-ember']
      ];
      $('#stats').innerHTML = list.map(function (s) {
        return '<div class="rounded-xl bg-white py-3 text-center shadow-[0_3px_10px_rgba(31,150,186,.10)]">' +
          '<p class="text-[28px] font-black leading-tight ' + s[2] + '">' + s[1] + '</p><p class="text-[13px] font-semibold text-slate2">' + s[0] + '</p></div>';
      }).join('');
      var total = state.tasks.length || 1;
      $('#catStats').innerHTML = CAT_ORDER.map(function (k) {
        var c = CATS[k], n = state.tasks.filter(function (t) { return catOf(t) === k; }).length;
        return '<div class="flex items-center gap-3"><span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[13px] text-white" style="background:' + c.c + '"><i class="fa-solid ' + c.i + '"></i></span>' +
          '<div class="min-w-0 flex-1"><div class="flex justify-between text-[13px] font-bold text-navy"><span>' + c.n + '</span><span>' + n + '</span></div>' +
          '<div class="bar2 !mt-1"><i style="width:' + Math.round(n / total * 100) + '%;background:' + c.c + '"></i></div></div></div>';
      }).join('');
    }
    function card() {
      var u = state.user;
      var rows = [['fa-briefcase', 'المسمى', u.title], ['fa-quote-right', 'نبذة', u.bio], ['fa-phone', 'الهاتف', u.phone], ['fa-envelope', 'البريد', u.email]].filter(function (r) { return r[2]; });
      $('#pCard').innerHTML = rows.length ? rows.map(function (r) { return drow(r[0], r[1], esc(r[2])); }).join('') :
        '<p class="rounded-xl bg-white/70 py-4 text-center text-[13px] text-slate2">لم تضف بياناتك بعد. اضغط «تعديل» لتخصيص ملفك.</p>';
      $('#pTitle').textContent = u.title || 'مستخدم إنجازي';
    }
    function settings() {
      var s = state.settings;
      $('#settings').innerHTML =
        '<div class="setrow"><span class="setico"><i class="fa-solid ' + (s.sound ? 'fa-volume-high' : 'fa-volume-xmark') + '"></i></span><div class="flex-1"><p class="text-[15px] font-bold text-navy">صوت التنبيهات</p><p class="text-[12px] text-slate2">جرس عند بداية المهمة وقرب انتهائها وانتهائها</p></div>' +
        '<button id="swSound" class="sw" role="switch" aria-checked="' + !!s.sound + '" aria-label="صوت التنبيهات"></button></div>' +
        '<div class="setrow"><span class="setico"><i class="fa-solid fa-bell"></i></span><div class="flex-1"><p class="text-[15px] font-bold text-navy">إشعارات المتصفح</p><p class="text-[12px] text-slate2">إشعار على الجهاز حتى لو التطبيق في تبويب تاني</p></div>' +
        '<button id="swNotify" class="sw" role="switch" aria-checked="' + !!s.notify + '" aria-label="إشعارات المتصفح"></button></div>' +
        (isNative() ? '<div class="setrow"><span class="setico"><i class="fa-solid fa-mobile-screen-button"></i></span><div class="flex-1"><p class="text-[15px] font-bold text-navy">تنبيهات الجوال</p><p class="text-[12px] text-slate2">' + (nativePerm === 'granted' ? 'مفعّلة — بترن حتى والتطبيق مقفول' : 'غير مفعّلة — اضغط للسماح') + '</p></div><button id="nativeOn" class="btn-outline !px-3 !py-1.5 text-[13px]">' + (nativePerm === 'granted' ? 'إعادة الجدولة' : 'تفعيل') + '</button></div>' : '') +
        '<button id="testAlert" class="btn-outline w-full"><i class="fa-solid fa-play me-2"></i>جرّب التنبيه الصوتي</button>';
    }
    function security() {
      var box = $('#security');
      if (!hasLock()) {
        box.innerHTML = '<div class="setrow"><span class="setico"><i class="fa-solid fa-lock-open"></i></span><div class="flex-1"><p class="text-[15px] font-bold text-navy">القفل غير مفعّل</p><p class="text-[12px] text-slate2">أي شخص يفتح التطبيق يشوف مهامك</p></div></div>' +
          '<button id="secOn" class="btn-primary w-full"><i class="fa-solid fa-shield-halved me-2"></i>تفعيل القفل</button>';
        return;
      }
      var nm = sec.mode === 'pass' ? 'كلمة المرور' : 'النمط';
      box.innerHTML = '<div class="setrow"><span class="setico" style="background:#dcfce7;color:#1f9d57"><i class="fa-solid fa-shield-halved"></i></span><div class="flex-1"><p class="text-[15px] font-bold text-navy">القفل مفعّل بـ' + nm + '</p><p class="text-[12px] text-slate2">تخزين مشفّر بـ PBKDF2 مع ملح عشوائي</p></div></div>' +
        '<label class="label" for="secAuto">القفل التلقائي</label><select id="secAuto" class="field">' +
        [[1, 'بعد دقيقة بدون نشاط'], [5, 'بعد 5 دقائق'], [15, 'بعد 15 دقيقة'], [60, 'بعد ساعة'], [0, 'بدون (عند فتح التطبيق فقط)']].map(function (o) { return '<option value="' + o[0] + '"' + (o[0] === (sec.auto == null ? 5 : sec.auto) ? ' selected' : '') + '>' + o[1] + '</option>'; }).join('') + '</select>' +
        '<div class="mt-3 grid grid-cols-2 gap-3"><button id="secLock" class="btn-outline"><i class="fa-solid fa-lock me-2"></i>قفل الآن</button><button id="secChange" class="btn-primary">تغيير ' + nm + '</button></div>' +
        '<button id="secOff" class="btn-danger mt-3 w-full">إيقاف القفل</button>';
      $('#secAuto').addEventListener('change', function (e) { sec.auto = parseInt(e.target.value, 10); secSave(); touchActive(); toast('تم الحفظ'); });
    }
    var lastTest = '';
    function renderTest(res) {
      var bad = res.filter(function (r) { return !r.ok; }).length;
      lastTest = '<div class="mt-3 rounded-2xl bg-white p-3 shadow-card"><p class="mb-2 text-[14px] font-extrabold ' + (bad ? 'text-red-600' : 'text-emerald-600') + '">' +
        (bad ? 'فشل ' + bad + ' من ' + res.length + ' اختبارات' : 'كل الاختبارات نجحت (<bdi>' + res.length + '/' + res.length + '</bdi>)') + ' · <bdi>' + res.ms + ' ms</bdi></p><ul class="space-y-2">' +
        res.map(function (r) {
          return '<li class="flex items-start gap-2 text-[13px]"><i class="fa-solid ' + (r.ok ? 'fa-circle-check text-emerald-600' : 'fa-circle-xmark text-red-500') + ' mt-0.5"></i>' +
            '<span><b class="text-navy">' + esc(r.label) + '</b><br><span class="text-slate2">' + esc(r.detail) + '</span></span></li>';
        }).join('') + '</ul></div>';
      var box = $('#dbResult'); if (box) box.innerHTML = lastTest;
    }
    function dbPanel(keepResult) {
      var box = $('#dbPanel');
      if (!dbOK) {
        box.innerHTML = '<div class="setrow"><span class="setico" style="background:#fee2e2;color:#dc2626"><i class="fa-solid fa-database"></i></span><div class="flex-1"><p class="text-[15px] font-bold text-red-600">SQLite غير متاح</p><p class="text-[12px] text-slate2">' + esc(dbError || 'تعذّر تشغيل المحرك') + ' · بنستخدم تخزين احتياطي مؤقتًا</p></div></div>';
        return;
      }
      var st = dbStats(), c = st.counts;
      box.innerHTML = '<div class="setrow"><span class="setico" style="background:#dcfce7;color:#1f9d57"><i class="fa-solid fa-database"></i></span><div class="flex-1"><p class="text-[15px] font-bold text-navy">قاعدة SQLite تعمل</p>' +
        '<p class="text-[12px] text-slate2" dir="ltr" style="text-align:start">SQLite ' + st.version + ' · WebAssembly · ' + dbInfo.via + '</p></div></div>' +
        '<div class="grid grid-cols-2 gap-3">' +
        [['حجم القاعدة', fmtBytes(st.size)], ['إجمالي السجلات', st.total], ['المهام / تأجيلاتها', c.tasks + ' / ' + c.task_snoozes], ['العادات / سجلاتها', c.habits + ' / ' + c.habit_logs], ['المشاريع / مهامها', c.projects + ' / ' + c.project_tasks],
         ['مهام شخصية', c.personal], ['الإشعارات', c.notifs]].map(function (x) {
          return '<div class="rounded-xl bg-white py-2.5 text-center shadow-[0_3px_10px_rgba(31,150,186,.10)]"><p class="text-[19px] font-black leading-tight text-royal" dir="ltr">' + x[1] + '</p><p class="text-[12px] font-semibold text-slate2">' + x[0] + '</p></div>';
        }).join('') + '</div>' +
        '<p id="dbQuota" class="mt-2.5 text-center text-[12px] text-slate2"></p>' +
        '<p class="mt-0.5 text-center text-[12px] text-slate2">آخر حفظ: ' + (dbInfo.lastSave ? new Date(dbInfo.lastSave).toLocaleTimeString(LOCALE, { hour: 'numeric', minute: '2-digit', second: '2-digit' }) : 'لم يتم بعد') +
        (dbInfo.migrated ? ' · تم نقل بياناتك القديمة' : '') + (dbInfo.recovered ? ' · تم استرجاع قاعدة بدل التالفة' : '') + '</p>' +
        '<button id="dbTest" class="btn-primary mt-3 w-full"><i class="fa-solid fa-vial-circle-check me-2"></i>اختبار قاعدة البيانات</button>' +
        '<div id="dbResult">' + (keepResult ? lastTest : '') + '</div>' +
        '<div class="mt-3 grid grid-cols-2 gap-3"><button id="dbExport" class="btn-outline"><i class="fa-solid fa-download me-2"></i>تصدير</button>' +
        '<label class="btn-outline cursor-pointer"><i class="fa-solid fa-upload me-2"></i>استعادة<input id="dbFile" type="file" accept=".sqlite,.db,.sqlite3,application/vnd.sqlite3,application/octet-stream" class="hidden" /></label></div>' +
        '<button id="dbClear" class="btn-danger mt-3 w-full"><i class="fa-solid fa-trash-can me-2"></i>مسح كل بياناتي</button>';
      $('#dbFile').addEventListener('change', function (e) { var f = e.target.files && e.target.files[0]; if (f) importDb(f); e.target.value = ''; });
      if (navigator.storage && navigator.storage.estimate) {
        navigator.storage.estimate().then(function (e) {
          var el = $('#dbQuota'); if (el && e.quota) el.innerHTML = 'مساحة المتصفح: مستخدم <bdi>' + fmtBytes(e.usage || 0) + '</bdi> من <bdi>' + fmtBytes(e.quota) + '</bdi>';
        }).catch(function () {});
      }
    }
    function refresh() { stats(); card(); settings(); security(); dbPanel(true); renderCommon(); }
    profileRefresh = refresh;
    refresh();

    function setupFlow(mode) {
      var fin = function () { closeSheet(); security(); toast(mode === 'pass' ? 'تم حفظ كلمة المرور' : 'تم حفظ النمط'); };
      if (mode === 'pass') setupPass(fin); else setupPattern(fin);
    }
    route.click = function (e) {
      var t = e.target;
      if (t.closest('#avBtn') || t.closest('#editProfile')) return editProfile(refresh);
      if (t.closest('#secOn')) return chooseMode(setupFlow);
      if (t.closest('#secLock')) return lockNow();
      if (t.closest('#secChange')) return verifySheet('تأكيد الهوية', 'لتغيير القفل لازم تكتب ' + (sec.mode === 'pass' ? 'كلمة المرور' : 'النمط') + ' الحالي الأول.', function () { chooseMode(setupFlow); });
      if (t.closest('#secOff')) return verifySheet('إيقاف القفل', 'اكتب ' + (sec.mode === 'pass' ? 'كلمة المرور' : 'النمط') + ' الحالي لإيقاف القفل.', function () {
        sec = {}; secSave(); try { sessionStorage.removeItem(SS_KEY); } catch (x) {} closeSheet(); security(); toast('تم إيقاف القفل');
      });
      if (t.closest('#logout')) { try { sessionStorage.removeItem(SS_KEY); } catch (x) {} return; }
      if (t.closest('#swSound')) {
        state.settings.sound = !state.settings.sound; save(); settings();
        if (state.settings.sound) playSound('start');
        return;
      }
      if (t.closest('#nativeOn')) {
        nativeAskPermission(function (r) { settings(); toast(r === 'granted' ? 'تم تفعيل تنبيهات الجوال' : 'اسمح بالإشعارات من إعدادات الجوال'); });
        return;
      }
      if (t.closest('#swNotify')) {
        if (state.settings.notify) { state.settings.notify = false; save(); return settings(); }
        if (!('Notification' in window)) return toast('المتصفح ده مش بيدعم الإشعارات');
        var done = function (perm) {
          if (perm === 'granted') { state.settings.notify = true; save(); settings(); toast('تم تفعيل إشعارات المتصفح'); }
          else toast('لازم تسمح بالإشعارات من إعدادات المتصفح');
        };
        try { var r = Notification.requestPermission(done); if (r && r.then) r.then(done); } catch (err) { toast('المتصفح ده مش بيدعم الإشعارات'); }
        return;
      }
      if (t.closest('#testAlert')) {
        banner('fa-bell', 'royal', 'تنبيه تجريبي', 'كده هيجيلك التنبيه بالصوت والإشعار');
        playSound('start');
        sysNotify('تنبيه تجريبي – إنجازي', 'كده هيجيلك التنبيه بالصوت والإشعار', 'test');
        return;
      }
      if (t.closest('#dbTest')) {
        var tb = $('#dbTest'); tb.disabled = true; $('#dbResult').innerHTML = '<p class="mt-3 text-center text-[13px] font-bold text-royal">جارٍ اختبار قاعدة البيانات…</p>';
        runSelfTest().then(function (res) { tb.disabled = false; renderTest(res); dbPanel(true); });
        return;
      }
      if (t.closest('#dbExport')) return dbOK ? exportDb() : toast('قاعدة البيانات غير متاحة');
      if (t.closest('#dbClear')) {
        var doClear = function () {
          confirmBox({ title: 'مسح كل البيانات', msg: 'هتتمسح كل المهام وسجل التأجيلات والمشاريع والمهام الشخصية والإشعارات نهائيًا من قاعدة البيانات. ملفك الشخصي والقفل هيفضلوا. مفيش تراجع، فيُفضَّل تصدّر نسخة احتياطية الأول.', ok: 'نعم، امسح كل البيانات', cancel: 'إلغاء', icon: 'fa-trash-can' }, function () {
            clearUserData(); lastTest = ''; refresh(); toast('تم مسح بياناتك');
          });
        };
        if (hasLock()) verifySheet('تأكيد الهوية', 'مسح البيانات نهائي، فلازم تأكد الأول.', function () { closeSheet(); doClear(); });
        else doClear();
      }
    };
  }

  /* =====================================================
     التقارير: رسوم بيانية + جداول + طباعة (مجمّعة أو كل يوم لوحده)
     ===================================================== */
  var RP_MAX = 366;                                   // أقصى مدة للتقرير (يوم)
  var RP_KEY = 'engazy.rp';
  var RP = { from: null, to: null, cat: 'all', st: 'all', preset: 'month', skip: true };
  var svgN = 0;
  var ST_COL = { done: '#15935a', active: '#1b7fc9', upcoming: '#6aa9d6', expired: '#dc2626', canceled: '#94a3b8' };
  var ST_ORDER = ['done', 'active', 'upcoming', 'expired', 'canceled'];

  function addDaysISO(iso, n) { var d = parseISO(iso); d.setDate(d.getDate() + n); return isoDate(d); }
  function daysBetween(a, b) { return Math.round((parseISO(b) - parseISO(a)) / DAY); }
  function shortDate(iso) { var d = parseISO(iso); return d.getDate() + '/' + (d.getMonth() + 1); }
  function longDate(iso) { return parseISO(iso).toLocaleDateString(LOCALE, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }); }

  function rpSave() { try { sessionStorage.setItem(RP_KEY, JSON.stringify(RP)); } catch (e) {} }
  function rpRestore() {
    try { var o = JSON.parse(sessionStorage.getItem(RP_KEY)); if (o && o.from && o.to) RP = Object.assign(RP, o); } catch (e) {}
    if (!RP.from) rpPreset('month');
  }
  function rpPreset(k) {
    var d = parseISO(TODAY), f, t;
    if (k === 'today') { f = t = TODAY; }
    else if (k === 'week') { f = addDaysISO(TODAY, -((d.getDay() + 1) % 7)); t = addDaysISO(f, 6); }
    else if (k === 'month') { f = isoDate(new Date(d.getFullYear(), d.getMonth(), 1)); t = isoDate(new Date(d.getFullYear(), d.getMonth() + 1, 0)); }
    else if (k === 'last30') { f = addDaysISO(TODAY, -29); t = TODAY; }
    else { // all
      if (!state.tasks.length) { return rpPreset('month'); }
      f = state.tasks.reduce(function (m, x) { return x.startDate < m ? x.startDate : m; }, state.tasks[0].startDate);
      t = state.tasks.reduce(function (m, x) { return x.endDate > m ? x.endDate : m; }, state.tasks[0].endDate);
      if (daysBetween(f, t) + 1 > RP_MAX) t = addDaysISO(f, RP_MAX - 1);
    }
    RP.from = f; RP.to = t; RP.preset = k;
  }

  function rpTasks() {
    return state.tasks.filter(function (t) {
      return t.startDate <= RP.to && t.endDate >= RP.from &&
        (RP.cat === 'all' || catOf(t) === RP.cat) && (RP.st === 'all' || statusOf(t) === RP.st);
    }).sort(function (a, b) { return startMs(a) - startMs(b) || endMs(a) - endMs(b); });
  }
  function overlaps(t, f, e) { return t.startDate <= e && t.endDate >= f; }

  function rpStats(list) {
    var o = { total: list.length, done: 0, active: 0, upcoming: 0, expired: 0, canceled: 0, high: 0, onTime: 0, hours: 0, snzTasks: 0, snzN: 0, snzMins: 0 };
    list.forEach(function (t) {
      var s = statusOf(t); o[s]++;
      if (t.priority === 'high') o.high++;
      if ((t.snoozes || []).length) { o.snzTasks++; o.snzN += t.snoozes.length; o.snzMins += snzTotal(t); }
      if (t.done && t.doneAt && t.doneAt <= endMs(t)) o.onTime++;
      o.hours += Math.max(0, endMs(t) - startMs(t)) / HOUR;
    });
    o.rate = o.total ? Math.round(o.done / o.total * 100) : 0;
    o.onTimeRate = o.done ? Math.round(o.onTime / o.done * 100) : 0;
    o.avgHours = o.total ? o.hours / o.total : 0;
    return o;
  }
  function fmtHours(h) { return h >= 48 ? Math.round(h / 24 * 10) / 10 + ' يوم' : Math.round(h * 10) / 10 + ' ساعة'; }

  /* ----- تقسيم الفترة: يومي (حتى 31 يوم) / أسبوعي (حتى 120) / شهري ----- */
  function rpBuckets() {
    var n = daysBetween(RP.from, RP.to) + 1, b = [], s, e, d;
    if (n <= 31) {
      for (var i = 0; i < n; i++) { s = addDaysISO(RP.from, i); b.push({ from: s, to: s, label: shortDate(s), full: shortDate(s) }); }
    } else if (n <= 120) {
      for (s = RP.from; s <= RP.to; s = addDaysISO(s, 7)) { e = addDaysISO(s, 6); if (e > RP.to) e = RP.to; b.push({ from: s, to: e, label: shortDate(s), full: shortDate(s) + ' – ' + shortDate(e) }); }
    } else {
      s = RP.from;
      while (s <= RP.to) {
        d = parseISO(s);
        var me = isoDate(new Date(d.getFullYear(), d.getMonth() + 1, 0));
        e = me < RP.to ? me : RP.to;
        b.push({ from: s, to: e, label: d.toLocaleDateString(LOCALE, { month: 'short' }), full: d.toLocaleDateString(LOCALE, { month: 'long', year: 'numeric' }) });
        s = addDaysISO(me, 1);
      }
    }
    return b;
  }
  function bucketData(list, buckets) {
    return buckets.map(function (b) {
      var o = { b: b, done: 0, active: 0, upcoming: 0, expired: 0, canceled: 0, due: 0, sched: 0 };
      list.forEach(function (t) {
        if (overlaps(t, b.from, b.to)) o.sched++;
        if (t.endDate >= b.from && t.endDate <= b.to) { o.due++; o[statusOf(t)]++; }
      });
      return o;
    });
  }

  /* ----- الرسم البياني الرئيسي: أعمدة متراكبة حسب النتيجة + خط المهام المجدولة ----- */
  function barChart(bd) {
    var W = 360, H = 240, L = 30, R = 10, T = 22, B = 34, iw = W - L - R, ih = H - T - B, id = 'bc' + (++svgN);
    var mx = Math.max(4, Math.max.apply(null, bd.map(function (x) { return Math.max(x.due, x.sched); })));
    var ticks = 4, top = Math.ceil(mx / ticks) * ticks, slot = iw / bd.length, bw = Math.min(26, slot * 0.64), rx = Math.min(5, bw / 2);
    var COL = { done: ['#4ade80', '#15935a'], active: ['#5bb8f5', '#1b7fc9'], upcoming: ['#cde8fa', '#8cc3ea'], expired: ['#fb8f8f', '#dc2626'], canceled: ['#cbd5e1', '#94a3b8'] };
    var s = '<svg viewBox="0 0 ' + W + ' ' + H + '" class="w-full" style="direction:ltr;font-family:inherit" role="img" aria-label="رسم بياني للمهام حسب الفترة"><defs>';
    ST_ORDER.forEach(function (k) { s += '<linearGradient id="' + id + k + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + COL[k][0] + '"/><stop offset="1" stop-color="' + COL[k][1] + '"/></linearGradient>'; });
    s += '</defs>';
    for (var i = 0; i <= ticks; i++) {
      var y = T + ih - ih * i / ticks;
      s += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + y + '" y2="' + y + '" stroke="' + (i ? '#e2e8f0' : '#94a3b8') + '" stroke-width="1"' + (i ? ' stroke-dasharray="3 3"' : '') + '/>' +
        '<text x="' + (L - 6) + '" y="' + (y + 3) + '" text-anchor="end" font-size="9" fill="#94a3b8">' + Math.round(top * i / ticks) + '</text>';
    }
    var every = Math.ceil(bd.length / 12), pts = [];
    bd.forEach(function (x, i) {
      var bx = L + slot * i + (slot - bw) / 2, cx = L + slot * i + slot / 2;
      if (x.b.from <= TODAY && TODAY <= x.b.to) s += '<rect x="' + (L + slot * i) + '" y="' + T + '" width="' + slot + '" height="' + ih + '" fill="#1896ba" opacity=".09" rx="4"/>';
      if (x.due) {
        var total = ih * x.due / top, yy = T + ih;
        s += '<clipPath id="' + id + 'c' + i + '"><rect x="' + bx + '" y="' + (T + ih - total) + '" width="' + bw + '" height="' + total + '" rx="' + rx + '"/></clipPath><g clip-path="url(#' + id + 'c' + i + ')">';
        ST_ORDER.forEach(function (k) {
          if (!x[k]) return;
          var h = ih * x[k] / top; yy -= h;
          s += '<rect x="' + bx + '" y="' + yy + '" width="' + bw + '" height="' + (h + 0.4) + '" fill="url(#' + id + k + ')"><title>' + esc(x.b.full) + ' – ' + STATUS_TXT[k] + ': ' + x[k] + '</title></rect>';
        });
        s += '</g>';
        if (bd.length <= 24) s += '<text x="' + cx + '" y="' + (T + ih - total - 4) + '" text-anchor="middle" font-size="9" font-weight="700" fill="#334155">' + x.due + '</text>';
      }
      pts.push([cx, T + ih - ih * x.sched / top]);
      if (i % every === 0) s += '<text x="' + cx + '" y="' + (H - 16) + '" text-anchor="middle" font-size="9" fill="#64748b">' + esc(x.b.label) + '</text>';
    });
    if (pts.length > 1) s += '<path d="M' + pts.map(function (p) { return p[0].toFixed(1) + ' ' + p[1].toFixed(1); }).join(' L') + '" fill="none" stroke="#f59e0b" stroke-width="2.2" stroke-dasharray="5 3" stroke-linecap="round" stroke-linejoin="round"/>';
    pts.forEach(function (p, i) { s += '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="3.2" fill="#fff" stroke="#f59e0b" stroke-width="2"><title>' + esc(bd[i].b.full) + ' – مجدولة: ' + bd[i].sched + '</title></circle>'; });
    return s + '</svg>';
  }

  function legend() {
    function dot(c, t, line) { return '<span class="inline-flex items-center gap-1.5 text-[11px] font-bold text-slate2"><i class="inline-block ' + (line ? 'h-0 w-4 border-t-2 border-dashed' : 'h-2.5 w-2.5 rounded-full') + '" style="' + (line ? 'border-color:' + c : 'background:' + c) + '"></i>' + t + '</span>'; }
    return '<div class="mt-2 flex flex-wrap justify-center gap-x-3 gap-y-1">' + dot('#15935a', 'منجزة') + dot('#1b7fc9', 'نشطة') + dot('#8cc3ea', 'قادمة') + dot('#dc2626', 'انتهت دون إنجاز') + dot('#94a3b8', 'ملغاة') + dot('#f59e0b', 'مجدولة في الفترة', true) + '</div>';
  }

  function donut(st) {
    var R0 = 50, C = 2 * Math.PI * R0, off = 0, s = '<svg viewBox="0 0 140 140" class="mx-auto h-[140px] w-[140px]" style="direction:ltr;font-family:inherit" role="img" aria-label="توزيع الحالات"><circle cx="70" cy="70" r="' + R0 + '" fill="none" stroke="#e8eef3" stroke-width="18"/>';
    if (st.total) ST_ORDER.forEach(function (k) {
      if (!st[k]) return;
      var len = C * st[k] / st.total;
      s += '<circle cx="70" cy="70" r="' + R0 + '" fill="none" stroke="' + ST_COL[k] + '" stroke-width="18" stroke-dasharray="' + (len - 1.5).toFixed(2) + ' ' + (C - len + 1.5).toFixed(2) + '" stroke-dashoffset="' + (-off).toFixed(2) + '" transform="rotate(-90 70 70)"><title>' + STATUS_TXT[k] + ': ' + st[k] + '</title></circle>';
      off += len;
    });
    return s + '<text x="70" y="70" text-anchor="middle" font-size="26" font-weight="900" fill="#1c607a">' + st.rate + '%</text><text x="70" y="88" text-anchor="middle" font-size="10" font-weight="700" fill="#64748b">نسبة الإنجاز</text></svg>';
  }
  function donutLegend(st) {
    return '<div class="mt-2 space-y-1">' + ST_ORDER.map(function (k) {
      var p = st.total ? Math.round(st[k] / st.total * 100) : 0;
      return '<div class="flex items-center justify-between text-[12px] font-bold"><span class="flex items-center gap-1.5 text-slate2"><i class="inline-block h-2.5 w-2.5 rounded-full" style="background:' + ST_COL[k] + '"></i>' + STATUS_TXT[k] + '</span><span class="text-navy" dir="ltr">' + st[k] + ' · ' + p + '%</span></div>';
    }).join('') + '</div>';
  }

  function catBars(list) {
    var rows = CAT_ORDER.map(function (k) {
      var l = list.filter(function (t) { return catOf(t) === k; });
      return { k: k, n: l.length, done: l.filter(function (t) { return t.done; }).length };
    }).filter(function (r) { return r.n; });
    var mx = Math.max.apply(null, rows.map(function (r) { return r.n; }).concat([1]));
    if (!rows.length) return '<p class="py-3 text-center text-[12px] text-slate2">لا توجد بيانات.</p>';
    return '<div class="space-y-2.5">' + rows.map(function (r) {
      var c = CATS[r.k];
      return '<div><div class="flex items-center justify-between text-[12px] font-bold text-navy"><span><i class="fa-solid ' + c.i + ' me-1.5" style="color:' + c.c + '"></i>' + c.n + '</span><span dir="ltr">' + r.done + '/' + r.n + '</span></div>' +
        '<div class="mt-1 h-2.5 overflow-hidden rounded-full bg-slate-200" style="direction:ltr"><div class="relative h-full rounded-full" style="width:' + (r.n / mx * 100) + '%;background:' + c.c + '33"><i class="absolute inset-y-0 start-0 block rounded-full" style="width:' + (r.done / r.n * 100) + '%;background:' + c.c + '"></i></div></div></div>';
    }).join('') + '</div>';
  }

  /* ----- الخط الزمني (جانت) ----- */
  function gantt(list, limit) {
    if (!list.length) return '';
    var fMs = toMs(RP.from, '00:00', '00:00'), tMs = toMs(RP.to, '23:59', '23:59') + 59999, span = tMs - fMs;
    var shown = list.slice(0, limit), s = '', i;
    var nT = Math.min(6, daysBetween(RP.from, RP.to) + 1), axis = '';
    for (i = 0; i < nT; i++) {
      var iso = addDaysISO(RP.from, Math.round(i * (daysBetween(RP.from, RP.to)) / Math.max(1, nT - 1)));
      axis += '<span style="position:absolute;left:' + ((toMs(iso, '00:00', '00:00') - fMs) / span * 100) + '%;transform:translateX(-' + (i === 0 ? 0 : i === nT - 1 ? 100 : 50) + '%)">' + shortDate(iso) + '</span>';
    }
    var todayPos = (TODAY >= RP.from && TODAY <= RP.to) ? (toMs(TODAY, '12:00', '12:00') - fMs) / span * 100 : null;
    s += '<div class="gantt"><div class="gantt-row"><div class="gantt-label"></div><div class="gantt-track gantt-axis">' + axis + '</div></div>';
    shown.forEach(function (t) {
      var a = Math.max(startMs(t), fMs), z = Math.min(endMs(t), tMs), l = (a - fMs) / span * 100, w = Math.max(1.2, (z - a) / span * 100), st = statusOf(t);
      s += '<div class="gantt-row"><div class="gantt-label" title="' + esc(t.title) + '"><i class="fa-solid ' + iconOf(t) + ' me-1" style="color:' + CATS[catOf(t)].c + '"></i>' + esc(t.title) + '</div>' +
        '<div class="gantt-track">' + (todayPos != null ? '<i class="gantt-today" style="left:' + todayPos + '%"></i>' : '') +
        '<b class="gantt-bar" style="left:' + l + '%;width:' + w + '%;background:' + ST_COL[st] + '" title="' + esc(t.title + ' – ' + STATUS_TXT[st]) + '"></b></div></div>';
    });
    s += '</div>';
    if (list.length > limit) s += '<p class="mt-1 text-center text-[11px] font-bold text-slate2">+ ' + (list.length - limit) + ' مهمة أخرى في الجدول التفصيلي</p>';
    return s;
  }

  /* ----- الجداول ----- */
  function stText(t) { var s = statusOf(t); return '<b style="color:' + ST_COL[s] + '">' + STATUS_TXT[s] + '</b>'; }
  function summaryTable(bd, cls, shown) {
    var tot = { sched: 0, due: 0, done: 0, active: 0, upcoming: 0, expired: 0, canceled: 0 };
    bd.forEach(function (x) { Object.keys(tot).forEach(function (k) { if (k !== 'sched') tot[k] += x[k]; }); });
    var rows = (shown || bd).map(function (x) {
      return '<tr><td>' + esc(x.b.full) + '</td><td>' + x.sched + '</td><td>' + x.due + '</td><td>' + x.done + '</td><td>' + x.active + '</td><td>' + x.upcoming + '</td><td style="' + (x.expired ? 'color:#dc2626;font-weight:700' : '') + '">' + x.expired + '</td><td>' + x.canceled + '</td><td>' + (x.due ? Math.round(x.done / x.due * 100) + '%' : '—') + '</td></tr>';
    }).join('');
    return '<table class="' + cls + '"><thead><tr><th>' + (bd.length && bd[0].b.from === bd[0].b.to ? 'اليوم' : 'الفترة') + '</th><th>مجدولة</th><th>تنتهي</th><th>منجزة</th><th>نشطة</th><th>قادمة</th><th>انتهت</th><th>ملغاة</th><th>الإنجاز</th></tr></thead><tbody>' + rows +
      '</tbody><tfoot><tr><td>الإجمالي (كل الفترات)</td><td>—</td><td>' + tot.due + '</td><td>' + tot.done + '</td><td>' + tot.active + '</td><td>' + tot.upcoming + '</td><td>' + tot.expired + '</td><td>' + tot.canceled + '</td><td>' + (tot.due ? Math.round(tot.done / tot.due * 100) + '%' : '—') + '</td></tr></tfoot></table>';
  }
  function stamp2(date, time, def) { return esc(shortDate(date)) + ' ' + fmtTime(time || def); }
  function snzNote(t) { var z = (t.snoozes || []).length; return z ? '<br><small style="color:#b45309;font-weight:700">تم مد فترة المهمة (' + z + (z === 1 ? ' مرة' : ' مرات') + ' · ' + esc(snzTotal(t) ? snzTxt(snzTotal(t)) : '') + ')</small>' : ''; }
  function detailTable(list, cls, full, off) {
    off = off || 0;
    if (!list.length) return '<p class="py-3 text-center text-[12px] text-slate2">لا توجد مهام في هذه الفترة.</p>';
    return '<table class="' + cls + '"><thead><tr><th>#</th><th>المهمة</th><th>التصنيف</th><th>البداية</th><th>النهاية</th><th>المدة</th><th>الأولوية</th><th>الحالة</th>' + (full ? '<th>المكان</th><th>ملاحظات</th>' : '') + '</tr></thead><tbody>' +
      list.map(function (t, i) {
        return '<tr><td>' + (off + i + 1) + '</td><td style="font-weight:700">' + esc(t.title) + '</td><td>' + CATS[catOf(t)].n + '</td><td>' + stamp2(t.startDate, t.startTime, '00:00') + '</td><td>' + stamp2(t.endDate, t.endTime, '23:59') + '</td><td>' + esc(durTxt(endMs(t) - startMs(t))) +
          '</td><td>' + (PRI[t.priority] || '—') + '</td><td>' + stText(t) + (t.done && t.doneAt ? '<br><small>' + esc(shortDate(isoDate(new Date(t.doneAt)))) + '</small>' : '') + snzNote(t) + '</td>' +
          (full ? '<td>' + esc(t.place || '—') + '</td><td>' + esc(t.notes || '—') + '</td>' : '') + '</tr>';
      }).join('') + '</tbody></table>';
  }

  /* ----- سجل التأجيلات (مد الفترة) في التقرير ----- */
  function snzRows(list) {
    var rows = [];
    list.forEach(function (t) { (t.snoozes || []).forEach(function (z, i) { rows.push({ t: t, z: z, no: i + 1, of: t.snoozes.length }); }); });
    return rows.sort(function (a, b) { return a.t.id === b.t.id ? a.z.at - b.z.at : startMs(a.t) - startMs(b.t) || (a.t.id < b.t.id ? -1 : 1); });
  }
  function snzTable(rows, cls, off) {
    off = off || 0;
    if (!rows.length) return '<p class="py-3 text-center text-[12px] text-slate2">لا توجد تأجيلات في هذه الفترة.</p>';
    return '<table class="' + cls + '"><thead><tr><th>#</th><th>المهمة</th><th>وقت التأجيل</th><th>المصدر</th><th>المدة المضافة</th><th>النهاية السابقة</th><th>النهاية الجديدة</th></tr></thead><tbody>' +
      rows.map(function (r, i) {
        var f = r.z.fromEnd || {}, to = r.z.toEnd || {};
        return '<tr><td>' + (off + i + 1) + '</td><td style="font-weight:700">' + esc(r.t.title) + '<br><small>التأجيل ' + r.no + ' من ' + r.of + '</small></td><td>' + esc(atStamp(r.z.at)) + '</td><td>' + (VIA_TXT[r.z.via] || VIA_TXT.manual) +
          '</td><td style="font-weight:700;color:#b45309">' + esc(snzTxt(r.z.mins)) + '</td><td>' + esc(absStamp(f.date, f.time)) + '</td><td>' + esc(absStamp(to.date, to.time)) + '</td></tr>';
      }).join('') + '</tbody></table>';
  }
  function snzSummaryText(st) {
    return st.snzN ? 'تم مد فترة ' + (st.snzTasks === 1 ? 'مهمة واحدة' : st.snzTasks === 2 ? 'مهمتين' : st.snzTasks + (st.snzTasks <= 10 ? ' مهام' : ' مهمة')) +
      ' إلى فترة إضافية · عدد مرات المد: ' + st.snzN + ' · إجمالي الفترات المضافة: ' + snzTxt(st.snzMins) : 'لم يتم مد فترة أي مهمة في هذه الفترة.';
  }

  function kpiHtml(st, big) {
    var items = [
      ['إجمالي المهام', st.total, 'fa-list-check', '#1896ba'], ['منجزة', st.done, 'fa-circle-check', '#15935a'],
      ['نسبة الإنجاز', st.rate + '%', 'fa-percent', '#1b7fc9'], ['انتهت دون إنجاز', st.expired, 'fa-triangle-exclamation', '#dc2626'],
      ['نشطة / قادمة', st.active + ' / ' + st.upcoming, 'fa-hourglass-half', '#e08a2e'], ['إنجاز في الموعد', st.done ? st.onTimeRate + '%' : '—', 'fa-bullseye', '#7c5cd6'],
      ['ملغاة', st.canceled, 'fa-ban', '#64748b'], ['مرات مد الفترة', st.snzN + (st.snzN ? ' (' + st.snzTasks + ' مهمة)' : ''), 'fa-clock-rotate-left', '#d97706']
    ];
    if (big) items.push(['ساعات مخططة', fmtHours(st.hours), 'fa-clock', '#16a6b6'], ['أولوية عالية', st.high, 'fa-flag', '#e0507a'], ['إجمالي المد', st.snzMins ? snzTxt(st.snzMins) : '—', 'fa-hourglass-end', '#d97706'], ['متوسط ساعات المهمة', fmtHours(st.avgHours), 'fa-gauge', '#16a6b6']);
    return items.map(function (x) {
      return '<div class="rp-kpi"><span class="rp-kpi-ico" style="background:' + x[3] + '1f;color:' + x[3] + '"><i class="fa-solid ' + x[2] + '"></i></span><div class="min-w-0"><p class="rp-kpi-n" dir="ltr" style="text-align:start">' + x[1] + '</p><p class="rp-kpi-l">' + x[0] + '</p></div></div>';
    }).join('');
  }

  function rpFilterText() {
    return 'من ' + longDate(RP.from) + ' إلى ' + longDate(RP.to) + ' (' + (daysBetween(RP.from, RP.to) + 1) + ' يومًا)' +
      ' · التصنيف: ' + (RP.cat === 'all' ? 'الكل' : CATS[RP.cat].n) + ' · الحالة: ' + (RP.st === 'all' ? 'الكل' : STATUS_TXT[RP.st]);
  }

  /* ----- الطباعة ----- */
  function printReportAll() {
    var list = rpTasks(), st = rpStats(list), bd = bucketData(list, rpBuckets());
    var body = '<p class="pr-sub">' + esc(rpFilterText()) + '</p>' +
      '<div class="pr-kpis">' + kpiHtml(st, true) + '</div>' +
      '<h2>المهام حسب الفترة</h2><div class="pr-chart">' + barChart(bd) + legend() + '</div>' +
      '<div class="pr-two"><div><h2>توزيع الحالات</h2>' + donut(st) + donutLegend(st) + '</div><div><h2>التصنيفات (منجزة / إجمالي)</h2>' + catBars(list) + '</div></div>' +
      '<h2>ملخص الفترات</h2>' + summaryTable(bd, 'pr-table') +
      (list.length ? '<h2 class="pr-break">الخط الزمني للمهام</h2>' + gantt(list, list.length) : '') +
      '<h2 class="pr-break">الجدول التفصيلي لكل المهام (' + list.length + ')</h2>' + detailTable(list, 'pr-table', true) +
      '<h2 class="pr-break">سجل مد الفترات (التأجيل)</h2><p class="pr-sub">' + esc(snzSummaryText(st)) + '</p>' + (st.snzN ? snzTable(snzRows(list), 'pr-table') : '');
    printDoc('تقرير المهام – مجمّع', body);
  }

  function rpDays() {
    var list = rpTasks(), out = [], n = daysBetween(RP.from, RP.to) + 1;
    for (var i = 0; i < n; i++) {
      var d = addDaysISO(RP.from, i), l = list.filter(function (t) { return overlaps(t, d, d); });
      if (l.length || !RP.skip) out.push({ d: d, list: l });
    }
    return out;
  }
  var printDaysOk = false;
  function printReportDays() {
    var days = rpDays();
    if (!days.length) return toast('لا توجد أيام فيها مهام في هذه الفترة');
    if (days.length > 60 && !printDaysOk) {
      return confirmBox({ title: 'طباعة عدد كبير من الصفحات', msg: 'هتتطبع ' + days.length + ' صفحة. تكمّل؟', ok: 'نعم، اطبع', cancel: 'إلغاء', tone: 'info', icon: 'fa-print' }, function () { printDaysOk = true; printReportDays(); printDaysOk = false; });
    }
    var dayStart = function (d) { return toMs(d, '00:00', '00:00'); }, dayEnd = function (d) { return toMs(d, '23:59', '23:59') + 59999; };
    var body = '<p class="pr-sub">' + esc(rpFilterText()) + '</p>' + days.map(function (x) {
      var st = rpStats(x.list), due = x.list.filter(function (t) { return t.endDate === x.d; }).length, starts = x.list.filter(function (t) { return t.startDate === x.d; }).length;
      var seg = ST_ORDER.map(function (k) { return st[k] ? '<i style="width:' + (st[k] / st.total * 100) + '%;background:' + ST_COL[k] + '"></i>' : ''; }).join('');
      var rows = x.list.length ? '<table class="pr-table"><thead><tr><th>#</th><th>المهمة</th><th>التصنيف</th><th>الوقت في هذا اليوم</th><th>تبدأ</th><th>تنتهي</th><th>الأولوية</th><th>الحالة</th><th>المكان / ملاحظات</th></tr></thead><tbody>' +
        x.list.map(function (t, i) {
          var a = Math.max(startMs(t), dayStart(x.d)), z = Math.min(endMs(t), dayEnd(x.d));
          var win = (a <= dayStart(x.d) && z >= dayEnd(x.d) - 60000) ? 'طوال اليوم' : fmtTime(dtAt(a).time) + ' – ' + fmtTime(dtAt(z).time);
          return '<tr><td>' + (i + 1) + '</td><td style="font-weight:700">' + esc(t.title) + '</td><td>' + CATS[catOf(t)].n + '</td><td>' + win + '</td><td>' + stamp2(t.startDate, t.startTime, '00:00') + '</td><td>' + stamp2(t.endDate, t.endTime, '23:59') +
            '</td><td>' + (PRI[t.priority] || '—') + '</td><td>' + stText(t) + snzNote(t) + '</td><td>' + esc([t.place, t.notes].filter(Boolean).join(' · ') || '—') + '</td></tr>';
        }).join('') + '</tbody></table>' : '<p class="pr-empty">لا توجد مهام في هذا اليوم.</p>';
      return '<section class="pr-day"><h2 class="pr-dayh">' + esc(longDate(x.d)) + (x.d === TODAY ? ' <small>(اليوم)</small>' : '') + '</h2>' +
        '<p class="pr-sub">مجدولة: <b>' + st.total + '</b> · تبدأ اليوم: <b>' + starts + '</b> · تنتهي اليوم: <b>' + due + '</b> · منجزة: <b>' + st.done + '</b> · نشطة: <b>' + st.active + '</b> · قادمة: <b>' + st.upcoming + '</b> · انتهت دون إنجاز: <b style="color:#dc2626">' + st.expired + '</b> · ملغاة: <b>' + st.canceled + '</b>' + (st.snzN ? ' · <b style="color:#b45309">مهام ممدودة الفترة: ' + st.snzTasks + '</b>' : '') + '</p>' +
        (st.total ? '<div class="pr-seg">' + seg + '</div>' : '') + rows + '</section>';
    }).join('');
    printDoc('تقرير يومي مفصّل', body);
  }

  function csvDownload(name, rows) {
    var csv = '﻿' + rows.map(function (r) { return r.map(function (c) { return '"' + String(c == null ? '' : c).replace(/"/g, '""') + '"'; }).join(','); }).join('\r\n');
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 5000);
  }
  function exportCsv() {
    var list = rpTasks();
    var rows = [['المهمة', 'التصنيف', 'تاريخ البداية', 'وقت البداية', 'تاريخ النهاية', 'وقت النهاية', 'الأولوية', 'الحالة', 'المكان', 'ملاحظات', 'تاريخ الإنجاز', 'تم مد الفترة', 'عدد مرات المد', 'إجمالي المد (دقيقة)']].concat(list.map(function (t) {
      return [t.title, CATS[catOf(t)].n, t.startDate, t.startTime, t.endDate, t.endTime, PRI[t.priority] || '', STATUS_TXT[statusOf(t)], t.place, t.notes, t.done && t.doneAt ? isoDate(new Date(t.doneAt)) : '',
        (t.snoozes || []).length ? 'تم مد فترة المهمة إلى فترة إضافية' : '', (t.snoozes || []).length, snzTotal(t)];
    }));
    csvDownload('engazy-report-' + RP.from + '_' + RP.to + '.csv', rows);
    toast('تم تصدير ' + list.length + ' مهمة (يفتح في Excel)');
  }
  function exportSnzCsv() {
    var rr = snzRows(rpTasks());
    if (!rr.length) return toast('لا توجد تأجيلات في هذه الفترة');
    csvDownload('engazy-snoozes-' + RP.from + '_' + RP.to + '.csv', [['المهمة', 'رقم التأجيل', 'وقت التأجيل', 'المصدر', 'المدة المضافة (دقيقة)', 'المدة المضافة', 'النهاية السابقة', 'النهاية الجديدة']].concat(rr.map(function (r) {
      var f = r.z.fromEnd || {}, to = r.z.toEnd || {};
      return [r.t.title, r.no, new Date(r.z.at).toISOString(), VIA_TXT[r.z.via] || VIA_TXT.manual, r.z.mins, snzTxt(r.z.mins), f.date + ' ' + f.time, to.date + ' ' + to.time];
    })));
    toast('تم تصدير ' + rr.length + ' تأجيل');
  }

  /* ----- صفحة التقارير ----- */
  function initReports() {
    rpRestore();
    var PRESETS = [['today', 'اليوم'], ['week', 'هذا الأسبوع'], ['month', 'هذا الشهر'], ['last30', 'آخر 30 يومًا'], ['all', 'كل المهام']];
    $('#rpCtl').innerHTML =
      '<div class="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-1" id="rpPresets"></div>' +
      '<div class="mt-3 grid grid-cols-2 gap-3"><div><label class="label !mt-0" for="rpFrom">من تاريخ</label><input id="rpFrom" type="date" class="field" /></div>' +
      '<div><label class="label !mt-0" for="rpTo">إلى تاريخ</label><input id="rpTo" type="date" class="field" /></div></div>' +
      '<p id="rpErr" class="mt-1 min-h-[18px] text-[12px] font-bold text-red-500" role="alert"></p>' +
      '<div class="grid grid-cols-2 gap-3"><div><label class="label !mt-0" for="rpCat">التصنيف</label><select id="rpCat" class="field"><option value="all">كل التصنيفات</option>' +
      CAT_ORDER.map(function (k) { return '<option value="' + k + '">' + CATS[k].n + '</option>'; }).join('') + '</select></div>' +
      '<div><label class="label !mt-0" for="rpSt">الحالة</label><select id="rpSt" class="field"><option value="all">كل الحالات</option>' +
      ST_ORDER.map(function (k) { return '<option value="' + k + '">' + STATUS_TXT[k] + '</option>'; }).join('') + '</select></div></div>' +
      '<label class="mt-3 flex items-center gap-2 text-[13px] font-bold text-navy"><input id="rpSkip" type="checkbox" class="h-4 w-4 accent-[#1896ba]" /> تخطي الأيام الفاضية في طباعة كل يوم لوحده</label>' +
      '<div class="mt-4 grid grid-cols-1 gap-2.5"><button id="rpPrintAll" class="btn-primary"><i class="fa-solid fa-print me-2"></i>طباعة التقرير مجمّعًا</button>' +
      '<button id="rpPrintDays" class="btn-outline"><i class="fa-solid fa-calendar-day me-2"></i><span>طباعة كل يوم على حدة</span></button>' +
      '<button id="rpCsv" class="btn-outline"><i class="fa-solid fa-file-csv me-2"></i>تصدير Excel (CSV)</button>' +
      '<button id="rpSnzCsv" class="btn-outline"><i class="fa-solid fa-clock-rotate-left me-2"></i>تصدير سجل التأجيلات (CSV)</button></div>';
    var F = $('#rpFrom'), T2 = $('#rpTo'), err = $('#rpErr');
    function sync() {
      F.value = RP.from; T2.value = RP.to; T2.min = RP.from; $('#rpCat').value = RP.cat; $('#rpSt').value = RP.st; $('#rpSkip').checked = !!RP.skip;
      $('#rpPresets').innerHTML = PRESETS.map(function (p) { return '<button class="fchip' + (RP.preset === p[0] ? ' is-on' : '') + '" data-pre="' + p[0] + '">' + p[1] + '</button>'; }).join('');
    }
    function render() {
      var list = rpTasks(), st = rpStats(list), buckets = rpBuckets(), bd = bucketData(list, buckets), n = daysBetween(RP.from, RP.to) + 1;
      $('#rpRange').textContent = 'من ' + shortDate(RP.from) + ' إلى ' + shortDate(RP.to) + ' · ' + (n === 1 ? 'يوم واحد' : n === 2 ? 'يومان' : n + (n <= 10 ? ' أيام' : ' يومًا'));
      $('#rpPrintDays span').textContent = 'طباعة كل يوم على حدة (' + rpDays().length + ' صفحة)';
      if (!list.length) {
        $('#rpBody').innerHTML = '<div class="rounded-3xl bg-white p-8 text-center shadow-card"><i class="fa-solid fa-chart-column text-[40px] text-royal/40"></i><p class="mt-3 text-[15px] font-bold text-navy">لا توجد مهام في هذه الفترة</p><p class="mt-1 text-[12px] text-slate2">غيّر التواريخ أو الفلاتر، أو أضف مهام من صفحة المهام.</p></div>';
        return;
      }
      var kind = buckets.length && buckets[0].from === buckets[0].to ? 'يوميًا' : buckets[0].full.indexOf('–') > -1 ? 'أسبوعيًا' : 'شهريًا';
      cur = { list: list, bd: bd, snz: snzRows(list), tok: [RP.from, RP.to, RP.cat, RP.st].join('|') };
      $('#rpBody').innerHTML =
        '<div class="grid grid-cols-2 gap-3">' + kpiHtml(st, false) + '</div>' +
        '<section class="rp-card mt-4"><h3 class="rp-h">المهام حسب الفترة <small>(' + kind + ' · حسب تاريخ النهاية)</small></h3>' + barChart(bd) + legend() + '</section>' +
        '<div class="mt-4 grid grid-cols-1 gap-4"><section class="rp-card"><h3 class="rp-h">توزيع الحالات</h3>' + donut(st) + donutLegend(st) + '</section>' +
        '<section class="rp-card"><h3 class="rp-h">التصنيفات <small>(منجزة / إجمالي)</small></h3>' + catBars(list) + '</section></div>' +
        '<section class="rp-card mt-4"><h3 class="rp-h">الخط الزمني للمهام <small>(' + list.length + ')</small></h3><div id="rpGan"></div></section>' +
        '<section class="rp-card mt-4"><h3 class="rp-h">ملخص الفترات <small>(' + bd.length + ')</small></h3><div id="rpSum"></div></section>' +
        '<section class="rp-card mt-4"><h3 class="rp-h">الجدول التفصيلي (' + list.length + ')</h3><div id="rpDet"></div></section>' +
        '<section class="rp-card mt-4"><h3 class="rp-h"><i class="fa-solid fa-clock-rotate-left me-1 text-ember"></i>سجل مد الفترات (التأجيل) <small>(' + cur.snz.length + ')</small></h3>' +
        '<p class="mb-2 text-[12px] font-bold ' + (st.snzN ? 'text-amber-700' : 'text-slate2') + '">' + esc(snzSummaryText(st)) + '</p><div id="rpSnz"></div></section>' +
        '<p class="mt-4 text-center text-[11px] text-slate2">الطباعة بتشمل كل البيانات كاملة (بدون تقسيم صفحات)، والجدول المطبوع فيه المكان والملاحظات كمان.</p>';
      drawGan(); drawSum(); drawDet(); drawSnz();
    }
    var cur = { list: [], bd: [], snz: [], tok: '' }, SZS = [10, 25, 50];
    function drawGan() {
      var box = $('#rpGan'); if (!box) return;
      var pg = paginate('rp-gan', cur.list, 10, drawGan, { token: cur.tok });
      box.innerHTML = gantt(pg.items, pg.items.length) + pg.html;
    }
    function drawSum() {
      var box = $('#rpSum'); if (!box) return;
      var pg = paginate('rp-sum', cur.bd, 10, drawSum, { token: cur.tok, sizes: SZS });
      box.innerHTML = '<div class="overflow-x-auto">' + summaryTable(cur.bd, 'rp-table', pg.items) + '</div>' + pg.html;
    }
    function drawDet() {
      var box = $('#rpDet'); if (!box) return;
      var pg = paginate('rp-det', cur.list, 10, drawDet, { token: cur.tok, sizes: SZS });
      box.innerHTML = '<div class="overflow-x-auto">' + detailTable(pg.items, 'rp-table', false, pg.from) + '</div>' + pg.html;
    }
    function drawSnz() {
      var box = $('#rpSnz'); if (!box) return;
      var pg = paginate('rp-snz', cur.snz, 10, drawSnz, { token: cur.tok, sizes: SZS });
      box.innerHTML = '<div class="overflow-x-auto">' + snzTable(pg.items, 'rp-table', pg.from) + '</div>' + pg.html;
    }
    function update() { rpSave(); sync(); render(); }
    function setRange(f, t, preset) {
      if (!f || !t) { err.textContent = 'اختر تاريخ البداية والنهاية'; return; }
      if (t < f) { err.textContent = 'تاريخ النهاية لا يمكن أن يكون قبل تاريخ البداية'; sync(); return; }
      if (daysBetween(f, t) + 1 > RP_MAX) { err.textContent = 'أقصى مدة للتقرير ' + RP_MAX + ' يومًا'; sync(); return; }
      err.textContent = ''; RP.from = f; RP.to = t; RP.preset = preset || ''; update();
    }
    F.addEventListener('change', function () {
      var f = F.value, t = RP.to < f ? f : RP.to; // لو البداية بعد النهاية الحالية ننقل النهاية معاها
      setRange(f, t);
    });
    T2.addEventListener('change', function () { setRange(RP.from, T2.value); });
    $('#rpCat').addEventListener('change', function (e) { RP.cat = e.target.value; update(); });
    $('#rpSt').addEventListener('change', function (e) { RP.st = e.target.value; update(); });
    $('#rpSkip').addEventListener('change', function (e) { RP.skip = e.target.checked; update(); });
    route.click = function (e) {
      var p = e.target.closest('[data-pre]'); if (p) { rpPreset(p.dataset.pre); err.textContent = ''; return update(); }
      if (e.target.closest('#rpPrintAll')) return printReportAll();
      if (e.target.closest('#rpPrintDays')) return printReportDays();
      if (e.target.closest('#rpCsv')) return exportCsv();
      if (e.target.closest('#rpSnzCsv')) return exportSnzCsv();
    };
    update();
    var iv = setInterval(function () { if (page === 'reports' && !document.hidden) render(); }, 60000);
    cleanups.push(function () { clearInterval(iv); });
  }

  /* =====================================================
     تشغيل الصفحة
     ===================================================== */
  var INIT = { welcome: initWelcome, home: initHome, tasks: initTasks, notifications: initNotifs, reports: initReports, profile: initProfile };

  function boot(name) {
    cleanups.forEach(function (f) { try { f(); } catch (e) {} });
    cleanups = [];
    var old = $('#sheet'); if (old) old.remove();
    page = name; phone = $('.phone'); route = {};
    applyTheme(name);
    renderCommon();
    if (INIT[name]) INIT[name]();
    startTicker();
    gate();
    nativeInit();
    if (checkAlerts() && page === 'notifications') renderNotifs();
    if (page === 'tasks') renderTasks();
  }

  function startApp() {
  if (STANDALONE) {
    // نسخة الملف الواحد: كل صفحة جوه <template> ونبدّل بينها بالـ #hash
    var go = function () {
      var name = (location.hash || '#welcome').slice(1);
      var tpl = document.getElementById('tpl-' + name);
      if (!tpl) { name = 'welcome'; tpl = document.getElementById('tpl-welcome'); }
      $('#app').innerHTML = tpl.innerHTML;
      document.title = tpl.getAttribute('data-title') || document.title;
      document.body.setAttribute('data-page', name);
      boot(name);
    };
    window.addEventListener('hashchange', go);
    go();
  } else {
    boot(document.body.getAttribute('data-page'));
  }
  }

  // نشغّل قاعدة SQLite الأول، وبعدين نحمّل البيانات ونبدأ التطبيق
  dbInit().then(function () { dbLoadState(); }).catch(function (e) {
    dbOK = false; dbError = String((e && e.message) || e);
    try { var l = JSON.parse(localStorage.getItem(KEY)); state = l && l.v === 3 ? normalizeState(l) : emptyState(); } catch (x) { state = emptyState(); }
  }).then(startApp);
})();
