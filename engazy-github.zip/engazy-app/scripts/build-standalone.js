#!/usr/bin/env node
/**
 * يبني نسخة "الملف الواحد" (STANDALONE):
 *   dist/engazy-standalone.html
 * فيها كل حاجة جوه ملف HTML واحد: الصفحات الخمس + Tailwind CSS + الخطوط + الأيقونات + الـ JavaScript.
 * بتشتغل من غير إنترنت وبدون أي ملفات تانية.
 *
 * التشغيل:  node scripts/build-standalone.js   (أو: npm run build:standalone)
 */
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const b64 = (p) => fs.readFileSync(path.join(root, p)).toString('base64');

// ---------- 1) الخطوط (Cairo) ----------
const fontsCss = read('css/fonts.css').replace(/url\(\.\.\/fonts\/([^)]+\.woff2)\)/g, (_, f) => {
  return `url(data:font/woff2;base64,${b64('fonts/' + f)})`;
});

// ---------- 2) الأيقونات (Font Awesome): نخلّي Free بس (solid + regular) ----------
const faRaw = read('vendor/fontawesome/css/all.min.css');
const faBlocks = faRaw.match(/@font-face\{[^}]*\}/g) || [];
let faCss = faRaw;
faBlocks.forEach((blk) => { faCss = faCss.replace(blk, ''); });
const keptFaces = faBlocks
  .filter((blk) => /font-family:"Font Awesome \d+ Free"/.test(blk))
  .map((blk) => blk.replace(/url\(\.\.\/webfonts\/([^)]+\.woff2)\)/g, (_, f) => {
    return `url(data:font/woff2;base64,${b64('vendor/fontawesome/webfonts/' + f)})`;
  }));
faCss = keptFaces.join('\n') + '\n' + faCss;

// ---------- 3) Tailwind + JS ----------
const tailwindCss = read('css/tailwind.css');
const appJs = read('js/app.js').replace(/<\/script/gi, '<\\/script');
const sqlJs = read('vendor/sqljs/sql-wasm.js').replace(/<\/script/gi, '<\\/script');
const sqlWasm = read('vendor/sqljs/sql-wasm-b64.js');
const h2c = read('vendor/html2canvas/html2canvas.min.js').replace(/<\/script/gi, '<\\/script');

// ---------- 4) الصفحات: نستخرج <section class="phone"> من كل ملف ----------
const pages = [
  ['welcome', 'index.html'],
  ['home', 'home.html'],
  ['tasks', 'tasks.html'],
  ['notifications', 'notifications.html'],
  ['reports', 'reports.html'],
  ['profile', 'profile.html'],
  ['prayer', 'prayer.html'],
];
const toHash = (file) => '#' + (file === 'index' ? 'welcome' : file);

const templates = pages.map(([name, file]) => {
  const html = read(file);
  const title = (html.match(/<title>([^<]*)<\/title>/) || [])[1] || 'إنجازي – Engazy';
  let section = (html.match(/<section class="phone">[\s\S]*<\/section>/) || [])[0];
  if (!section) throw new Error('مش لاقي <section class="phone"> في ' + file);
  // الروابط بين الصفحات تبقى #hash
  section = section.replace(/href="(index|home|tasks|notifications|reports|profile|prayer)\.html"/g, (_, f) => `href="${toHash(f)}"`);
  return `<template id="tpl-${name}" data-title="${title.replace(/"/g, '&quot;')}">\n${section}\n</template>`;
});

// ---------- 5) تجميع الملف ----------
const out = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no" />
  <meta name="theme-color" content="#6eabff" />
  <title>إنجازي – Engazy</title>
  <style>
${fontsCss}
${faCss}
${tailwindCss}
  </style>
</head>
<body data-standalone data-page="welcome">
  <main class="stage" id="app"></main>

${templates.join('\n\n')}

  <template id="adhan-data">${b64('sounds/adhan-default.mp3')}</template>

  <script>
${sqlJs}
  </script>
  <script>
${sqlWasm}
  </script>
  <script>
${h2c}
  </script>
  <script>
${appJs}
  </script>
</body>
</html>
`;

fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
const target = path.join(root, 'dist', 'engazy-standalone.html');
fs.writeFileSync(target, out);
console.log('تم: ' + path.relative(root, target) + ' (' + (out.length / 1024).toFixed(0) + ' KB)');
