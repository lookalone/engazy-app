/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./*.html', './js/**/*.js'],
  // كلاسات بتتركّب ديناميكيًا في app.js (مثال: 'proj-' + color)
  safelist: ['proj-green', 'proj-blue', 'proj-orange', 'ptask-green', 'ptask-blue', 'tl-green', 'tl-late', 'type-btn', 'type-ico', 'tl-dot-done', 'pad', 'lock', 'bg-red-600', 'is-sel', 'is-today', 'has', 'has-red', 'tcard-expired', 'tcard-active', 'tcard-upcoming', 'tcard-done', 'chip-up', 'fchip-red', 'bg-red-500', 'tcard-canceled', 'chip-cancel', 'cd-canceled', 'chip-snz', 'tico', 'ico-cell', 'urg-hot', 'urg-anim', 'modal-danger', 'modal-warn', 'modal-info', 'hrow-due', 'hrow-done', 'hrow-skip', 'hrow-past', 'hrow-later', 'hv-day-all', 'hv-day-part', 'hv-day-miss', 'hv-day-later', 'hv-day-none', 'hv-slot-done', 'hv-slot-due'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Cairo Variable', 'Cairo', 'system-ui', 'sans-serif'],
      },
      colors: {
        page: 'rgb(var(--page) / <alpha-value>)',   // خلفية الصفحة (برّه الموبايل)
        brand: 'rgb(var(--brand) / <alpha-value>)',  // أزرق الهيدر
        mint: 'rgb(var(--mint) / <alpha-value>)',   // خلفية المحتوى
        royal: 'rgb(var(--royal) / <alpha-value>)',  // عناوين وأزرار
        navy: 'rgb(var(--navy) / <alpha-value>)',   // WELCOME
        leaf: 'rgb(var(--leaf) / <alpha-value>)',   // أخضر (المكتمل)
        ember: 'rgb(var(--ember) / <alpha-value>)',  // برتقالي
        slate2: 'rgb(var(--slate2) / <alpha-value>)', // نص رمادي
      },
      boxShadow: {
        card: '0 6px 16px rgb(var(--royal) / .18)',
        fab: '0 8px 18px rgb(var(--navy) / .35)',
        sheet: '0 -10px 40px rgb(var(--navy) / .25)',
      },
    },
  },
  plugins: [],
};
